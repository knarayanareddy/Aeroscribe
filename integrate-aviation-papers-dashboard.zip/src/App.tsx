import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import PipelineView from './components/PipelineView';
import LiteratureView from './components/LiteratureView';
import NoveltyView from './components/NoveltyView';
import CFDView from './components/CFDView';
import ManuscriptView from './components/ManuscriptView';
import ReviewView from './components/ReviewView';
import WikiView from './components/WikiView';
import SettingsView from './components/SettingsView';

export type View = 'dashboard' | 'pipeline' | 'literature' | 'novelty' | 'cfd' | 'manuscript' | 'review' | 'wiki' | 'settings';

export default function App() {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [selectedRunId, setSelectedRunId] = useState<string | undefined>(undefined);

  const handleNavigate = (view: string, runId?: string) => {
    setActiveView(view as View);
    if (runId) setSelectedRunId(runId);
  };

  const renderView = () => {
    switch (activeView) {
      case 'dashboard': return <Dashboard onNavigate={handleNavigate} />;
      case 'pipeline': return <PipelineView selectedRunId={selectedRunId} onNavigate={handleNavigate} />;
      case 'literature': return <LiteratureView selectedRunId={selectedRunId} />;
      case 'novelty': return <NoveltyView selectedRunId={selectedRunId} />;
      case 'cfd': return <CFDView selectedRunId={selectedRunId} />;
      case 'manuscript': return <ManuscriptView selectedRunId={selectedRunId} />;
      case 'review': return <ReviewView selectedRunId={selectedRunId} />;
      case 'wiki': return <WikiView />;
      case 'settings': return <SettingsView />;
      default: return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}
