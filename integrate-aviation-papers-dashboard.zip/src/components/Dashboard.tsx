import { mockPipelineRuns, mockPapers, mockWikiArticles, mockCFDResults } from '../data/mockData';

interface DashboardProps {
  onNavigate: (view: string, runId?: string) => void;
}

const statusLabels: Record<string, { text: string; cls: string }> = {
  idle: { text: 'Idle', cls: 'bg-slate-100 text-slate-600' },
  running: { text: 'Running', cls: 'bg-blue-100 text-blue-700' },
  gate_pending: { text: 'Gate Pending', cls: 'bg-orange-100 text-orange-700' },
  completed: { text: 'Completed', cls: 'bg-emerald-100 text-emerald-700' },
  failed: { text: 'Failed', cls: 'bg-red-100 text-red-700' },
};

const stageColors: Record<string, string> = {
  completed: 'bg-emerald-500',
  running: 'bg-blue-500',
  gate_pending: 'bg-orange-400',
  pending: 'bg-slate-200',
  failed: 'bg-red-500',
  skipped: 'bg-slate-100',
};

export default function Dashboard({ onNavigate }: DashboardProps) {
  const totalPapers = mockPapers.length;
  const avgRelevance = (mockPapers.reduce((a, p) => a + p.relevanceScore, 0) / totalPapers).toFixed(1);
  const verifiedResults = mockCFDResults.length;
  const activeRuns = mockPipelineRuns.filter(r => r.status === 'running' || r.status === 'gate_pending').length;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Research Dashboard</h1>
        <p className="text-slate-500 mt-1">World's first autonomous aerospace research laboratory</p>
      </div>

      {/* Top metrics */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Active Pipeline Runs', value: activeRuns.toString(), icon: '🔄', color: 'text-blue-600' },
          { label: 'Total Papers Harvested', value: totalPapers.toString(), icon: '📄', color: 'text-slate-900' },
          { label: 'Avg Relevance Score', value: avgRelevance, icon: '⭐', color: 'text-amber-600' },
          { label: 'CFD Results Verified', value: verifiedResults.toString(), icon: '✅', color: 'text-emerald-600' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-xs text-slate-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Pipeline runs */}
      <div>
        <h2 className="text-lg font-semibold text-slate-800 mb-3">Pipeline Runs</h2>
        <div className="space-y-3">
          {mockPipelineRuns.map((run) => {
            const completedStages = run.stages.filter(s => s.status === 'completed').length;
            const progress = (completedStages / run.stages.length) * 100;
            return (
              <div
                key={run.id}
                onClick={() => onNavigate('pipeline', run.id)}
                className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 cursor-pointer hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusLabels[run.status].cls}`}>
                        {statusLabels[run.status].text}
                      </span>
                      <span className="text-xs text-slate-400">{run.journal}</span>
                    </div>
                    <div className="text-sm font-semibold text-slate-800">{run.topic}</div>
                    <div className="text-xs text-slate-500 mt-0.5 italic">"{run.paperTitle}"</div>
                  </div>
                  <div className="text-right shrink-0 ml-4">
                    <div className="text-lg font-bold text-slate-900">{completedStages}/9</div>
                    <div className="text-xs text-slate-400">stages</div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-3">
                  <div className="flex gap-1">
                    {run.stages.map((stage) => (
                      <div
                        key={stage.id}
                        className={`h-2 flex-1 rounded-full ${stageColors[stage.status]}`}
                        title={`${stage.name}: ${stage.status}`}
                      />
                    ))}
                  </div>
                  <div className="flex items-center justify-between mt-1.5 text-xs text-slate-400">
                    <span>{run.stages[run.currentStage]?.name || 'Complete'}</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                </div>

                {run.status === 'gate_pending' && (
                  <div className="mt-3 bg-orange-50 border border-orange-200 rounded-lg px-4 py-2.5 flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-orange-400 animate-pulse shrink-0" />
                    <span className="text-xs text-orange-700 font-medium">
                      Action Required: {run.stages[run.currentStage]?.gateId} needs your approval to continue
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-2 gap-6">
        {/* Principles */}
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h3 className="font-semibold text-slate-800 mb-3">🧬 Core Principles</h3>
          <div className="space-y-3">
            {[
              { icon: '🚫', label: 'Zero Hallucination', desc: 'No fabricated numbers. Every value traces to VerifiedRegistry.' },
              { icon: '🔐', label: 'Verified Registry', desc: 'SHA256 checksums on all computational evidence.' },
              { icon: '🎯', label: 'Journal Calibration', desc: 'Automated AIAA, Elsevier, and Acta Astronautica formatting.' },
              { icon: '👤', label: 'Human-in-the-Loop', desc: '11 mandatory researcher decision gates per pipeline.' },
            ].map((p) => (
              <div key={p.label} className="flex gap-3 items-start">
                <span className="text-lg shrink-0">{p.icon}</span>
                <div>
                  <div className="text-sm font-semibold text-slate-800">{p.label}</div>
                  <div className="text-xs text-slate-500">{p.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AeroWiki */}
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-800">📚 Recent AeroWiki Articles</h3>
            <button
              onClick={() => onNavigate('wiki')}
              className="text-xs text-blue-600 hover:text-blue-700 font-medium"
            >
              View all →
            </button>
          </div>
          <div className="space-y-2">
            {mockWikiArticles.slice(0, 5).map((a) => (
              <div
                key={a.id}
                onClick={() => onNavigate('wiki')}
                className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-800 truncate">{a.title}</div>
                  <div className="text-xs text-slate-400">{a.category} · {a.papersLinked} papers</div>
                </div>
                <div className="text-xs text-slate-400 shrink-0 ml-2">{a.lastUpdated}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent papers summary */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-slate-800">📑 Highest-Relevance Papers</h3>
          <button
            onClick={() => onNavigate('literature')}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            Browse all →
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {mockPapers
            .sort((a, b) => b.relevanceScore - a.relevanceScore)
            .slice(0, 6)
            .map((p) => (
              <div
                key={p.id}
                onClick={() => onNavigate('literature')}
                className="p-3 rounded-lg border border-slate-100 hover:border-blue-200 cursor-pointer transition-colors"
              >
                <div className="text-sm font-medium text-slate-800 line-clamp-1">{p.title}</div>
                <div className="text-xs text-slate-500 mt-0.5">{p.authors} · {p.year}</div>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className="text-xs font-semibold text-blue-600">{p.relevanceScore}/10</span>
                  <span className="text-xs text-slate-400">{p.citationCount} citations</span>
                  <span className="text-xs text-slate-300">|</span>
                  <span className="text-xs text-slate-400">{p.journal}</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
