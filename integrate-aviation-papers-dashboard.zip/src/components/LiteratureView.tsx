import { useState } from 'react';
import { mockPapers, getPapersForRun } from '../data/mockData';

interface LiteratureViewProps {
  selectedRunId?: string;
}

export default function LiteratureView({ selectedRunId }: LiteratureViewProps) {
  const [search, setSearch] = useState('');
  const [minScore, setMinScore] = useState(7);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [selectedPaper, setSelectedPaper] = useState<string | null>(null);
  const [runFilter, setRunFilter] = useState<string>(selectedRunId || 'all');

  const papers = runFilter === 'all' ? mockPapers : getPapersForRun(runFilter);
  const allTags = Array.from(new Set(papers.flatMap(p => p.tags))).sort();

  const filtered = papers.filter(p => {
    if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.authors.toLowerCase().includes(search.toLowerCase())) return false;
    if (p.relevanceScore < minScore) return false;
    if (selectedTag && !p.tags.includes(selectedTag)) return false;
    return true;
  }).sort((a, b) => b.relevanceScore - a.relevanceScore);

  const expandedPaper = papers.find(p => p.id === selectedPaper);

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Literature Archaeology</h1>
        <p className="text-slate-500 mt-1">DOI-verified papers · Zero hallucinated references · Citation graph expansion</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Total Papers', value: mockPapers.length.toString(), icon: '📄' },
          { label: 'DOI Verified', value: '100%', icon: '✅' },
          { label: 'Avg Relevance', value: (mockPapers.reduce((a, p) => a + p.relevanceScore, 0) / mockPapers.length).toFixed(1), icon: '⭐' },
          { label: 'Topics Covered', value: Array.from(new Set(mockPapers.flatMap(p => p.tags))).length.toString(), icon: '🏷️' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 space-y-3">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <svg className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" strokeLinecap="round" />
            </svg>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search title, authors..."
              className="w-full border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Min score:</span>
            <input
              type="range"
              min={1}
              max={10}
              step={0.5}
              value={minScore}
              onChange={e => setMinScore(Number(e.target.value))}
              className="w-24"
            />
            <span className="text-sm font-mono text-slate-700 w-6">{minScore}</span>
          </div>
          <select
            value={runFilter}
            onChange={e => setRunFilter(e.target.value)}
            className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Runs</option>
            <option value="run-001">run-001: RDE</option>
            <option value="run-002">run-002: Morphing Wings</option>
            <option value="run-003">run-003: Hypersonic BL</option>
            <option value="run-004">run-004: Scramjet ML</option>
          </select>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5">
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
              className={`text-xs px-2.5 py-1 rounded-full border transition-all ${
                selectedTag === tag
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-blue-300'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">{filtered.length} papers shown</span>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Paper list */}
        <div className="col-span-2 space-y-2">
          {filtered.map(p => (
            <div
              key={p.id}
              onClick={() => setSelectedPaper(selectedPaper === p.id ? null : p.id)}
              className={`bg-white rounded-xl border shadow-sm p-4 cursor-pointer transition-all ${
                selectedPaper === p.id ? 'border-blue-300 ring-1 ring-blue-200' : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-slate-800">{p.title}</div>
                  <div className="text-xs text-slate-500 mt-0.5">{p.authors} · {p.journal} · {p.year}</div>
                </div>
                <div className="text-right shrink-0 ml-3">
                  <div className="text-sm font-bold text-blue-600">{p.relevanceScore}</div>
                  <div className="text-xs text-slate-400">{p.citationCount} cit.</div>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mt-2">
                {p.tags.map(t => (
                  <span key={t} className="text-xs bg-slate-50 text-slate-500 px-1.5 py-0.5 rounded">{t}</span>
                ))}
              </div>
              {selectedPaper === p.id && (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <p className="text-xs text-slate-600 leading-relaxed">{p.abstract}</p>
                  <div className="mt-2 text-xs text-slate-400">
                    DOI: <span className="font-mono">{p.doi}</span>
                  </div>
                  <div className="mt-1 flex gap-1 flex-wrap">
                    {p.linkedRunIds.map(r => (
                      <span key={r} className="text-xs bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded">{r}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="bg-white rounded-xl border border-slate-100 p-8 text-center text-sm text-slate-400">
              No papers match current filters
            </div>
          )}
        </div>

        {/* Citation graph placeholder */}
        <div className="col-span-1">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 sticky top-8">
            <h3 className="font-semibold text-slate-800 mb-3">Citation Network</h3>
            <div className="text-xs text-slate-500 mb-4">Top papers by citation count within harvested corpus</div>
            {expandedPaper ? (
              <div className="space-y-3">
                <div className="text-sm font-semibold text-slate-800">{expandedPaper.title}</div>
                <div className="text-xs text-slate-500">{expandedPaper.authors}</div>
                <div className="text-xs text-slate-400">Cited by {expandedPaper.citationCount} papers in harvested corpus</div>
                <div className="space-y-2 mt-3">
                  <div className="text-xs font-semibold text-slate-600">Related Papers (same tags)</div>
                  {papers
                    .filter(p => p.id !== expandedPaper.id && p.tags.some(t => expandedPaper.tags.includes(t)))
                    .slice(0, 5)
                    .map(p => (
                      <div key={p.id} className="text-xs text-slate-600 py-1 border-b border-slate-50 last:border-0">
                        <span className="font-medium">{p.title.slice(0, 50)}...</span>
                        <span className="text-slate-400 ml-1">({p.relevanceScore})</span>
                      </div>
                    ))}
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {papers
                  .sort((a, b) => b.citationCount - a.citationCount)
                  .slice(0, 8)
                  .map((p, i) => (
                    <div key={p.id} className="flex items-center gap-2">
                      <span className="text-xs text-slate-400 w-4 shrink-0">{i + 1}.</span>
                      <div className="flex-1 min-w-0">
                        <div className="h-2 bg-blue-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500 rounded-full"
                            style={{ width: `${(p.citationCount / papers.sort((a, b) => b.citationCount - a.citationCount)[0].citationCount) * 100}%` }}
                          />
                        </div>
                      </div>
                      <span className="text-xs text-slate-500 shrink-0 w-6 text-right">{p.citationCount}</span>
                    </div>
                  ))}
                <div className="text-xs text-slate-400 text-center mt-2">Citation count →</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
