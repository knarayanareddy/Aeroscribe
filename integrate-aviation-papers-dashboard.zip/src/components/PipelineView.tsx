import { useState } from 'react';
import { mockPipelineRuns, mockAgentLogs, type PipelineRun, type PipelineStatus, type StageStatus } from '../data/mockData';

interface PipelineViewProps {
  selectedRunId?: string;
  onNavigate?: (view: string, runId?: string) => void;
}

const stageColors: Record<StageStatus, string> = {
  completed: 'bg-emerald-500 border-emerald-500 text-white',
  running: 'bg-blue-500 border-blue-500 text-white',
  gate_pending: 'bg-orange-400 border-orange-400 text-white',
  pending: 'bg-white border-slate-300 text-slate-400',
  failed: 'bg-red-500 border-red-500 text-white',
  skipped: 'bg-slate-100 border-slate-200 text-slate-300',
};

const stageLineColors: Record<StageStatus, string> = {
  completed: 'bg-emerald-400',
  running: 'bg-blue-400',
  gate_pending: 'bg-orange-400',
  pending: 'bg-slate-200',
  failed: 'bg-red-400',
  skipped: 'bg-slate-100',
};

export default function PipelineView({ selectedRunId }: PipelineViewProps) {
  const [runs, setRuns] = useState(mockPipelineRuns);
  const [activeRun, setActiveRun] = useState<PipelineRun>(
    runs.find(r => r.id === selectedRunId) || runs[0]
  );
  const [showNewRun, setShowNewRun] = useState(false);
  const [newTopic, setNewTopic] = useState('');
  const [newJournal, setNewJournal] = useState('Journal of Propulsion and Power');
  const [expandedStage, setExpandedStage] = useState<number | null>(activeRun.currentStage);

  const approveGate = (run: PipelineRun, stageId: number) => {
    setRuns(prev => prev.map(r => {
      if (r.id !== run.id) return r;
      const newStages = r.stages.map(s => s.id === stageId ? { ...s, gateApproved: true, status: 'completed' as const } : s);
      const nextStage = newStages.find(s => s.id === stageId + 1);
      if (nextStage && nextStage.status === 'pending') nextStage.status = 'running';
      return { ...r, stages: newStages, currentStage: Math.min(stageId + 1, 8), status: 'running' as PipelineStatus };
    }));
    setActiveRun(prev => {
      const newStages = prev.stages.map(s => s.id === stageId ? { ...s, gateApproved: true, status: 'completed' as const } : s);
      const nextIdx = stageId + 1;
      if (newStages[nextIdx] && newStages[nextIdx].status === 'pending') {
        newStages[nextIdx] = { ...newStages[nextIdx], status: 'running' };
      }
      return { ...prev, stages: newStages, currentStage: Math.min(nextIdx, 8), status: 'running' };
    });
  };

  const createRun = () => {
    if (!newTopic.trim()) return;
    const newRun: PipelineRun = {
      id: `run-${Date.now()}`,
      topic: newTopic,
      journal: newJournal,
      status: 'running',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      currentStage: 0,
      noveltyScore: 0,
      paperTitle: 'Pending...',
      stages: [
        { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'running', agentsActive: ['TopicIntelligenceAgent'], metrics: {} },
        { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'pending', agentsActive: [], metrics: {} },
        { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'pending', agentsActive: [], metrics: {} },
        { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'pending', agentsActive: [], metrics: {} },
        { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'pending', agentsActive: [], metrics: {} },
        { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
        { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
        { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
        { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
      ]
    };
    setRuns(prev => [newRun, ...prev]);
    setActiveRun(newRun);
    setShowNewRun(false);
    setNewTopic('');
  };

  const runLogs = mockAgentLogs.filter(l => l.runId === activeRun.id);

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Pipeline Manager</h1>
          <p className="text-slate-500 mt-1">Monitor autonomous research pipeline execution</p>
        </div>
        <button
          onClick={() => setShowNewRun(true)}
          className="px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path d="M12 4v16m8-8H4" strokeLinecap="round" /></svg>
          New Run
        </button>
      </div>

      {/* New Run Form */}
      {showNewRun && (
        <div className="bg-white rounded-xl border border-blue-200 shadow-sm p-6 space-y-4">
          <h3 className="font-semibold text-slate-800">Launch New Pipeline Run</h3>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Research Topic</label>
            <input
              value={newTopic}
              onChange={e => setNewTopic(e.target.value)}
              placeholder="e.g., Hybrid rocket fuel regression rate modeling..."
              className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">Target Journal</label>
            <select
              value={newJournal}
              onChange={e => setNewJournal(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option>Journal of Propulsion and Power</option>
              <option>AIAA Journal</option>
              <option>Aerospace Science and Technology</option>
              <option>Acta Astronautica</option>
              <option>Journal of Aircraft</option>
              <option>Combustion and Flame</option>
            </select>
          </div>
          <div className="flex gap-3">
            <button onClick={createRun} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700">Launch</button>
            <button onClick={() => setShowNewRun(false)} className="px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        {/* Run selector */}
        <div className="col-span-1 space-y-2">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1 mb-2">Pipeline Runs</div>
          {runs.map(run => {
            const completed = run.stages.filter(s => s.status === 'completed').length;
            return (
              <button
                key={run.id}
                onClick={() => { setActiveRun(run); setExpandedStage(run.currentStage); }}
                className={`w-full text-left p-3 rounded-xl border transition-all ${
                  activeRun.id === run.id
                    ? 'border-blue-300 bg-blue-50 shadow-sm'
                    : 'border-slate-100 bg-white hover:border-slate-200'
                }`}
              >
                <div className="text-sm font-semibold text-slate-800 line-clamp-1">{run.paperTitle}</div>
                <div className="text-xs text-slate-500 mt-0.5">{run.journal}</div>
                <div className="flex items-center gap-2 mt-1.5">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    run.status === 'running' ? 'bg-blue-100 text-blue-700' :
                    run.status === 'gate_pending' ? 'bg-orange-100 text-orange-700' :
                    run.status === 'completed' ? 'bg-emerald-100 text-emerald-700' :
                    'bg-slate-100 text-slate-600'
                  }`}>{run.status.replace('_', ' ')}</span>
                  <span className="text-xs text-slate-400">{completed}/9 stages</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Stage detail */}
        <div className="col-span-2 space-y-3">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <h3 className="font-semibold text-slate-800 mb-4">{activeRun.paperTitle}</h3>

            {/* Stage pipeline visualization */}
            <div className="flex items-center gap-0 mb-6">
              {activeRun.stages.map((stage, i) => (
                <div key={stage.id} className="flex items-center flex-1">
                  <button
                    onClick={() => setExpandedStage(expandedStage === stage.id ? null : stage.id)}
                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold transition-all shrink-0 ${
                      stageColors[stage.status]
                    } ${expandedStage === stage.id ? 'ring-2 ring-offset-2 ring-blue-300' : ''}`}
                    title={stage.name}
                  >
                    {stage.status === 'completed' ? '✓' : stage.status === 'gate_pending' ? '!' : stage.id}
                  </button>
                  {i < activeRun.stages.length - 1 && (
                    <div className={`flex-1 h-1 ${stageLineColors[stage.status]}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Expanded stage */}
            {expandedStage !== null && activeRun.stages[expandedStage] && (
              <div className="border border-slate-100 rounded-xl p-4 space-y-3">
                {(() => {
                  const stage = activeRun.stages[expandedStage];
                  return (
                    <>
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-slate-800">Stage {stage.id}: {stage.name}</h4>
                          <div className="text-xs text-slate-500 mt-0.5">Status: <span className="font-medium text-slate-700">{stage.status.replace('_', ' ')}</span></div>
                        </div>
                        {stage.status === 'gate_pending' && !stage.gateApproved && (
                          <button
                            onClick={() => approveGate(activeRun, stage.id)}
                            className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-semibold hover:bg-orange-600 transition-colors"
                          >
                            Approve {stage.gateId}
                          </button>
                        )}
                      </div>

                      {stage.agentsActive.length > 0 && (
                        <div>
                          <div className="text-xs font-semibold text-slate-500 mb-1">Active Agents</div>
                          <div className="flex gap-2 flex-wrap">
                            {stage.agentsActive.map(a => (
                              <span key={a} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-lg font-medium">{a}</span>
                            ))}
                          </div>
                        </div>
                      )}

                      {stage.metrics && Object.keys(stage.metrics).length > 0 && (
                        <div>
                          <div className="text-xs font-semibold text-slate-500 mb-1">Metrics</div>
                          <div className="grid grid-cols-2 gap-2">
                            {Object.entries(stage.metrics).map(([k, v]) => (
                              <div key={k} className="bg-slate-50 rounded-lg px-3 py-2">
                                <div className="text-xs text-slate-500">{k.replace(/([A-Z])/g, ' $1').toLowerCase()}</div>
                                <div className="text-sm font-semibold text-slate-800">{String(v)}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {stage.gateId && (
                        <div className={`text-xs px-3 py-2 rounded-lg ${stage.gateApproved ? 'bg-emerald-50 text-emerald-700' : 'bg-orange-50 text-orange-700'}`}>
                          {stage.gateApproved ? `✓ ${stage.gateId} Approved` : `⏳ ${stage.gateId} Awaiting Researcher Approval`}
                        </div>
                      )}
                    </>
                  );
                })()}
              </div>
            )}
          </div>

          {/* Agent Logs */}
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100">
              <h3 className="font-semibold text-slate-800">Agent Activity Log</h3>
              <div className="text-xs text-slate-500 mt-0.5">{runLogs.length} events for {activeRun.id}</div>
            </div>
            <div className="max-h-64 overflow-y-auto divide-y divide-slate-50">
              {runLogs.map(log => (
                <div key={log.id} className="px-5 py-3 hover:bg-slate-50/50">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${
                      log.level === 'success' ? 'bg-emerald-400' :
                      log.level === 'warn' ? 'bg-orange-400' :
                      log.level === 'error' ? 'bg-red-400' :
                      'bg-blue-400'
                    }`} />
                    <span className="text-xs font-semibold text-slate-700">{log.agentId}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-400">{log.event}</span>
                    <span className="ml-auto text-xs text-slate-400">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-xs text-slate-600 ml-4">{log.message}</p>
                  {(log.durationMs || log.costUsd) && (
                    <div className="flex gap-3 ml-4 mt-1">
                      {log.durationMs && <span className="text-xs text-slate-400">{(log.durationMs / 60000).toFixed(1)} min</span>}
                      {log.costUsd && <span className="text-xs text-slate-400">${log.costUsd.toFixed(3)}</span>}
                    </div>
                  )}
                </div>
              ))}
              {runLogs.length === 0 && (
                <div className="px-5 py-8 text-center text-sm text-slate-400">No logs yet for this run</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
