import { useState } from 'react';
import { getReviewsForRun } from '../data/mockData';

interface ReviewViewProps {
  selectedRunId?: string;
}

export default function ReviewView({ selectedRunId }: ReviewViewProps) {
  const activeRunId = selectedRunId || 'run-002';
  const comments = getReviewsForRun(activeRunId);
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [showResolved, setShowResolved] = useState(true);
  const [selectedComment, setSelectedComment] = useState<string | null>(null);

  const filtered = comments.filter(c => {
    if (severityFilter !== 'all' && c.severity !== severityFilter) return false;
    if (!showResolved && c.resolved) return false;
    return true;
  });

  const majorUnresolved = comments.filter(c => c.severity === 'major' && !c.resolved).length;

  const reviewers = [
    { id: 'ReviewerAAgent', name: 'Methodology Reviewer', focus: 'CFD setup, grid convergence, uncertainty quantification', icon: '🔬' },
    { id: 'ReviewerBAgent', name: 'Literature Reviewer', focus: 'Citation completeness, context, related work gaps', icon: '📚' },
    { id: 'ReviewerCAgent', name: 'Physics Reviewer', focus: 'Fluid mechanics, combustion physics, result interpretation', icon: '⚛️' },
    { id: 'ReviewerDAgent', name: 'Compliance Reviewer', focus: 'AIAA format, word limits, citation style, AI disclosure', icon: '📋' },
    { id: 'MetaReviewerAgent', name: 'Meta-Reviewer', focus: 'Overall cohesion, cross-section consistency, major gaps', icon: '🎯' },
  ];

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Peer Review Council</h1>
        <p className="text-slate-500 mt-1">Internal multi-reviewer assessment · 4 specialized reviewers + meta-reviewer</p>
      </div>

      {/* Resolution progress */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-slate-800">Review Resolution Progress</h3>
          <span className={`text-xs font-semibold px-3 py-1.5 rounded-full ${majorUnresolved > 0 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'}`}>
            {majorUnresolved > 0 ? `${majorUnresolved} major issues unresolved` : 'All major issues resolved!'}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-4">
          {(['major', 'minor', 'suggestion'] as const).map(sev => {
            const total = comments.filter(c => c.severity === sev).length;
            const done = comments.filter(c => c.severity === sev && c.resolved).length;
            const pct = total ? (done / total) * 100 : 0;
            return (
              <div key={sev} className="border border-slate-100 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold uppercase tracking-wider ${sev === 'major' ? 'text-red-600' : sev === 'minor' ? 'text-amber-600' : 'text-blue-600'}`}>{sev}</span>
                  <span className="text-xs text-slate-500">{done}/{total}</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${sev === 'major' ? 'bg-red-400' : sev === 'minor' ? 'bg-amber-400' : 'bg-blue-400'}`} style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reviewers */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100">
          <h3 className="font-semibold text-slate-800">Review Council Members</h3>
        </div>
        <div className="grid grid-cols-5 divide-x divide-slate-50">
          {reviewers.map(r => {
            const rComments = comments.filter(c => c.reviewerId === r.id);
            return (
              <div key={r.id} className="p-4 text-center">
                <div className="text-2xl mb-2">{r.icon}</div>
                <div className="text-xs font-semibold text-slate-800">{r.name}</div>
                <div className="text-xs text-slate-500 mt-0.5 line-clamp-2">{r.focus}</div>
                <div className="mt-2 text-sm font-bold text-slate-900">{rComments.length}</div>
                <div className="text-xs text-slate-400">comments</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filter bar */}
      <div className="flex items-center gap-4">
        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {['all', 'major', 'minor', 'suggestion'].map(f => (
            <button
              key={f}
              onClick={() => setSeverityFilter(f)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                severityFilter === f ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-2 text-xs text-slate-600">
          <input type="checkbox" checked={showResolved} onChange={e => setShowResolved(e.target.checked)} className="rounded" />
          Show resolved
        </label>
        <span className="text-xs text-slate-400 ml-auto">{filtered.length} comments shown</span>
      </div>

      {/* Comments list */}
      <div className="space-y-3">
        {filtered.map(comment => {
          const isSelected = selectedComment === comment.id;
          return (
            <div
              key={comment.id}
              onClick={() => setSelectedComment(isSelected ? null : comment.id)}
              className={`bg-white rounded-xl border shadow-sm p-5 cursor-pointer transition-all ${
                comment.resolved ? 'border-emerald-100' :
                comment.severity === 'major' ? 'border-red-100' :
                'border-slate-100'
              } ${isSelected ? 'ring-2 ring-blue-200' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-bold uppercase tracking-wider ${
                      comment.severity === 'major' ? 'text-red-600' :
                      comment.severity === 'minor' ? 'text-amber-600' :
                      'text-blue-600'
                    }`}>{comment.severity}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500">{comment.reviewerName}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-500">{comment.section}</span>
                  </div>
                  <p className="text-sm text-slate-700">{comment.comment}</p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium shrink-0 ml-3 ${
                  comment.resolved ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                }`}>
                  {comment.resolved ? 'Resolved' : 'Open'}
                </span>
              </div>
              {comment.response && (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <div className="text-xs font-semibold text-emerald-600 mb-1">Response:</div>
                  <p className="text-xs text-slate-600">{comment.response}</p>
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="bg-white rounded-xl border border-slate-100 p-8 text-center text-sm text-slate-400">
            No review comments for this run. Comments are generated during Stage 6 (Peer Review Council).
          </div>
        )}
      </div>
    </div>
  );
}
