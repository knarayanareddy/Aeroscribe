import {
  LayoutDashboard,
  GitBranch,
  BookOpen,
  Sparkles,
  FlaskConical,
  FileText,
  Users,
  BookMarked,
  Settings,
} from 'lucide-react';

export type View = 'dashboard' | 'pipeline' | 'literature' | 'novelty' | 'cfd' | 'manuscript' | 'review' | 'wiki' | 'settings';

interface SidebarProps {
  activeView: View;
  setActiveView: (v: View) => void;
}

const navItems: { id: View; label: string; icon: React.ReactNode; badge?: number }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { id: 'pipeline', label: 'Pipeline', icon: <GitBranch size={18} />, badge: 1 },
  { id: 'literature', label: 'Literature', icon: <BookOpen size={18} /> },
  { id: 'novelty', label: 'Novelty', icon: <Sparkles size={18} /> },
  { id: 'cfd', label: 'Evidence / CFD', icon: <FlaskConical size={18} /> },
  { id: 'manuscript', label: 'Manuscript', icon: <FileText size={18} /> },
  { id: 'review', label: 'Peer Review', icon: <Users size={18} />, badge: 4 },
  { id: 'wiki', label: 'AeroWiki', icon: <BookMarked size={18} /> },
  { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
];

export default function Sidebar({ activeView, setActiveView }: SidebarProps) {
  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0">
      <div className="p-5 border-b border-slate-700/50">
        <div className="text-lg font-bold tracking-tight">AeroScribe</div>
        <div className="text-xs text-slate-400 mt-0.5">Research Engine v1.0</div>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
              activeView === item.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon}
            {item.label}
            {item.badge && (
              <span className="ml-auto bg-orange-500 text-white text-xs font-bold px-1.5 py-0.5 rounded-full">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-xs font-bold">KN</div>
          <div>
            <div className="text-sm font-medium">K. Narayana Reddy</div>
            <div className="text-xs text-slate-400">Researcher</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
