import { useState } from 'react';
import { mockWikiArticles, type WikiArticle } from '../data/mockData';

export default function WikiView() {
  const [articles] = useState(mockWikiArticles);
  const [selected, setSelected] = useState<WikiArticle>(mockWikiArticles[0]);
  const [search, setSearch] = useState('');

  const filtered = articles.filter(a =>
    !search || a.title.toLowerCase().includes(search.toLowerCase()) || a.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = Array.from(new Set(articles.map(a => a.category)));

  const renderMarkdown = (text: string) => {
    return text.split('\n\n').map((para, i) => {
      if (para.startsWith('**') && para.endsWith('**') && !para.slice(2, -2).includes('\n')) {
        return <h3 key={i} className="text-base font-bold text-slate-900 mt-5 mb-2">{para.slice(2, -2)}</h3>;
      }
      const formatted = para
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/`(.*?)`/g, '<code class="bg-slate-100 px-1 py-0.5 rounded text-xs font-mono text-slate-700">$1</code>');
      if (para.startsWith('- ') || para.startsWith('1.')) {
        const items = para.split('\n').map(line => line.replace(/^[-\d.]+\s/, ''));
        return (
          <ul key={i} className="list-disc list-inside space-y-1 ml-2 my-2">
            {items.map((item, j) => (
              <li key={j} className="text-sm text-slate-700" dangerouslySetInnerHTML={{ __html: item.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
            ))}
          </ul>
        );
      }
      return <p key={i} className="text-sm text-slate-700 leading-relaxed my-2" dangerouslySetInnerHTML={{ __html: formatted }} />;
    });
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">AeroWiki</h1>
          <p className="text-slate-500 mt-1">Compounding knowledge base — auto-updated by WikiCompilerAgent after each pipeline run</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Published Articles', value: articles.filter(a => a.status === 'published').length.toString() },
          { label: 'Draft Articles', value: articles.filter(a => a.status === 'draft').length.toString() },
          { label: 'Papers Linked', value: articles.reduce((a, w) => a + w.papersLinked, 0).toString() },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 text-center">
            <div className="text-2xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs text-slate-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Article list */}
        <div className="col-span-1 space-y-3">
          <div className="relative">
            <svg className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8" /><path d="M21 21l-4.35-4.35" strokeLinecap="round" />
            </svg>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search articles..."
              className="w-full border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {categories.map(cat => {
            const catArticles = filtered.filter(a => a.category === cat);
            if (!catArticles.length) return null;
            return (
              <div key={cat}>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">{cat}</div>
                {catArticles.map(a => (
                  <button
                    key={a.id}
                    onClick={() => setSelected(a)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg mb-1 transition-all ${
                      selected.id === a.id
                        ? 'bg-blue-50 border border-blue-200'
                        : 'hover:bg-slate-50 border border-transparent'
                    }`}
                  >
                    <div className="text-sm font-medium text-slate-800">{a.title}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className={`text-xs px-1.5 py-0.5 rounded ${a.status === 'published' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{a.status}</span>
                      <span className="text-xs text-slate-400">{a.papersLinked} papers</span>
                    </div>
                  </button>
                ))}
              </div>
            );
          })}
        </div>

        {/* Article content */}
        <div className="col-span-2 bg-white rounded-xl border border-slate-100 shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900">{selected.title}</h2>
              <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                <span>{selected.category}</span>
                <span>·</span>
                <span>Updated {selected.lastUpdated}</span>
                <span>·</span>
                <span>{selected.papersLinked} papers linked</span>
                <span>·</span>
                {selected.linkedRunIds.map(r => (
                  <span key={r} className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded">{r}</span>
                ))}
              </div>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full font-medium ${selected.status === 'published' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
              {selected.status}
            </span>
          </div>

          <div className="border-t border-slate-100 pt-4">
            {renderMarkdown(selected.body)}
          </div>

          {selected.related.length > 0 && (
            <div className="mt-6 pt-4 border-t border-slate-100">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Related Articles</div>
              <div className="flex flex-wrap gap-2">
                {selected.related.map(r => {
                  const relatedArticle = articles.find(a => a.title === r);
                  return (
                    <button
                      key={r}
                      onClick={() => relatedArticle && setSelected(relatedArticle)}
                      className="text-xs bg-slate-50 text-slate-600 px-3 py-1.5 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      {r}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
