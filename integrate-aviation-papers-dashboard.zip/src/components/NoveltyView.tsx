import { useState } from 'react';
import { getGapsForRun, getPapersForRun } from '../data/mockData';

interface NoveltyViewProps {
  selectedRunId?: string;
}

export default function NoveltyView({ selectedRunId }: NoveltyViewProps) {
  const activeRunId = selectedRunId || 'run-001';
  const gaps = getGapsForRun(activeRunId);
  const papers = getPapersForRun(activeRunId);
  const [selectedGap, setSelectedGap] = useState(gaps[0]?.id || null);
  const [runFilter, setRunFilter] = useState(activeRunId);

  const allGaps = runFilter === activeRunId ? gaps : getGapsForRun(runFilter);
  const currentGap = allGaps.find(g => g.id === selectedGap) || allGaps[0];

  // Gap matrix for run-001 (RDE topic)
  const phenomena = ['Wave Stability', 'Cell Width', 'Multi-wave Mode', 'Fuel Mixing', 'Ignition', 'Detonation Speed'];
  const methodologies = ['CFD (DNS)', 'CFD (RANS)', 'Shock Tube', 'Linear Theory', 'ML Surrogate', 'Experiment'];
  const covered: Record<string, boolean> = {
    'Wave Stability-CFD (RANS)': true, 'Wave Stability-Linear Theory': true,
    'Cell Width-Shock Tube': true, 'Cell Width-CFD (DNS)': true, 'Cell Width-Linear Theory': true,
    'Multi-wave Mode-CFD (RANS)': true, 'Multi-wave Mode-Experiment': true,
    'Fuel Mixing-CFD (RANS)': true, 'Fuel Mixing-Experiment': true,
    'Ignition-Shock Tube': true, 'Ignition-Experiment': true,
    'Detonation Speed-CFD (RANS)': true, 'Detonation Speed-Experiment': true, 'Detonation Speed-Shock Tube': true,
  };

  const scoreBar = (score: number) => (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full ${score >= 8.5 ? 'bg-emerald-500' : score >= 7 ? 'bg-blue-500' : 'bg-amber-500'}`}
          style={{ width: `${score * 10}%` }}
        />
      </div>
      <span className="text-sm font-bold text-slate-700 w-8">{score}</span>
    </div>
  );

  const contradictions = [
    {
      p1: 'Smith & Chen (2024)', p2: 'Ng & Zhang (2022)',
      claim1: 'Detonation cell width decreases monotonically with pressure (1–20 atm)',
      claim2: 'Cell width exhibits non-monotonic behavior near stoichiometric H₂-air at elevated pressure',
      score: 0.72, topic: 'Detonation Cell Behavior'
    },
    {
      p1: 'Liu et al. (2024)', p2: 'Andrus et al. (2023)',
      claim1: 'Multi-wave mode is stabilized at back-pressures above 3 bar',
      claim2: 'Wave count is independent of ambient back-pressure; determined solely by injector configuration',
      score: 0.61, topic: 'RDE Wave Mode'
    },
  ];

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Novelty Detection</h1>
          <p className="text-slate-500 mt-1">Research gap analysis · Contradiction detection · Novelty certification</p>
        </div>
        <select
          value={runFilter}
          onChange={e => { setRunFilter(e.target.value); setSelectedGap(null); }}
          className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="run-001">run-001: RDE Stability</option>
          <option value="run-002">run-002: Morphing Wings</option>
          <option value="run-003">run-003: Hypersonic BL</option>
          <option value="run-004">run-004: Scramjet ML</option>
        </select>
      </div>

      {/* Novelty Certificate */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-6 text-white">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">📜</span>
              <span className="font-semibold">Novelty Certificate — {runFilter}</span>
            </div>
            <p className="text-sm text-slate-300 italic max-w-xl">
              {currentGap?.recommendation || 'Pending literature review completion...'}
            </p>
          </div>
          <div className="flex gap-6 shrink-0 ml-6">
            <div className="text-center">
              <div className="text-3xl font-black">{currentGap?.noveltyScore || '—'}</div>
              <div className="text-xs text-slate-400">Novelty Score / 10</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-emerald-400">{currentGap?.competitorRisk?.toUpperCase() || '—'}</div>
              <div className="text-xs text-slate-400">Preemption Risk</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-black">{allGaps.length}</div>
              <div className="text-xs text-slate-400">Gaps Identified</div>
            </div>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-slate-700 flex items-center gap-4 text-xs text-slate-400">
          <span>✓ 0 arXiv preprints found in last 90 days</span>
          <span>·</span>
          <span>✓ No competitor group publications in 6 months</span>
          <span>·</span>
          <span>⏳ GATE-2 awaiting researcher approval</span>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-6">
        {/* Gap Matrix */}
        {runFilter === 'run-001' && (
          <div className="col-span-3 bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-slate-800">Research Gap Matrix</h3>
                <div className="text-xs text-slate-500 mt-0.5">Phenomena × Methodologies — empty cells = candidate gaps</div>
              </div>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-emerald-200 border border-emerald-400 rounded text-center text-[8px] leading-3">✓</span> Covered</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-amber-200 border border-amber-400 rounded text-center text-[8px] leading-3">★</span> Primary Gap</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 bg-slate-100 border border-slate-200 rounded" /> Uncovered</span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr>
                    <th className="text-left py-1.5 pr-3 font-semibold text-slate-600">Phenomena ↓</th>
                    {methodologies.map(m => (
                      <th key={m} className="text-center px-1.5 py-1.5 font-medium text-slate-500" style={{ writingMode: 'vertical-lr', transform: 'rotate(180deg)', maxWidth: 30, height: 80 }}>{m}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {phenomena.map((ph) => (
                    <tr key={ph}>
                      <td className="py-1 pr-3 font-medium text-slate-700 whitespace-nowrap">{ph}</td>
                      {methodologies.map(me => {
                        const key = `${ph}-${me}`;
                        const isCovered = covered[key];
                        const isGap = ph === 'Wave Stability' && me === 'CFD (DNS)';
                        return (
                          <td key={key} className="px-1 py-1 text-center">
                            <div className={`w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold ${
                              isGap ? 'bg-amber-200 border-2 border-amber-400 text-amber-800' :
                              isCovered ? 'bg-emerald-200 border border-emerald-400 text-emerald-700' :
                              'bg-slate-50 border border-slate-200 text-slate-300'
                            }`}>
                              {isGap ? '★' : isCovered ? '✓' : '·'}
                            </div>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Gaps list */}
        <div className={runFilter === 'run-001' ? 'col-span-2 space-y-3' : 'col-span-5 space-y-3'}>
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100">
              <h3 className="font-semibold text-slate-800">Candidate Research Gaps</h3>
              <div className="text-xs text-slate-500 mt-0.5">{allGaps.length} gaps for {runFilter}</div>
            </div>
            <div className="divide-y divide-slate-50">
              {allGaps.map(gap => (
                <button
                  key={gap.id}
                  onClick={() => setSelectedGap(gap.id)}
                  className={`w-full text-left px-5 py-3 hover:bg-slate-50 transition-colors ${
                    selectedGap === gap.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="text-sm font-medium text-slate-800 line-clamp-1">{gap.phenomena}</div>
                  <div className="text-xs text-slate-500 mt-0.5 line-clamp-1">{gap.missingMethodology}</div>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className={`text-xs font-bold ${gap.noveltyScore >= 8.5 ? 'text-emerald-600' : gap.noveltyScore >= 7 ? 'text-blue-600' : 'text-amber-600'}`}>
      {gap.noveltyScore}/10
    </span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      gap.competitorRisk === 'low' ? 'bg-emerald-50 text-emerald-600' :
                      gap.competitorRisk === 'medium' ? 'bg-amber-50 text-amber-600' :
                      'bg-red-50 text-red-600'
                    }`}>{gap.competitorRisk} risk</span>
                    <span className="text-xs text-slate-400">{gap.linkedPapers.length} papers</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Selected gap detail */}
          {currentGap && (
            <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5 space-y-3">
              <h4 className="font-semibold text-slate-800">{currentGap.phenomena}</h4>
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1">Novelty Score</div>
                {scoreBar(currentGap.noveltyScore)}
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1">Missing Methodology</div>
                <p className="text-sm text-slate-700">{currentGap.missingMethodology}</p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1">💡 AeroScribe Recommendation</div>
                <p className="text-sm text-slate-700">{currentGap.recommendation}</p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500 mb-1">Linked Papers</div>
                <div className="flex gap-1 flex-wrap">
                  {currentGap.linkedPapers.map(pid => {
                    const paper = papers.find(p => p.id === pid);
                    return paper ? (
                      <span key={pid} className="text-xs bg-slate-50 text-slate-600 px-2 py-1 rounded-lg">
                        {paper.authors.split(',')[0]} ({paper.year})
                      </span>
                    ) : null;
                  })}
                </div>
              </div>
              <div className={`text-xs px-3 py-2 rounded-lg ${
                currentGap.competitorRisk === 'low' ? 'bg-emerald-50 text-emerald-700' :
                currentGap.competitorRisk === 'medium' ? 'bg-amber-50 text-amber-700' :
                'bg-red-50 text-red-700'
              }`}>
                Competitor Risk: {currentGap.competitorRisk.toUpperCase()}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Contradictions */}
      {runFilter === 'run-001' && (
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
          <h3 className="font-semibold text-slate-800 mb-3">⚡ Contradiction Detection</h3>
          <div className="space-y-3">
            {contradictions.map((c, i) => (
              <div key={i} className="grid grid-cols-3 gap-4 items-start">
                <div className="bg-red-50 border border-red-100 rounded-lg p-3">
                  <div className="text-xs font-semibold text-red-700">{c.p1}</div>
                  <p className="text-xs text-red-600 mt-1 italic">"{c.claim1}"</p>
                </div>
                <div className="flex flex-col items-center justify-center py-2">
                  <div className="text-lg font-black text-amber-600">{(c.score * 100).toFixed(0)}%</div>
                  <div className="text-xs text-amber-600 font-medium">conflict</div>
                  <div className="text-xs text-slate-400 mt-1">{c.topic}</div>
                </div>
                <div className="bg-red-50 border border-red-100 rounded-lg p-3">
                  <div className="text-xs font-semibold text-red-700">{c.p2}</div>
                  <p className="text-xs text-red-600 mt-1 italic">"{c.claim2}"</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
