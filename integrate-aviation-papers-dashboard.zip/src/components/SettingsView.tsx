import { useState } from 'react';
import { journalProfiles } from '../data/mockData';

export default function SettingsView() {
  const [activeTab, setActiveTab] = useState<'api' | 'journals' | 'agents' | 'integrity'>('api');
  const [model, setModel] = useState('claude-opus-4-5');
  const [fastModel, setFastModel] = useState('claude-haiku-3-5');

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-1">Configure the AeroScribe autonomous research engine</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 rounded-xl p-1 w-fit">
        {[
          { id: 'api' as const, label: 'API & Models' },
          { id: 'journals' as const, label: 'Journal Profiles' },
          { id: 'agents' as const, label: 'Agent Config' },
          { id: 'integrity' as const, label: 'Integrity Rules' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'api' && (
        <div className="space-y-5">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6 space-y-5">
            <h3 className="font-semibold text-slate-800 border-b border-slate-100 pb-3">🤖 AI Models</h3>
            <div className="grid grid-cols-2 gap-5">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Primary Model</label>
                <select value={model} onChange={e => setModel(e.target.value)} className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="claude-opus-4-5">claude-opus-4-5 (Most capable)</option>
                  <option value="claude-sonnet-4-5">claude-sonnet-4-5 (Balanced)</option>
                  <option value="claude-haiku-3-5">claude-haiku-3-5 (Fast)</option>
                </select>
                <p className="text-xs text-slate-400 mt-1">Used for Stage 5 (Writing) and Stage 6 (Review)</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Fast Model (Reranking, Classification)</label>
                <select value={fastModel} onChange={e => setFastModel(e.target.value)} className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="claude-haiku-3-5">claude-haiku-3-5</option>
                  <option value="claude-sonnet-4-5">claude-sonnet-4-5</option>
                </select>
                <p className="text-xs text-slate-400 mt-1">Used for literature reranking and contradiction detection</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6 space-y-4">
            <h3 className="font-semibold text-slate-800 border-b border-slate-100 pb-3">🔑 API Keys</h3>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
              ⚠️ <strong>RULE-040:</strong> API keys are stored as environment variables only. Never hardcoded in source files. The PreToolUse hook actively blocks any write containing key patterns.
            </div>
            {[
              { label: 'Anthropic API Key', env: 'ANTHROPIC_API_KEY', masked: true },
              { label: 'Semantic Scholar API Key', env: 'SEMANTIC_SCHOLAR_API_KEY', masked: true },
              { label: 'Clerk Secret Key', env: 'CLERK_SECRET_KEY', masked: true },
            ].map(k => (
              <div key={k.env}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{k.label}</label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    defaultValue="••••••••••••••••••••"
                    readOnly={k.masked}
                    className="flex-1 border border-slate-200 rounded-lg px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder={`Set via ${k.env}`}
                  />
                  <button className="px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-500 hover:bg-slate-50">Update</button>
                </div>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">{k.env}</p>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6 space-y-4">
            <h3 className="font-semibold text-slate-800 border-b border-slate-100 pb-3">💾 Infrastructure</h3>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: 'Database', value: 'PostgreSQL 16 (primary state)', status: 'connected' },
                { label: 'Cache / Queue', value: 'Redis 7 + BullMQ', status: 'connected' },
                { label: 'Object Storage', value: 'MinIO (S3-compatible)', status: 'connected' },
                { label: 'CFD Solver', value: 'OpenFOAM 10 (HPC cluster)', status: 'idle' },
              ].map(i => (
                <div key={i.label} className="border border-slate-100 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-slate-600">{i.label}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${i.status === 'connected' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>{i.status}</span>
                  </div>
                  <div className="text-sm text-slate-700">{i.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'journals' && (
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100">
            <h3 className="font-semibold text-slate-800">Journal Profile Database</h3>
            <p className="text-xs text-slate-500 mt-0.5">Scope keywords, formatting requirements, acceptance rates — sourced from specs/_global/journal-profiles.md</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="text-left px-6 py-3 font-medium">Journal</th>
                  <th className="text-left px-4 py-3 font-medium">Publisher</th>
                  <th className="text-right px-4 py-3 font-medium">Impact Factor</th>
                  <th className="text-right px-4 py-3 font-medium">Accept Rate</th>
                  <th className="text-right px-4 py-3 font-medium">Review Time</th>
                  <th className="text-left px-4 py-3 font-medium">Scope Keywords</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {journalProfiles.map(j => (
                  <tr key={j.id} className="hover:bg-slate-50">
                    <td className="px-6 py-3 font-medium text-slate-800">{j.name}</td>
                    <td className="px-4 py-3 text-slate-600">{j.publisher}</td>
                    <td className="px-4 py-3 text-right font-mono text-slate-700">{j.impactFactor}</td>
                    <td className="px-4 py-3 text-right text-slate-600">{j.acceptanceRate}%</td>
                    <td className="px-4 py-3 text-right text-slate-600">{j.reviewWeeks} weeks</td>
                    <td className="px-4 py-3 text-xs text-slate-500 max-w-[250px]">
                      <div className="flex flex-wrap gap-1">
                        {j.scopeKeywords.slice(0, 3).map(k => (
                          <span key={k} className="bg-slate-50 px-1.5 py-0.5 rounded">{k}</span>
                        ))}
                        {j.scopeKeywords.length > 3 && <span className="text-slate-400">+{j.scopeKeywords.length - 3}</span>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'agents' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100">
              <h3 className="font-semibold text-slate-800">Agent Registry</h3>
              <p className="text-xs text-slate-500 mt-0.5">All registered agents from AGENTS.md — orchestration rules and resource limits</p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                  <tr>
                    <th className="text-left px-6 py-3 font-medium">Agent ID</th>
                    <th className="text-left px-4 py-3 font-medium">Role</th>
                    <th className="text-right px-4 py-3 font-medium">Stage</th>
                    <th className="text-right px-4 py-3 font-medium">Max Runtime</th>
                    <th className="text-left px-4 py-3 font-medium">Primary Tool</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { id: 'TopicIntelligenceAgent', role: 'Worker', stage: 0, runtime: '15 min', tool: 'journal_profile_db' },
                    { id: 'LiteratureHarvestAgent', role: 'Worker', stage: 1, runtime: '4 hours', tool: 'semantic_scholar_api' },
                    { id: 'CitationGraphAgent', role: 'Worker', stage: 1, runtime: '2 hours', tool: 'gitnexus_indexer' },
                    { id: 'LiteratureRerankerAgent', role: 'Worker', stage: 1, runtime: '1 hour', tool: 'llm_reranker' },
                    { id: 'NoveltyDetectionAgent', role: 'Worker', stage: 2, runtime: '1 hour', tool: 'gap_matrix_builder' },
                    { id: 'CFDSetupAgent', role: 'Worker', stage: 4, runtime: '30 min', tool: 'cfd_mesh_generator' },
                    { id: 'CFDSolverAgent', role: 'Worker', stage: 4, runtime: '15 min/run', tool: 'cfd_solver_runner' },
                    { id: 'ArchitectureAgent', role: 'Worker', stage: 5, runtime: '30 min', tool: 'paper_architect' },
                    { id: 'SectionWriterAgent', role: 'Worker', stage: 5, runtime: '2 hours', tool: 'hierarchical_writer' },
                    { id: 'LaTeXRenderAgent', role: 'Worker', stage: 5, runtime: '30 min', tool: 'latex_compiler' },
                    { id: 'MetaReviewerAgent', role: 'Worker', stage: 6, runtime: '30 min', tool: 'meta_review_synthesizer' },
                    { id: 'PipelineOrchestrator', role: 'Orchestrator', stage: 0, runtime: '72 hours', tool: 'pipeline_controller' },
                  ].map(a => (
                    <tr key={a.id} className="hover:bg-slate-50">
                      <td className="px-6 py-3 font-mono text-xs text-slate-800">{a.id}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${a.role === 'Orchestrator' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'}`}>{a.role}</span>
                      </td>
                      <td className="px-4 py-3 text-right text-slate-600">{a.stage}</td>
                      <td className="px-4 py-3 text-right text-slate-600">{a.runtime}</td>
                      <td className="px-4 py-3 text-xs text-slate-500 font-mono">{a.tool}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
            <h3 className="font-semibold text-slate-800 mb-3">Context Window Budgets (RULE-024)</h3>
            <div className="grid grid-cols-3 gap-4">
              {[
                { stage: 'Stage 1 (Literature)', mcps: 15, tools: 80 },
                { stage: 'Stage 4 (Evidence)', mcps: 8, tools: 40 },
                { stage: 'Stage 5 (Writing)', mcps: 6, tools: 30 },
              ].map(b => (
                <div key={b.stage} className="border border-slate-100 rounded-lg p-4">
                  <div className="text-sm font-semibold text-slate-800">{b.stage}</div>
                  <div className="mt-2 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Max MCPs</span>
                      <span className="font-mono text-slate-700">{b.mcps}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-500">Max Tools</span>
                      <span className="font-mono text-slate-700">{b.tools}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'integrity' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6 space-y-4">
            <h3 className="font-semibold text-slate-800 border-b border-slate-100 pb-3">⚖️ Constitutional Rules (from CLAUDE.md)</h3>
            <div className="space-y-3">
              {[
                { rule: 'RULE-001', desc: 'NEVER fabricate numerical results. Every number traces to VerifiedRegistry.', severity: 'critical' },
                { rule: 'RULE-002', desc: 'NEVER add non-DOI-resolved references. Citation hallucination = pipeline HALT.', severity: 'critical' },
                { rule: 'RULE-003', desc: 'NEVER bypass HITL gates. 11 mandatory decision gates per pipeline.', severity: 'critical' },
                { rule: 'RULE-004', desc: 'NEVER list AI as paper author. AI disclosure always generated.', severity: 'critical' },
                { rule: 'RULE-005', desc: 'NEVER submit outside journal scope. Scope fit ≥ 7.0/10 required.', severity: 'critical' },
                { rule: 'RULE-031', desc: 'Quantitative claims: "[VALUE] ± [UNCERTAINTY] ([CONFIDENCE]%, [METHOD])"', severity: 'high' },
                { rule: 'RULE-033', desc: 'Figures use pgfplots ONLY. Vector PDF. SI units in axis labels.', severity: 'high' },
                { rule: 'RULE-034', desc: 'Abstract: 4-sentence structure. Max 250 words. Written LAST.', severity: 'high' },
                { rule: 'RULE-040', desc: 'API keys via environment variables ONLY. PreToolUse hook blocks secrets.', severity: 'critical' },
                { rule: 'RULE-041', desc: 'CFD results SHA256-checksummed before use. Integrity chain enforced.', severity: 'critical' },
                { rule: 'RULE-043', desc: 'VerifiedRegistry is append-only. No UPDATE/DELETE allowed.', severity: 'critical' },
              ].map(r => (
                <div key={r.rule} className="flex items-start gap-3 p-3 rounded-lg border border-slate-100">
                  <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded shrink-0 ${
                    r.severity === 'critical' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                  }`}>{r.rule}</span>
                  <span className="text-sm text-slate-700">{r.desc}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6">
            <h3 className="font-semibold text-slate-800 mb-3">🚦 HITL Gate Schedule</h3>
            <p className="text-xs text-slate-500 mb-4">Every gate requires POST /api/v1/pipeline/{'{run_id}'}/gate/{'{gate_id}'}/approve</p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { gate: 'GATE-0', stage: 0, trigger: 'Journal ranking + topic confirmed' },
                { gate: 'GATE-1', stage: 1, trigger: 'Reading list delivered (95+ papers)' },
                { gate: 'GATE-2', stage: 2, trigger: 'Novelty certificate generated' },
                { gate: 'GATE-3', stage: 3, trigger: 'Contribution statement locked' },
                { gate: 'GATE-4A', stage: 4, trigger: 'Grid convergence study complete' },
                { gate: 'GATE-4B', stage: 4, trigger: 'Validation vs. experiment complete' },
                { gate: 'GATE-4C', stage: 4, trigger: 'Final figure set approved' },
                { gate: 'GATE-5', stage: 5, trigger: 'Section outlines approved' },
                { gate: 'GATE-6', stage: 6, trigger: 'Review council report delivered' },
                { gate: 'GATE-7', stage: 7, trigger: 'Response-to-reviewers approved' },
                { gate: 'GATE-8', stage: 8, trigger: 'Submission package final approval' },
              ].map(g => (
                <div key={g.gate} className="border border-slate-100 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-bold text-slate-800">{g.gate}</span>
                    <span className="text-xs bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded">Stage {g.stage}</span>
                  </div>
                  <p className="text-xs text-slate-500">{g.trigger}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
