import { useState } from 'react';
import { mockPipelineRuns, getCFDForRun } from '../data/mockData';

interface ManuscriptViewProps {
  selectedRunId?: string;
}

const sections = [
  { id: 'abstract', label: 'Abstract', wordCount: 248, status: 'complete' as const },
  { id: 'nomenclature', label: 'Nomenclature', wordCount: 120, status: 'complete' as const },
  { id: 'introduction', label: 'I. Introduction', wordCount: 1840, status: 'complete' as const },
  { id: 'literature', label: 'II. Literature Review', wordCount: 2160, status: 'review' as const },
  { id: 'methodology', label: 'III. Methodology', wordCount: 1420, status: 'review' as const },
  { id: 'results', label: 'IV. Results & Discussion', wordCount: 3240, status: 'review' as const },
  { id: 'conclusions', label: 'V. Conclusions', wordCount: 812, status: 'draft' as const },
];

const sectionContent: Record<string, string> = {
  abstract: `This paper investigates the combustion stability of rotating detonation engines (RDEs) operating under simulated stratospheric conditions, where ambient pressures fall below 100 mbar. Despite extensive characterization of RDE behavior at sea-level conditions, the performance envelope at high-altitude equivalence remains poorly understood. A high-fidelity three-dimensional reactive Euler solver with detailed hydrogen-air kinetics (GRI-Mech 3.0) is employed on a 12.4M-cell structured mesh to simulate detonation wave propagation at back-pressures ranging from 1 atm to 0.05 atm. The detonation wave speed was measured at 1842.3 ± 12.4 m/s (95% CI, reactive Euler with GRI-Mech 3.0), with a peak pressure ratio of 18.6 ± 0.4 and specific impulse of 4312 ± 38 s. A cell instability parameter χ = 3.72 ± 0.18 identifies the onset of multi-wave bifurcation at pressures below 0.3 atm. These findings establish the operational limits of RDE technology for altitude-relight applications and inform the design of next-generation pressure-gain combustion systems for hypersonic propulsion.`,
  nomenclature: `CJ    — Chapman-Jouguet
RDE   — Rotating Detonation Engine
PDE   — Pulse Detonation Engine
Isp   — Specific Impulse [s]
η_c   — Combustion Efficiency
χ     — Cell Instability Parameter
φ     — Equivalence Ratio
λ     — Detonation Cell Width [mm]
p₂/p₁ — Peak Pressure Ratio
L/D   — Lift-to-Drag Ratio
GCI   — Grid Convergence Index
DNS   — Direct Numerical Simulation
RANS  — Reynolds-Averaged Navier-Stokes
LES   — Large-Eddy Simulation
SMA   — Shape Memory Alloy`,
  introduction: `The pursuit of pressure-gain combustion for aerospace propulsion has intensified over the past decade, driven by the thermodynamic advantage of detonation-based cycles over conventional constant-pressure Brayton combustion. Rotating detonation engines (RDEs), in which one or more detonation waves propagate continuously around an annular combustor, offer a theoretical specific impulse improvement of 15–25% over traditional gas turbine combustors (Kaemming & Paxson, 2024).

While RDE performance has been extensively characterized at sea-level and moderate altitude conditions (Nakamura et al., 2023; Andrus et al., 2023), the behavior of rotating detonations under stratospheric pressure conditions (< 100 mbar) remains largely unexplored. This knowledge gap is critical for two applications: (1) altitude relight capability for RDE-equipped hypersonic vehicles, and (2) upper-stage propulsion where ambient pressure is negligible.

The detonation cell width (λ), a fundamental measure of mixture detonability, scales approximately as λ ∝ p^(−0.8) for hydrogen-air mixtures (Smith & Chen, 2024). At stratospheric pressures, the cell width can exceed the annular channel gap, fundamentally altering the wave propagation mode. Ng & Zhang (2022) established a linear perturbation framework for predicting detonation stability, but their analysis is limited to pressures above 0.5 atm.

The objective of this study is to characterize RDE combustion stability at stratospheric pressure conditions using high-fidelity CFD, extending the stability framework of Ng & Zhang to the low-pressure regime relevant to altitude-relight applications.`,
  methodology: `The computational domain consists of a 150 mm diameter annular combustor with a 10 mm channel width, representative of experimental RDE geometries in the literature (Nakamura et al., 2023). The reactive Euler equations are solved with the GRI-Mech 3.0 detailed chemical kinetics mechanism (9 species, 25 reactions for H₂-air) using a finite-volume scheme with HLLC flux splitting.

Grid convergence was assessed via Richardson extrapolation across four mesh levels (1.2M, 4.9M, 12.4M, and 49.6M cells). The GCI for the fine grid (12.4M) is 0.38%, confirming asymptotic convergence. All results presented use the fine grid unless otherwise stated.

Boundary conditions simulate altitude-equivalent back-pressures from 1 atm to 0.05 atm (corresponding to altitudes of 0–25 km). Reactant injection is modeled via a non-reacting plenum with a prescribed pressure ratio of 20:1, consistent with typical RDE feed systems. The simulation is advanced for 50 ms of physical time with a maximum CFL of 0.5, requiring approximately 2,400 time steps at the finest mesh level.`,
  results: `The detonation wave speed at 1 atm back-pressure was measured at 1842.3 ± 12.4 m/s (95% CI, reactive Euler with GRI-Mech 3.0), representing 96.8% of the theoretical Chapman-Jouguet velocity for stoichiometric H₂-air (1902 m/s). The velocity deficit is attributed to frontal curvature and reactant incomplete mixing in the annular geometry.

As back-pressure decreases from 1 atm to 0.05 atm, three distinct propagation modes are observed: (1) single-wave mode (1.0–0.5 atm), (2) multi-wave mode with regular cell structure (0.5–0.15 atm), and (3) unstable galloping mode with intermittent extinction (< 0.15 atm). The transition from single-wave to multi-wave mode occurs at 0.3 atm, consistent with the cell instability parameter χ exceeding the critical value of 3.5.

The peak pressure ratio p₂/p₁ = 18.6 ± 0.4 at 1 atm decreases to 14.2 ± 0.6 at 0.1 atm, reflecting reduced mixture density at the wave front. Combustion efficiency η_c = 0.9417 ± 0.0031 (95% CI, species integration over exit plane) remains above 90% for all back-pressures above 0.15 atm, indicating robust combustion despite the changing wave structure.

Figure 6 shows the detonation wave structure at three representative back-pressures. The single-wave mode (1 atm) exhibits a clean detonation front with regular cellular structure, while the multi-wave mode (0.2 atm) shows four co-rotating waves with irregular cell boundaries. At 0.05 atm, the wave structure becomes chaotic with intermittent extinction events and re-ignition.`,
  conclusions: `This study presents the first CFD-validated investigation of RDE combustion stability at stratospheric pressure conditions. The key findings are:

1. Detonation wave speed of 1842.3 ± 12.4 m/s at 1 atm, representing 96.8% of CJ velocity, validated against experimental data.

2. Three propagation modes identified: single-wave (>0.5 atm), multi-wave (0.15–0.5 atm), and unstable galloping (<0.15 atm).

3. A critical cell instability parameter χ = 3.72 ± 0.18 predicts the onset of multi-wave bifurcation.

4. Combustion efficiency remains above 90% for back-pressures above 0.15 atm, confirming RDE viability for altitude-relight up to approximately 15 km.

These findings establish operational envelopes for RDE technology and inform the design of detonation-based propulsion systems for hypersonic vehicles requiring altitude-relight capability.`,
};

const statusClasses: Record<string, string> = {
  complete: 'bg-emerald-100 text-emerald-700',
  review: 'bg-blue-100 text-blue-700',
  draft: 'bg-amber-100 text-amber-700',
  pending: 'bg-slate-100 text-slate-500',
};

export default function ManuscriptView({ selectedRunId }: ManuscriptViewProps) {
  const activeRunId = selectedRunId || 'run-001';
  const run = mockPipelineRuns.find(r => r.id === activeRunId) || mockPipelineRuns[0];
  const cfdResults = getCFDForRun(activeRunId);
  const [activeSection, setActiveSection] = useState('abstract');
  const [showLatex, setShowLatex] = useState(false);

  const totalWords = sections.reduce((a, s) => a + s.wordCount, 0);
  const targetWords = 12000;

  const latexSnippet = `\\documentclass{aiaa-journal-2026}
\\usepackage{amsmath,amssymb}
\\usepackage{graphicx}
\\usepackage{pgfplots}

\\begin{document}

\\title{${run.paperTitle}}

\\author{K. Narayana Reddy \\and AeroScribe Research Group}

\\begin{abstract}
This paper investigates the combustion stability of rotating detonation engines (RDEs) operating under simulated stratospheric conditions. The detonation wave speed was measured at $1842.3 \\pm 12.4$\\,m/s (95\\% CI, reactive Euler with GRI-Mech 3.0)...
\\end{abstract}

\\section{Introduction}
The pursuit of pressure-gain combustion for aerospace propulsion has intensified...

\\section{Methodology}
The reactive Euler equations are solved with GRI-Mech 3.0...

\\section{Results and Discussion}
\\begin{equation}
  V_{wave} = 1842.3 \\pm 12.4 \\text{ m/s} \\quad (95\\% \\text{ CI})
\\end{equation}

\\begin{figure}[htbp]
  \\centering
  \\begin{tikzpicture}
    \\begin{axis}[xlabel={Back Pressure (atm)}, ylabel={Wave Speed (m/s)}]
      \\addplot coordinates {(1.0,1842) (0.5,1798) (0.2,1741) (0.1,1680) (0.05,1590)};
    \\end{axis}
  \\end{tikzpicture}
  \\caption{Detonation wave speed vs. back-pressure. Error bars indicate 95\\% CI. SHA256: e5f2d1a8c9b0...4d77}
\\end{figure}

\\end{document}`;

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Manuscript Synthesis</h1>
        <p className="text-slate-500 mt-1">Hierarchical 5-level writing pipeline · AIAA LaTeX · Zero-hallucination</p>
      </div>

      {/* Progress */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-5">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="font-semibold text-slate-800">Manuscript Progress</h3>
            <p className="text-xs text-slate-500 mt-0.5">{totalWords.toLocaleString()} / {targetWords.toLocaleString()} words · {cfdResults.length} CFD figures referenced</p>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-slate-900">{Math.round((totalWords / targetWords) * 100)}%</div>
            <div className="text-xs text-slate-400">complete</div>
          </div>
        </div>
        <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${(totalWords / targetWords) * 100}%` }} />
        </div>
        <div className="flex items-center gap-4 mt-2 text-xs">
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-400" /> Complete</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-400" /> In Review</span>
          <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-400" /> Draft</span>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Section nav */}
        <div className="col-span-1 space-y-3">
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Sections</div>
            <div className="space-y-1">
              {sections.map(s => (
                <button
                  key={s.id}
                  onClick={() => { setActiveSection(s.id); setShowLatex(false); }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all ${
                    activeSection === s.id
                      ? 'bg-blue-50 text-blue-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="truncate">{s.label}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${statusClasses[s.status]}`}>{s.wordCount}w</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Journal compliance */}
          <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">📋 AIAA Compliance</div>
            <div className="space-y-1.5">
              {[
                { label: 'Abstract ≤ 250 words', ok: true, detail: '248 words' },
                { label: 'Nomenclature present', ok: true },
                { label: 'AIAA citation style', ok: true },
                { label: 'Uncertainty on all values', ok: false, detail: '7 values missing' },
                { label: 'AI disclosure included', ok: true },
                { label: 'Figure captions complete', ok: false, detail: 'Fig.6 scale bar' },
              ].map(item => (
                <div key={item.label} className="flex items-start gap-2 text-xs">
                  <span className={`shrink-0 mt-0.5 ${item.ok ? 'text-emerald-500' : 'text-amber-500'}`}>
                    {item.ok ? '✓' : '!'}
                  </span>
                  <span className="text-slate-700">{item.label}</span>
                  {item.detail && <span className="text-slate-400 ml-auto">{item.detail}</span>}
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setShowLatex(!showLatex)}
            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50 flex items-center justify-center gap-2"
          >
            {showLatex ? '📄 Content View' : '🔧 LaTeX View'}
          </button>
        </div>

        {/* Content area */}
        <div className="col-span-3">
          {showLatex ? (
            <div className="bg-slate-900 rounded-xl p-5 overflow-auto">
              <div className="text-xs text-slate-400 mb-3 font-mono">manuscript.tex — AIAA LaTeX</div>
              <pre className="text-sm text-green-400 font-mono leading-relaxed whitespace-pre-wrap">{latexSnippet}</pre>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">{sections.find(s => s.id === activeSection)?.label}</h3>
                  <span className="text-xs text-slate-400">{sections.find(s => s.id === activeSection)?.wordCount} words</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${statusClasses[sections.find(s => s.id === activeSection)?.status || 'pending']}`}>
                  {sections.find(s => s.id === activeSection)?.status?.replace('_', ' ')}
                </span>
              </div>

              {sectionContent[activeSection] ? (
                <div className="prose prose-sm max-w-none">
                  <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                    {sectionContent[activeSection]}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <div className="text-4xl mb-3">✏️</div>
                  <div className="text-sm font-medium">Section in progress — SectionWriterAgent queued</div>
                  <div className="text-xs mt-1">Awaiting GATE-4C (Figure Set Approval)</div>
                </div>
              )}

              {activeSection === 'abstract' && sectionContent.abstract && (
                <div className="mt-6 pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Abstract Structure Validation (RULE-034)</h4>
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { n: 'S1', label: 'Problem + Motivation', ok: true },
                      { n: 'S2', label: 'Approach / Method', ok: true },
                      { n: 'S3', label: 'Key Quantitative Result', ok: true },
                      { n: 'S4', label: 'Significance / Impact', ok: true },
                    ].map(s => (
                      <div key={s.n} className={`p-3 rounded-lg border ${s.ok ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'}`}>
                        <div className="text-sm font-bold text-slate-800">{s.n}</div>
                        <div className="text-xs text-slate-600 mt-0.5">{s.label}</div>
                        <div className={`text-xs mt-1 ${s.ok ? 'text-emerald-600' : 'text-red-600'}`}>✓ Present</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 text-xs text-emerald-600 font-medium">
                    ✓ 248/250 words · 4-sentence structure verified · AIAA-compliant
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
