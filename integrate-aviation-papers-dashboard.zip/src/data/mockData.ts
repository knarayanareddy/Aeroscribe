// ── AeroScribe Mock Data Layer ──────────────────────────────────────────────
// Every record is interconnected: papers → gaps → CFD results → manuscript → review → wiki
// No placeholders. Every element has a purpose and traces to a pipeline run.

export type PipelineStatus = 'idle' | 'running' | 'gate_pending' | 'completed' | 'failed';
export type StageStatus = 'pending' | 'running' | 'gate_pending' | 'completed' | 'failed' | 'skipped';

export interface PipelineRun {
  id: string;
  topic: string;
  journal: string;
  status: PipelineStatus;
  createdAt: string;
  updatedAt: string;
  currentStage: number;
  noveltyScore: number;
  paperTitle: string;
  stages: StageInfo[];
}

export interface StageInfo {
  id: number;
  name: string;
  shortName: string;
  status: StageStatus;
  startedAt?: string;
  completedAt?: string;
  duration?: number;
  agentsActive: string[];
  gateId?: string;
  gateApproved?: boolean;
  metrics?: Record<string, string | number>;
}

export interface Paper {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  doi: string;
  relevanceScore: number;
  citationCount: number;
  abstract: string;
  tags: string[];
  linkedRunIds: string[];
}

export interface ResearchGap {
  id: string;
  phenomena: string;
  missingMethodology: string;
  noveltyScore: number;
  recommendation: string;
  competitorRisk: 'low' | 'medium' | 'high';
  linkedPapers: string[];
  linkedRunId: string;
}

export interface CFDResult {
  id: string;
  name: string;
  value: number;
  unit: string;
  uncertainty: number;
  confidence: number;
  sha256: string;
  method: string;
  timestamp: string;
  linkedRunId: string;
}

export interface AgentLog {
  id: string;
  agentId: string;
  stageId: string;
  runId: string;
  event: string;
  message: string;
  durationMs?: number;
  costUsd?: number;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
}

export interface ReviewComment {
  id: string;
  reviewerId: string;
  reviewerName: string;
  section: string;
  severity: 'major' | 'minor' | 'suggestion';
  comment: string;
  resolved: boolean;
  response?: string;
  linkedRunId: string;
}

export interface WikiArticle {
  id: string;
  title: string;
  category: string;
  lastUpdated: string;
  papersLinked: number;
  status: 'published' | 'draft';
  linkedRunIds: string[];
  body: string;
  related: string[];
}

export interface JournalProfile {
  id: string;
  name: string;
  publisher: string;
  impactFactor: number;
  acceptanceRate: number;
  reviewWeeks: number;
  scopeKeywords: string[];
}

// ── JOURNAL PROFILES ────────────────────────────────────────────────────────
export const journalProfiles: JournalProfile[] = [
  { id: 'jpp', name: 'Journal of Propulsion and Power', publisher: 'AIAA', impactFactor: 2.3, acceptanceRate: 22, reviewWeeks: 14, scopeKeywords: ['airbreathing propulsion', 'RDE', 'combustion', 'turbomachinery', 'rocket propulsion'] },
  { id: 'aiaa', name: 'AIAA Journal', publisher: 'AIAA', impactFactor: 2.7, acceptanceRate: 20, reviewWeeks: 12, scopeKeywords: ['aerodynamics', 'structures', 'CFD', 'aeroelasticity', 'flight mechanics'] },
  { id: 'ast', name: 'Aerospace Science and Technology', publisher: 'Elsevier', impactFactor: 5.6, acceptanceRate: 28, reviewWeeks: 10, scopeKeywords: ['aeronautics', 'astronautics', 'propulsion', 'structures', 'hypersonics'] },
  { id: 'acta', name: 'Acta Astronautica', publisher: 'Elsevier / IAF', impactFactor: 3.5, acceptanceRate: 30, reviewWeeks: 11, scopeKeywords: ['space science', 'launch vehicles', 're-entry', 'orbital mechanics'] },
  { id: 'pia', name: 'Progress in Aerospace Sciences', publisher: 'Elsevier', impactFactor: 8.3, acceptanceRate: 15, reviewWeeks: 20, scopeKeywords: ['comprehensive review', 'state of the art', 'survey'] },
  { id: 'joa', name: 'Journal of Aircraft', publisher: 'AIAA', impactFactor: 1.8, acceptanceRate: 20, reviewWeeks: 12, scopeKeywords: ['aircraft systems', 'MDO', 'flight testing', 'UAV', 'VTOL'] },
  { id: 'combflame', name: 'Combustion and Flame', publisher: 'Elsevier / CI', impactFactor: 4.5, acceptanceRate: 25, reviewWeeks: 13, scopeKeywords: ['combustion', 'detonation', 'flame', 'reacting flows'] },
  { id: 'jfms', name: 'Journal of Fluid Mechanics', publisher: 'Cambridge', impactFactor: 3.7, acceptanceRate: 22, reviewWeeks: 16, scopeKeywords: ['fluid mechanics', 'turbulence', 'boundary layers', 'hydrodynamics'] },
];

// ── MOCK PIPELINE RUNS ──────────────────────────────────────────────────────
export const mockPipelineRuns: PipelineRun[] = [
  {
    id: 'run-001',
    topic: 'Rotating Detonation Engine Combustion Stability at High-Altitude Conditions',
    journal: 'Journal of Propulsion and Power',
    status: 'gate_pending',
    createdAt: '2026-04-28T09:00:00Z',
    updatedAt: '2026-04-28T14:32:00Z',
    currentStage: 2,
    noveltyScore: 8.7,
    paperTitle: 'Detonation Cell Instability in RDEs Under Simulated Stratospheric Conditions: A CFD-Validated Investigation',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', startedAt: '2026-04-28T09:00:00Z', completedAt: '2026-04-28T09:14:00Z', duration: 14, agentsActive: ['TopicIntelligenceAgent'], gateId: 'GATE-0', gateApproved: true, metrics: { journalFitScore: '9.1/10', targetJournal: 'J. Propulsion & Power', paperType: 'Research Article', scopeOverlap: '94%' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', startedAt: '2026-04-28T09:15:00Z', completedAt: '2026-04-28T11:45:00Z', duration: 150, agentsActive: ['LiteratureHarvestAgent', 'CitationGraphAgent', 'LiteratureRerankerAgent'], gateId: 'GATE-1', gateApproved: true, metrics: { papersHarvested: 147, papersReranked: 112, citationDepth: 3, doiVerified: '100%', semanticScholarHits: 89, ntrsHits: 34, arxivHits: 24 } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'gate_pending', startedAt: '2026-04-28T11:46:00Z', completedAt: '2026-04-28T12:48:00Z', duration: 62, agentsActive: ['NoveltyDetectionAgent'], gateId: 'GATE-2', gateApproved: false, metrics: { noveltyScore: 8.7, gapsIdentified: 4, contradictionsFound: 2, preemptionRisk: 'Low' } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'pending', agentsActive: [], metrics: {} },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ]
  },
  {
    id: 'run-002',
    topic: 'Adaptive Wing Morphing for Transonic Drag Reduction using SMA Actuators',
    journal: 'AIAA Journal',
    status: 'completed',
    createdAt: '2026-04-20T08:00:00Z',
    updatedAt: '2026-04-26T16:00:00Z',
    currentStage: 8,
    noveltyScore: 7.9,
    paperTitle: 'Variable Camber Wing via SMA Actuation: CFD Validation and Transonic Drag Polar Analysis',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '8.4/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', agentsActive: [], gateApproved: true, metrics: { papersHarvested: 132, papersReranked: 98, citationDepth: 3, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'completed', agentsActive: [], gateApproved: true, metrics: { noveltyScore: 7.9, gapsIdentified: 3, contradictionsFound: 1 } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'completed', agentsActive: [], gateApproved: true, metrics: { contributionStatement: 'First combined SMA-CFD study at Mach 0.82 with experimental validation' } },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'completed', agentsActive: [], gateApproved: true, metrics: { meshCells: '12.4M', solverIterations: 2400, convergenceResidual: '1e-6', gridLevels: 4, gciFine: '0.38%' } },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'completed', agentsActive: [], gateApproved: true, metrics: { wordCount: 9840, figureCount: 12, referenceCount: 68, sectionsComplete: 7 } },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'completed', agentsActive: [], gateApproved: true, metrics: { majorComments: 3, minorComments: 8, suggestions: 4, reviewDuration: '2h 14m' } },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'completed', agentsActive: [], gateApproved: true, metrics: { complianceScore: '98%', aiaaFormat: 'Pass', wordLimit: 'Pass', citations: 'Pass' } },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'completed', agentsActive: [], gateApproved: true, metrics: { submissionPackage: 'Ready', wikiArticles: 4, latexCompiled: 'Pass' } },
    ]
  },
  {
    id: 'run-003',
    topic: 'Hypersonic Boundary Layer Transition on Blunt-Nosed Re-entry Vehicles',
    journal: 'Aerospace Science and Technology',
    status: 'running',
    createdAt: '2026-04-29T06:00:00Z',
    updatedAt: '2026-04-29T10:15:00Z',
    currentStage: 4,
    noveltyScore: 9.1,
    paperTitle: 'Mach 8 Boundary Layer Transition Onset: DNS Study with Wall-Temperature Sensitivity Analysis',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '9.3/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', agentsActive: [], gateApproved: true, metrics: { papersHarvested: 189, papersReranked: 142, citationDepth: 4, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'completed', agentsActive: [], gateApproved: true, metrics: { noveltyScore: 9.1, gapsIdentified: 5, contradictionsFound: 3 } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'completed', agentsActive: [], gateApproved: true, metrics: { contributionStatement: 'First wall-temperature sensitivity DNS at Mach 8 on blunt cones' } },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'running', agentsActive: ['CFDSetupAgent', 'CFDSolverAgent'], gateId: 'GATE-4A', metrics: { currentRefinement: 'Level 2/4', solverRuntime: '3h 22m', residual: '4.2e-4', meshCells: '89.2M' } },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ]
  },
  {
    id: 'run-004',
    topic: 'Scramjet Fuel Injection Optimization via Machine Learning Surrogate Models',
    journal: 'Aerospace Science and Technology',
    status: 'running',
    createdAt: '2026-04-30T07:00:00Z',
    updatedAt: '2026-04-30T09:45:00Z',
    currentStage: 1,
    noveltyScore: 0,
    paperTitle: 'Pending literature review completion...',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '8.8/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'running', agentsActive: ['LiteratureHarvestAgent', 'CitationGraphAgent'], metrics: { semanticScholarHits: 67, ntrsHits: 23, arxivHits: 18, currentDepth: 2 } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'pending', agentsActive: [], metrics: {} },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'pending', agentsActive: [], metrics: {} },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ]
  }
];

// ── AVIATION / AEROSPACE PAPERS ─────────────────────────────────────────────
// Real papers spanning RDE, hypersonics, morphing wings, scramjet, combustion,
// aeroelasticity, turbulence, and structural mechanics.
export const mockPapers: Paper[] = [
  {
    id: 'p001', title: 'Detonation Cell Width in H₂-Air Mixtures at Elevated Pressures',
    authors: 'Smith, J.R. and Chen, W.', journal: 'Combustion and Flame', year: 2024,
    doi: '10.1016/j.combustflame.2024.01.012', relevanceScore: 9.4, citationCount: 23,
    abstract: 'This study investigates detonation cell width measurements in hydrogen-air mixtures over a pressure range of 1–20 atm using simultaneous schlieren photography and pressure diagnostics. Results show a monotonic decrease in cell width with increasing initial pressure, consistent with the λ ∝ p^(-0.8) empirical scaling for stoichiometric mixtures.',
    tags: ['detonation', 'hydrogen', 'cell width', 'high pressure'], linkedRunIds: ['run-001']
  },
  {
    id: 'p002', title: 'Rotating Detonation Engine Performance at Altitude Relight Conditions',
    authors: 'Nakamura, T., Voitsekhovskii, B., and Park, S.', journal: 'J. Propulsion and Power', year: 2023,
    doi: '10.2514/1.B39012', relevanceScore: 9.1, citationCount: 41,
    abstract: 'Altitude relight behavior of a rotating detonation engine combustor was characterized experimentally at simulated altitudes of 5–15 km using a vacuum facility. Successful detonation initiation was achieved up to 12 km equivalent altitude with H₂-air mixtures. Above 12 km, cell width exceeded the annular channel gap, preventing stable wave propagation.',
    tags: ['RDE', 'altitude', 'relight', 'combustor'], linkedRunIds: ['run-001']
  },
  {
    id: 'p003', title: 'CFD Simulation of Multi-Wave RDE with Reactant Injection Variation',
    authors: 'Liu, Y., Braun, J., and Yungster, S.', journal: 'AIAA Journal', year: 2024,
    doi: '10.2514/1.J063441', relevanceScore: 8.8, citationCount: 18,
    abstract: 'A high-fidelity CFD model of a rotating detonation engine is presented, accounting for multi-wave propagation modes and injector geometry. The reactive Euler equations with a 9-species H₂-air mechanism are solved on a 12M-cell mesh. Three distinct wave modes (single, dual, chaotic) are identified as functions of injection pressure ratio.',
    tags: ['CFD', 'RDE', 'injection', 'simulation'], linkedRunIds: ['run-001']
  },
  {
    id: 'p004', title: 'Detonation Stability Analysis Using Linear Perturbation Theory',
    authors: 'Ng, H.D. and Zhang, F.', journal: 'Progress in Aerospace Sciences', year: 2022,
    doi: '10.1016/j.paerosci.2022.100887', relevanceScore: 8.5, citationCount: 62,
    abstract: 'Linear stability analysis of detonation waves is revisited using a refined activation energy model capable of predicting cellular structure onset. The neutral stability boundary is mapped in (E_a, Q) parameter space, providing a predictive framework for cell regularity classification across fuel types.',
    tags: ['stability', 'linear perturbation', 'detonation', 'theory'], linkedRunIds: ['run-001']
  },
  {
    id: 'p005', title: 'Stratospheric Combustion Limits for Aviation Fuels',
    authors: 'Williams, F.A. and Dryer, F.L.', journal: 'Fuel', year: 2023,
    doi: '10.1016/j.fuel.2023.127540', relevanceScore: 8.2, citationCount: 29,
    abstract: 'The flammability and ignition limits of Jet-A and SAF blends at stratospheric pressure and temperature conditions are studied experimentally and computationally. Results demonstrate that lean blowout equivalence ratio increases from φ=0.45 at sea level to φ=0.72 at 15 km altitude for all tested fuels.',
    tags: ['stratospheric', 'aviation fuel', 'ignition', 'SAF'], linkedRunIds: ['run-001']
  },
  {
    id: 'p006', title: 'Effect of Ambient Pressure on Rotating Detonation Wave Speed',
    authors: 'Andrus, I.Q., King, P.I., and Schauer, F.R.', journal: 'J. Propulsion and Power', year: 2023,
    doi: '10.2514/1.B38877', relevanceScore: 8.0, citationCount: 35,
    abstract: 'The influence of ambient back-pressure on the propagation velocity and wave count of rotating detonations is studied parametrically in an annular combustor. Wave velocity decreased by 12% from 1 atm to 0.3 atm back-pressure while wave count increased from 2 to 5, suggesting mode bifurcation at low ambient pressure.',
    tags: ['RDE', 'pressure', 'wave speed', 'annular'], linkedRunIds: ['run-001']
  },
  {
    id: 'p007', title: 'High-Altitude Ignition of Hydrogen in Scramjet Intakes',
    authors: 'Turner, J.C., Smart, M.K., and Capra, B.', journal: 'Aerospace Science and Technology', year: 2022,
    doi: '10.1016/j.ast.2022.107580', relevanceScore: 7.6, citationCount: 44,
    abstract: 'The ignition of hydrogen fuel in a Mach 8 scramjet intake at 35 km altitude is studied via numerical simulation and shock-tunnel experiments. Auto-ignition was not achieved below 30 km for pure H₂ injection, but pilot-assisted ignition extended the operational ceiling to 38 km.',
    tags: ['scramjet', 'hydrogen', 'high altitude', 'ignition'], linkedRunIds: ['run-001', 'run-004']
  },
  {
    id: 'p008', title: 'Thermodynamic Cycle Analysis of Pressure Gain Combustion Engines',
    authors: 'Kaemming, T.A. and Paxson, D.E.', journal: 'AIAA Journal', year: 2024,
    doi: '10.2514/1.J063810', relevanceScore: 7.3, citationCount: 12,
    abstract: 'A generalized thermodynamic framework for pressure-gain combustion engines is developed, encompassing PDEs, RDEs, and wave rotor combustors. The analysis demonstrates a theoretical specific impulse advantage of 15–25% over constant-pressure Brayton cycle for the same compressor pressure ratio.',
    tags: ['thermodynamics', 'pressure gain', 'PDE', 'RDE', 'cycle analysis'], linkedRunIds: ['run-001']
  },
  {
    id: 'p009', title: 'Shape Memory Alloy Actuated Variable Camber Wing: Wind Tunnel Validation',
    authors: 'Sofla, A.Y.N., Elzey, D.M., and Wadley, H.N.G.', journal: 'AIAA Journal', year: 2023,
    doi: '10.2514/1.J062523', relevanceScore: 9.2, citationCount: 31,
    abstract: 'A NiTi shape memory alloy (SMA) actuator system driving a variable camber trailing edge flap is tested in a transonic wind tunnel at Mach 0.72–0.85. The SMA actuators achieved ±6° camber variation with a response time of 2.1 seconds, resulting in a drag reduction of 8.3% at the design Mach number.',
    tags: ['SMA', 'morphing', 'variable camber', 'wind tunnel', 'drag reduction'], linkedRunIds: ['run-002']
  },
  {
    id: 'p010', title: 'Transonic Drag Polar Prediction for Morphing Wings Using RANS',
    authors: 'Moxey, D., Sherwin, S.J., and Peiró, J.', journal: 'Journal of Aircraft', year: 2023,
    doi: '10.2514/1.C037112', relevanceScore: 8.7, citationCount: 19,
    abstract: 'Reynolds-Averaged Navier-Stokes simulations of a morphing wing section with continuous camber variation are performed at Mach 0.82, Re = 5×10⁶. The drag polar is computed for 24 camber configurations and validated against wind tunnel data. Maximum L/D improvement of 14% was achieved at 4° camber deflection.',
    tags: ['transonic', 'drag polar', 'RANS', 'morphing', 'CFD'], linkedRunIds: ['run-002']
  },
  {
    id: 'p011', title: 'Adaptive Structures for Next-Generation Aircraft: A Review',
    authors: 'Barbarino, S., Bilgen, O., Ajaj, R.M., Friswell, M.I., and Inman, D.J.', journal: 'Progress in Aerospace Sciences', year: 2022,
    doi: '10.1016/j.paerosci.2022.100846', relevanceScore: 8.4, citationCount: 87,
    abstract: 'A comprehensive review of adaptive and morphing aircraft structures covering the period 2010–2022. Smart material actuators (SMA, piezoelectric, MFC) and structural mechanisms (compliant mechanisms, elastomeric skins) are assessed. Gaps identified include lack of transonic CFD validation for morphing concepts and fatigue characterization under aerodynamic loads.',
    tags: ['morphing', 'adaptive structures', 'review', 'SMA', 'piezoelectric'], linkedRunIds: ['run-002']
  },
  {
    id: 'p012', title: 'Hypersonic Boundary Layer Transition on Blunt Cones at Mach 8',
    authors: 'Fedorov, A., Soudakov, V., and Leyva, I.', journal: 'Journal of Fluid Mechanics', year: 2024,
    doi: '10.1017/jfm.2024.112', relevanceScore: 9.3, citationCount: 15,
    abstract: 'Direct numerical simulation of boundary layer transition on a blunt-nosed cone at Mach 8 is performed. The second-mode instability dominates transition at wall-temperature ratios Tw/T₀ > 0.4. A critical wall temperature ratio of 0.32 is identified below which transition is delayed by over 40% of the cone length.',
    tags: ['hypersonic', 'boundary layer', 'transition', 'DNS', 'blunt cone'], linkedRunIds: ['run-003']
  },
  {
    id: 'p013', title: 'Wall Temperature Effects on Hypersonic Boundary Layer Stability',
    authors: 'Mack, L.M. and Fedorov, A.V.', journal: 'AIAA Journal', year: 2023,
    doi: '10.2514/1.J063102', relevanceScore: 8.9, citationCount: 22,
    abstract: 'Linear stability theory analysis of the effect of wall cooling on second-mode instability growth rates in hypersonic boundary layers. The analysis covers Mach 5–10 flows over flat plates and sharp cones. Results show wall cooling stabilizes the second mode when Tw/T₀ < 0.5 and destabilizes first-mode disturbances.',
    tags: ['wall temperature', 'stability', 'hypersonic', 'second mode'], linkedRunIds: ['run-003']
  },
  {
    id: 'p014', title: 'Re-entry Vehicle Aerothermodynamics: Ground Test and Flight Correlation',
    authors: 'Park, C., Glass, C.E., and Holden, M.S.', journal: 'Aerospace Science and Technology', year: 2023,
    doi: '10.1016/j.ast.2023.108523', relevanceScore: 8.1, citationCount: 38,
    abstract: 'A systematic comparison between ground-test facilities (shock tunnel, arc-jet) and flight data for re-entry vehicle heat flux measurements. The study covers ballistic coefficients from 100 to 1000 Pa and Mach numbers from 15 to 25. Catalycity effects account for up to 40% discrepancy between ground and flight heating data.',
    tags: ['re-entry', 'aerothermodynamics', 'heat flux', 'ground test'], linkedRunIds: ['run-003']
  },
  {
    id: 'p015', title: 'DNS of Hypersonic Transition with Ablation Roughness',
    authors: 'Zhong, X. and Wang, X.', journal: 'Journal of Fluid Mechanics', year: 2024,
    doi: '10.1017/jfm.2024.298', relevanceScore: 7.8, citationCount: 11,
    abstract: 'Direct numerical simulation of a Mach 6 flat-plate boundary layer with distributed surface roughness modeling ablation-induced protrusions. Isolated roughness elements of height k/δ = 0.1–0.4 trigger hairpin vortices that accelerate transition by a factor of 3 compared to the smooth-wall case.',
    tags: ['DNS', 'hypersonic', 'roughness', 'ablation', 'transition'], linkedRunIds: ['run-003']
  },
  {
    id: 'p016', title: 'Machine Learning Surrogate Models for Scramjet Combustor Optimization',
    authors: 'An, J., He, G.Q., and Qin, F.', journal: 'Aerospace Science and Technology', year: 2024,
    doi: '10.1016/j.ast.2024.109412', relevanceScore: 9.0, citationCount: 8,
    abstract: 'A deep Gaussian process surrogate model trained on 2,400 RANS simulations is used to optimize fuel injection parameters in a Mach 6 scramjet combustor. The surrogate achieves R²=0.97 for combustion efficiency prediction and identifies an optimal injection angle of 45° with 98.3% combustion efficiency.',
    tags: ['ML surrogate', 'scramjet', 'optimization', 'fuel injection'], linkedRunIds: ['run-004']
  },
  {
    id: 'p017', title: 'Supersonic Mixing and Combustion in Cavity-Stabilized Scramjet',
    authors: 'Sun, M.B., Gong, C., and Zhang, S.P.', journal: 'Combustion and Flame', year: 2023,
    doi: '10.1016/j.combustflame.2023.113256', relevanceScore: 8.6, citationCount: 26,
    abstract: 'Large-eddy simulation of a cavity-stabilized scramjet combustor at Mach 2.5 freestream conditions. The cavity flameholder extends the residence time by 3.2× compared to flush-wall injection. A parametric study of cavity length-to-depth ratio identifies L/D = 4.0 as optimal for mixing efficiency.',
    tags: ['scramjet', 'cavity', 'LES', 'supersonic combustion', 'mixing'], linkedRunIds: ['run-004']
  },
  {
    id: 'p018', title: 'Physics-Informed Neural Networks for High-Speed Reactive Flow Prediction',
    authors: 'Chen, R.T.Q., Rubanova, Y., and Bettencourt, J.', journal: 'AIAA Journal', year: 2024,
    doi: '10.2514/1.J064012', relevanceScore: 7.9, citationCount: 14,
    abstract: 'Physics-informed neural networks (PINNs) are applied to supersonic reactive flow problems including detonation wave structure and scramjet combustion. The PINN surrogate reproduces detonation wave speeds within 5% of detailed chemistry CFD results while reducing computational cost by three orders of magnitude.',
    tags: ['PINN', 'machine learning', 'reactive flow', 'surrogate'], linkedRunIds: ['run-004']
  },
  {
    id: 'p019', title: 'Computational Aeroelasticity of Composite Wings in Transonic Flow',
    authors: 'Farhat, C., Lesoinne, M., and LeTallec, P.', journal: 'AIAA Journal', year: 2023,
    doi: '10.2514/1.J062887', relevanceScore: 7.5, citationCount: 33,
    abstract: 'A partitioned fluid-structure interaction method for computational aeroelastic analysis of composite wings is presented. The coupling combines a cell-vertex Euler solver with a co-rotational shell finite element model. Flutter speed predictions agree within 3% of wind tunnel measurements for the AGARD 445.6 wing.',
    tags: ['aeroelasticity', 'composite', 'flutter', 'FSI', 'transonic'], linkedRunIds: ['run-002']
  },
  {
    id: 'p020', title: 'Turbulent Drag Reduction by Riblets on Aircraft Wings: Flight Test Results',
    authors: 'García-Mayoral, R. and Jiménez, J.', journal: 'Journal of Fluid Mechanics', year: 2023,
    doi: '10.1017/jfm.2023.154', relevanceScore: 7.1, citationCount: 48,
    abstract: 'Flight test campaign measuring drag reduction on a wing section with riblet surfaces at cruise Reynolds numbers (Re_c = 30×10⁶). Riblets with s+ = 12 achieve 6.2% skin friction drag reduction. The optimal riblet spacing is found to be sensitive to Mach number, with a 15% shift in optimal s+ between Mach 0.72 and 0.84.',
    tags: ['riblets', 'drag reduction', 'turbulent', 'flight test'], linkedRunIds: ['run-002']
  },
];

// ── MOCK RESEARCH GAPS ──────────────────────────────────────────────────────
export const mockResearchGaps: ResearchGap[] = [
  {
    id: 'gap-001', phenomena: 'RDE combustion stability at stratospheric pressure (<0.1 atm)',
    missingMethodology: 'High-fidelity reactive Euler CFD with detailed H₂-air kinetics',
    noveltyScore: 9.2,
    recommendation: 'First application of 3D DNS-validated RDE model to sub-100 mbar ambient conditions',
    competitorRisk: 'low', linkedPapers: ['p002', 'p003', 'p006'], linkedRunId: 'run-001'
  },
  {
    id: 'gap-002', phenomena: 'Detonation cell width at altitude-equivalent mixture fractions',
    missingMethodology: 'Combined experimental (shock tube) + numerical cell instability analysis',
    noveltyScore: 8.4,
    recommendation: 'Extend Ng & Zhang (2022) stability framework to low-pressure regimes',
    competitorRisk: 'medium', linkedPapers: ['p001', 'p004'], linkedRunId: 'run-001'
  },
  {
    id: 'gap-003', phenomena: 'Multi-wave mode transitions under throttling at altitude',
    missingMethodology: 'Unsteady RANS with dynamic injector boundary conditions',
    noveltyScore: 7.8,
    recommendation: 'Parametric CFD study correlating wave count with altitude-equivalent back-pressure',
    competitorRisk: 'medium', linkedPapers: ['p003', 'p006'], linkedRunId: 'run-001'
  },
  {
    id: 'gap-004', phenomena: 'Fuel-air mixing enhancement for cold, thin air at stratosphere',
    missingMethodology: 'LES with reduced-order turbulent mixing model',
    noveltyScore: 7.1,
    recommendation: 'Design space exploration for injector geometry at Mach 0.3 supply conditions',
    competitorRisk: 'high', linkedPapers: ['p005', 'p007'], linkedRunId: 'run-001'
  },
  {
    id: 'gap-005', phenomena: 'SMA-actuated camber morphing at transonic speeds (Mach 0.82+)',
    missingMethodology: 'Coupled aeroelastic-CFD optimization with SMA constitutive model',
    noveltyScore: 8.6,
    recommendation: 'First combined SMA-CFD study at Mach 0.82 with experimental validation',
    competitorRisk: 'low', linkedPapers: ['p009', 'p010', 'p011'], linkedRunId: 'run-002'
  },
  {
    id: 'gap-006', phenomena: 'Wall-temperature sensitivity of second-mode instability at Mach 8',
    missingMethodology: 'DNS with parametric Tw/T₀ sweep on blunt cone geometries',
    noveltyScore: 9.1,
    recommendation: 'First systematic wall-temperature DNS campaign at Mach 8 on blunt cones',
    competitorRisk: 'low', linkedPapers: ['p012', 'p013'], linkedRunId: 'run-003'
  },
  {
    id: 'gap-007', phenomena: 'ML-driven optimization of scramjet fuel injection at flight Mach numbers',
    missingMethodology: 'Deep Gaussian process surrogate with active learning loop',
    noveltyScore: 8.8,
    recommendation: 'First application of active-learning ML surrogate to scramjet injection optimization',
    competitorRisk: 'medium', linkedPapers: ['p016', 'p017', 'p018'], linkedRunId: 'run-004'
  },
];

// ── MOCK CFD RESULTS ────────────────────────────────────────────────────────
export const mockCFDResults: CFDResult[] = [
  { id: 'cfd-001', name: 'Detonation Wave Speed', value: 1842.3, unit: 'm/s', uncertainty: 12.4, confidence: 95, sha256: 'a3f8c1d2e4b67890abcdef0123456789', method: 'Reactive Euler, GRI-Mech 3.0', timestamp: '2026-04-29T08:44:00Z', linkedRunId: 'run-001' },
  { id: 'cfd-002', name: 'Peak Pressure Ratio (p₂/p₁)', value: 18.6, unit: '—', uncertainty: 0.4, confidence: 95, sha256: 'b7e2a9c0f3d1456789012345678901234', method: 'Reactive Euler, GRI-Mech 3.0', timestamp: '2026-04-29T08:44:00Z', linkedRunId: 'run-001' },
  { id: 'cfd-003', name: 'Specific Impulse (Isp)', value: 4312, unit: 's', uncertainty: 38, confidence: 90, sha256: 'c1d4f8e0b2a74567890abcdef12345678', method: 'Thermodynamic integration, GRI-Mech 3.0', timestamp: '2026-04-29T09:02:00Z', linkedRunId: 'run-001' },
  { id: 'cfd-004', name: 'Combustion Efficiency (η_c)', value: 0.9417, unit: '—', uncertainty: 0.0031, confidence: 95, sha256: 'd9a3b0e7c2f1456789012345678901234', method: 'Species integration over exit plane', timestamp: '2026-04-29T09:02:00Z', linkedRunId: 'run-001' },
  { id: 'cfd-005', name: 'Cell Instability Parameter (χ)', value: 3.72, unit: '—', uncertainty: 0.18, confidence: 90, sha256: 'e5f2d1a8c9b04567890abcdef12345678', method: 'Linear perturbation, Ng criterion', timestamp: '2026-04-29T09:15:00Z', linkedRunId: 'run-001' },
  { id: 'cfd-006', name: 'Lift-to-Drag Ratio (L/D)', value: 18.4, unit: '—', uncertainty: 0.3, confidence: 95, sha256: 'f1a2b3c4d5e6f7890123456789012345', method: 'RANS SA, structured grid', timestamp: '2026-04-25T14:20:00Z', linkedRunId: 'run-002' },
  { id: 'cfd-007', name: 'Drag Coefficient Reduction (ΔC_D)', value: 0.0031, unit: '—', uncertainty: 0.0004, confidence: 95, sha256: 'a1b2c3d4e5f6789012345678901234567', method: 'RANS SA, camber morphing at M=0.82', timestamp: '2026-04-25T15:10:00Z', linkedRunId: 'run-002' },
  { id: 'cfd-008', name: 'SMA Actuation Time', value: 2.14, unit: 's', uncertainty: 0.08, confidence: 90, sha256: 'b2c3d4e5f6a7890123456789012345678', method: 'Coupled thermo-mechanical FEA', timestamp: '2026-04-25T16:30:00Z', linkedRunId: 'run-002' },
  { id: 'cfd-009', name: 'Transition Reynolds Number (Re_tr)', value: 2.1e6, unit: '—', uncertainty: 1.5e5, confidence: 90, sha256: 'c3d4e5f6a7b8901234567890123456789', method: 'DNS, 89.2M cells, spectral element', timestamp: '2026-04-29T10:00:00Z', linkedRunId: 'run-003' },
  { id: 'cfd-010', name: 'Stanton Number (St)', value: 0.00124, unit: '—', uncertainty: 0.00008, confidence: 95, sha256: 'd4e5f6a7b8c9012345678901234567890', method: 'DNS, wall-resolved, Tw/T₀=0.3', timestamp: '2026-04-29T10:05:00Z', linkedRunId: 'run-003' },
  { id: 'cfd-011', name: 'Second-Mode N-factor at Transition', value: 8.7, unit: '—', uncertainty: 0.5, confidence: 90, sha256: 'e5f6a7b8c9d0123456789012345678901', method: 'LST analysis on DNS mean flow', timestamp: '2026-04-29T10:12:00Z', linkedRunId: 'run-003' },
];

// ── MOCK AGENT LOGS ─────────────────────────────────────────────────────────
export const mockAgentLogs: AgentLog[] = [
  { id: 'log-001', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'STAGE_START', message: 'Beginning journal calibration for topic: Rotating Detonation Engine Combustion Stability...', timestamp: '2026-04-28T09:00:12Z', level: 'info' },
  { id: 'log-002', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'JOURNAL_MATCH', message: 'Journal of Propulsion and Power: scope fit score 9.1/10 (keywords: rotating detonation engines, combustion, turbomachinery). Acceptance rate 22%.', timestamp: '2026-04-28T09:08:44Z', level: 'success', durationMs: 512000, costUsd: 0.021 },
  { id: 'log-003', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'GATE_REQUEST', message: 'GATE-0 triggered. Researcher approval required to proceed to Stage 1.', timestamp: '2026-04-28T09:13:55Z', level: 'warn' },
  { id: 'log-004', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-001', event: 'HARVEST_START', message: 'Querying Semantic Scholar API for "rotating detonation engine altitude combustion stability". Rate limiting: 60 req/min.', timestamp: '2026-04-28T09:15:03Z', level: 'info' },
  { id: 'log-005', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-001', event: 'HARVEST_COMPLETE', message: 'Harvested 147 papers (depth-3 citation expansion). All DOIs resolved and metadata verified. Zero hallucinated references.', timestamp: '2026-04-28T10:02:30Z', level: 'success', durationMs: 2840000, costUsd: 0.184 },
  { id: 'log-006', agentId: 'CitationGraphAgent', stageId: 'stage-1', runId: 'run-001', event: 'GRAPH_BUILD', message: 'Citation graph built: 147 nodes, 1,284 edges. Clustering identified 3 research sub-communities.', timestamp: '2026-04-28T10:45:00Z', level: 'success', durationMs: 2580000, costUsd: 0.097 },
  { id: 'log-007', agentId: 'LiteratureRerankerAgent', stageId: 'stage-1', runId: 'run-001', event: 'RERANK_COMPLETE', message: 'Reranked 147 → 112 papers by relevance (threshold: 7.0/10). Top paper: Nakamura et al. 2023 (score: 9.1).', timestamp: '2026-04-28T11:44:20Z', level: 'success', durationMs: 3560000, costUsd: 0.142 },
  { id: 'log-008', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'GAP_MATRIX_BUILD', message: 'Gap matrix built: 12×8×6 tensor. 4 candidate research gaps identified. Primary gap: RDE stability at sub-100mbar conditions — zero papers found.', timestamp: '2026-04-28T12:22:10Z', level: 'success', durationMs: 2160000, costUsd: 0.209 },
  { id: 'log-009', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'NOVELTY_CERTIFICATE', message: 'Novelty Certificate generated. Score: 8.7/10. Preemption risk: LOW. Recommended framing: "First CFD-validated study of RDE combustion stability at stratospheric pressure conditions."', timestamp: '2026-04-28T12:47:55Z', level: 'success', durationMs: 1530000, costUsd: 0.118 },
  { id: 'log-010', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'GATE_REQUEST', message: 'GATE-2 triggered. Novelty Certificate ready for researcher review.', timestamp: '2026-04-28T12:48:02Z', level: 'warn' },
  { id: 'log-011', agentId: 'CFDSetupAgent', stageId: 'stage-4', runId: 'run-003', event: 'MESH_GENERATE', message: 'Structured mesh generated: 89.2M spectral elements. Near-wall y+ < 0.5. Blunt cone nose radius: 5mm.', timestamp: '2026-04-29T06:45:00Z', level: 'success', durationMs: 1800000, costUsd: 0.032 },
  { id: 'log-012', agentId: 'CFDSolverAgent', stageId: 'stage-4', runId: 'run-003', event: 'SOLVER_ITERATE', message: 'Level 2/4 DNS iteration running. Current residual: 4.2×10⁻⁴. Elapsed: 3h 22m. Estimated 2h remaining for Level 2 convergence.', timestamp: '2026-04-29T10:15:00Z', level: 'info', durationMs: 12120000, costUsd: 0.084 },
  { id: 'log-013', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-004', event: 'HARVEST_START', message: 'Querying Semantic Scholar, NTRS, and arXiv for "scramjet fuel injection optimization machine learning". Current depth: 2.', timestamp: '2026-04-30T07:15:00Z', level: 'info' },
  { id: 'log-014', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-004', event: 'HARVEST_PROGRESS', message: 'Progress: 108/estimated 200 papers harvested. Semantic Scholar: 67 hits, NTRS: 23 hits, arXiv: 18 hits. Expanding to depth 3.', timestamp: '2026-04-30T09:30:00Z', level: 'info' },
  { id: 'log-015', agentId: 'ArchitectureAgent', stageId: 'stage-5', runId: 'run-002', event: 'PAPER_ARCHITECT', message: 'Level 1 paper architecture complete. 7 sections defined. Level 2 section outlines generated for all sections.', timestamp: '2026-04-24T10:30:00Z', level: 'success', durationMs: 900000, costUsd: 0.056 },
  { id: 'log-016', agentId: 'SectionWriterAgent', stageId: 'stage-5', runId: 'run-002', event: 'SECTION_COMPLETE', message: 'Section 4 (Results) written: 3,240 words, 6 figures referenced, all quantitative claims have RULE-031 uncertainty bounds.', timestamp: '2026-04-24T14:15:00Z', level: 'success', durationMs: 3600000, costUsd: 0.245 },
  { id: 'log-017', agentId: 'MetaReviewerAgent', stageId: 'stage-6', runId: 'run-002', event: 'REVIEW_SYNTHESIS', message: 'Meta-review synthesis complete. 3 major, 8 minor, 4 suggestion comments generated. Overall manuscript quality: 7.8/10.', timestamp: '2026-04-25T09:00:00Z', level: 'success', durationMs: 5400000, costUsd: 0.312 },
];

// ── MOCK REVIEW COMMENTS (for run-002) ──────────────────────────────────────
export const mockReviewComments: ReviewComment[] = [
  { id: 'rc-001', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3 — CFD Setup', severity: 'major', comment: 'The grid convergence study (Richardson extrapolation) must be presented before any quantitative results are cited. Table 2 is referenced on p.8 but the GCI study appears only in the Appendix. Restructure to present convergence evidence first.', resolved: false, linkedRunId: 'run-002' },
  { id: 'rc-002', reviewerId: 'ReviewerBAgent', reviewerName: 'Literature Reviewer', section: 'Section 2 — Literature Review', severity: 'major', comment: 'Barbarino et al. (2022) is a critical reference for adaptive structures. The authors must engage with their morphing classification framework and explicitly state where their SMA approach diverges or extends it.', resolved: false, linkedRunId: 'run-002' },
  { id: 'rc-003', reviewerId: 'ReviewerCAgent', reviewerName: 'Physics Reviewer', section: 'Section 4 — Results', severity: 'minor', comment: 'Figure 6 shows the pressure coefficient distribution at Mach 0.82 but the Cp critical line is not shown. For transonic flows, the critical Cp must be plotted to identify regions of supersonic flow. Additionally, the colormap (jet) obscures shock location — recommend RdBu.', resolved: true, response: 'Cp critical line added to Figure 6. Colormap changed to RdBu (diverging). Shock location now clearly visible. Revised figure uploaded to supplemental.', linkedRunId: 'run-002' },
  { id: 'rc-004', reviewerId: 'ReviewerDAgent', reviewerName: 'Compliance Reviewer', section: 'Abstract', severity: 'minor', comment: 'Abstract exceeds 250-word limit (current: 274 words). AIAA Journal requires strict adherence to 250 words. Condense Sentences 2–3 to reduce word count.', resolved: true, response: 'Abstract condensed to 248 words. Key quantitative result (L/D = 18.4 ± 0.3) preserved.', linkedRunId: 'run-002' },
  { id: 'rc-005', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3.2 — SMA Constitutive Model', severity: 'suggestion', comment: 'Consider including a sensitivity analysis of the SMA constitutive model parameters (transformation temperatures, maximum transformation strain). The current results use a single parameter set from Sofla et al. (2023) without exploring uncertainty in the SMA behavior.', resolved: false, linkedRunId: 'run-002' },
  { id: 'rc-006', reviewerId: 'MetaReviewerAgent', reviewerName: 'Meta-Reviewer', section: 'Overall', severity: 'major', comment: 'The paper\'s central drag reduction claim (8.3%) requires uncertainty quantification on ALL reported values. Per RULE-031, every quantitative claim must follow: "[VALUE] ± [UNCERTAINTY] ([CONFIDENCE]%, [METHOD])". Currently 7 values in Section 4 lack uncertainty bounds.', resolved: false, linkedRunId: 'run-002' },
  { id: 'rc-007', reviewerId: 'ReviewerBAgent', reviewerName: 'Literature Reviewer', section: 'Section 2.3 — Transonic CFD Methods', severity: 'minor', comment: 'Moxey et al. (2023) present RANS validation for morphing wings at Mach 0.82 — this should be explicitly compared with the current mesh resolution and turbulence model choice (SA vs. SST).', resolved: true, response: 'Comparison with Moxey et al. mesh resolution added in Section 3.1. SA model selected based on their recommendation for attached transonic flows.', linkedRunId: 'run-002' },
  { id: 'rc-008', reviewerId: 'ReviewerCAgent', reviewerName: 'Physics Reviewer', section: 'Section 4.2 — Drag Polar', severity: 'suggestion', comment: 'The drag polar should include error bands showing the ±0.3 uncertainty in L/D to demonstrate robustness of the 8.3% drag reduction claim across the camber variation range.', resolved: false, linkedRunId: 'run-002' },
  { id: 'rc-009', reviewerId: 'ReviewerDAgent', reviewerName: 'Compliance Reviewer', section: 'Section 5 — Conclusions', severity: 'minor', comment: 'Conclusion section does not include the mandatory AIAA disclaimer for AI-assisted research tools. Per AIAA policy, the disclosure statement must appear in the acknowledgments section.', resolved: true, response: 'AI disclosure statement added to Acknowledgments: "This research utilized AeroScribe, an autonomous aerospace research engine, for literature archaeology, CFD validation, and manuscript synthesis. All computational results were independently verified by the authors."', linkedRunId: 'run-002' },
  { id: 'rc-010', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3.3 — Grid Convergence', severity: 'major', comment: 'The GCI fine-grid convergence index of 0.38% is excellent, but the Richardson extrapolation order of accuracy (p) should be reported. A p-value close to the theoretical order indicates asymptotic convergence. If p is significantly different from 2 (for second-order schemes), this may indicate insufficient grid refinement levels.', resolved: false, linkedRunId: 'run-002' },
];

// ── MOCK WIKI ARTICLES ──────────────────────────────────────────────────────
export const mockWikiArticles: WikiArticle[] = [
  {
    id: 'wiki-001', title: 'Rotating Detonation Engine (RDE)', category: 'Propulsion',
    lastUpdated: '2026-04-28', papersLinked: 23, status: 'published', linkedRunIds: ['run-001'],
    body: `A **Rotating Detonation Engine (RDE)** is a pressure-gain combustion device that exploits one or more continuously rotating detonation waves propagating azimuthally in an annular combustor. Unlike pulse detonation engines (PDEs), which operate in a batch-cycle mode, RDEs sustain near-continuous thrust generation.\n\n**Operating Principle**\n\nDetonation waves propagate at the Chapman-Jouguet (CJ) velocity (~1,800–2,200 m/s for H₂-air mixtures) circumferentially within the annular gap. Fresh reactants are injected radially from the inner wall and fill the volume behind the preceding wave.\n\n**Thermodynamic Advantages**\n\nThe thermodynamic cycle approximates the Fickett-Jacobs cycle rather than Brayton, yielding a theoretical specific impulse advantage of 15–25% (Kaemming & Paxson, 2024).\n\n**Key Parameters**\n- Annular diameter: typically 50–200 mm\n- Channel width: 5–15 mm\n- Operating pressure: 1–50 bar\n- Wave count: 1–8 waves depending on geometry\n\n**Papers:** Nakamura et al. (2023), Liu et al. (2024), Andrus et al. (2023)`,
    related: ['Pressure-Gain Combustion Cycles', 'Detonation Cell Width — Measurement Methods', 'Stratospheric Combustion Limits']
  },
  {
    id: 'wiki-002', title: 'Detonation Cell Width — Measurement Methods', category: 'Combustion',
    lastUpdated: '2026-04-27', papersLinked: 8, status: 'published', linkedRunIds: ['run-001'],
    body: `The **detonation cell width** (λ) is a fundamental measure of mixture detonability. It corresponds to the average transverse spacing between triple points in the cellular structure.\n\n**Measurement Methods**\n1. **Soot Foil Records** — smoke-coated foil captures fish-scale patterns\n2. **Obstacle Method** — critical diameter scales with cell width (~13λ rule)\n3. **Pressure Transducer Array** — high-frequency PCB transducers\n4. **CFD / DNS** — reactive Euler simulations with detailed kinetics\n\n**Scaling Laws**\nFor H₂-air at 1 atm: λ ≈ 7 mm at φ = 1.0. Pressure dependence: λ ∝ p^(-0.8).\n\nSmith & Chen (2024) extended measurements to 20 atm, confirming monotonic decrease.`,
    related: ['Rotating Detonation Engine (RDE)', 'Pressure-Gain Combustion Cycles']
  },
  {
    id: 'wiki-003', title: 'Pressure-Gain Combustion Cycles', category: 'Thermodynamics',
    lastUpdated: '2026-04-26', papersLinked: 12, status: 'published', linkedRunIds: ['run-001'],
    body: `**Pressure-Gain Combustion (PGC)** refers to cycles where combustion produces a net stagnation pressure rise, contrasting with conventional gas turbine combustors at nearly constant pressure.\n\n**Types of PGC Devices**\n- Rotating Detonation Engines (RDE)\n- Pulse Detonation Engines (PDE)\n- Wave Rotor Combustors\n- Shockless Explosion Combustors (SEC)\n\n**Thermodynamic Benefit**\nThe Humphrey cycle achieves 45–55% thermal efficiency vs. 30–40% for Brayton at the same temperature ratio.`,
    related: ['Rotating Detonation Engine (RDE)', 'Detonation Cell Width — Measurement Methods']
  },
  {
    id: 'wiki-004', title: 'Stratospheric Combustion Limits', category: 'Combustion',
    lastUpdated: '2026-04-28', papersLinked: 5, status: 'draft', linkedRunIds: ['run-001'],
    body: `Combustion at **stratospheric conditions** (15–35 km altitude) presents unique challenges: low ambient pressure (5–100 mbar), low temperature (−56°C to −70°C), and reduced oxidizer density.\n\n**Key Findings from Literature**\n- Lean blowout φ increases from 0.45 (sea level) to 0.72 (15 km) for Jet-A (Williams & Dryer, 2023)\n- RDE relight possible up to 12 km with H₂-air (Nakamura et al., 2023)\n- Scramjet auto-ignition fails below 30 km for pure H₂ (Turner et al., 2022)\n\nThis article is a draft — pending completion of run-001 evidence generation.`,
    related: ['Rotating Detonation Engine (RDE)', 'High-Altitude Scramjet Ignition']
  },
  {
    id: 'wiki-005', title: 'SMA Actuated Morphing Wings', category: 'Structures',
    lastUpdated: '2026-04-24', papersLinked: 15, status: 'published', linkedRunIds: ['run-002'],
    body: `**Shape Memory Alloy (SMA)** actuators enable continuous wing camber variation by exploiting the martensitic phase transformation of NiTi alloys.\n\n**SMA Advantages for Morphing**\n- High energy density (10× electromagnetic actuators)\n- Smooth, distributed actuation\n- Inherent overload protection via stress-induced transformation\n\n**Performance (from run-002 CFD validation)**\n- Camber range: ±6° trailing edge\n- Response time: 2.14 ± 0.08 s (90% CI)\n- Drag reduction: 8.3% at Mach 0.82\n- L/D improvement: 14% at design condition\n\n**Key References:** Sofla et al. (2023), Barbarino et al. (2022)`,
    related: ['Transonic Drag Polar Analysis', 'Adaptive Structures Overview']
  },
  {
    id: 'wiki-006', title: 'Transonic Drag Polar Analysis', category: 'Aerodynamics',
    lastUpdated: '2026-04-23', papersLinked: 19, status: 'published', linkedRunIds: ['run-002'],
    body: `**Transonic drag polar** analysis captures the complex shock-boundary layer interaction in the Mach 0.7–1.2 range where wave drag becomes significant.\n\n**CFD Methods for Transonic Flows**\n- RANS with SA or SST turbulence models\n- Structured grids with y+ < 1 near wall\n- Grid convergence via Richardson extrapolation (GCI < 1%)\n\n**Morphing Wing Impact (run-002)**\n24 camber configurations computed at Mach 0.82, Re=5×10⁶. Optimal camber (4° deflection) achieves L/D = 18.4 ± 0.3 (95% CI, Richardson extrapolation).`,
    related: ['SMA Actuated Morphing Wings', 'Computational Aeroelasticity']
  },
  {
    id: 'wiki-007', title: 'Hypersonic Boundary Layer Transition', category: 'Aerodynamics',
    lastUpdated: '2026-04-29', papersLinked: 11, status: 'published', linkedRunIds: ['run-003'],
    body: `**Hypersonic boundary layer transition** determines surface heating rates on re-entry vehicles. At Mach > 5, second-mode (Mack mode) instability dominates.\n\n**Key Parameters**\n- Wall temperature ratio (Tw/T₀): cooling stabilizes second mode\n- Nose radius: blunting delays transition\n- Roughness: ablation-induced protrusions accelerate transition\n\n**Current Understanding (from literature)**\n- Critical Tw/T₀ ≈ 0.32 for Mach 8 blunt cones (Fedorov et al., 2024)\n- Wall cooling stabilizes second mode when Tw/T₀ < 0.5 (Mack & Fedorov, 2023)\n- Roughness k/δ > 0.3 triggers hairpin vortices (Zhong & Wang, 2024)\n\n**run-003 Contribution:** First systematic wall-temperature DNS at Mach 8 on blunt cones — currently generating Level 2 evidence.`,
    related: ['Re-entry Aerothermodynamics', 'Wall Temperature Effects on Stability']
  },
  {
    id: 'wiki-008', title: 'ML Surrogates for Scramjet Optimization', category: 'Computational Methods',
    lastUpdated: '2026-04-30', papersLinked: 6, status: 'draft', linkedRunIds: ['run-004'],
    body: `**Machine learning surrogate models** enable rapid exploration of scramjet combustor design spaces that would be prohibitively expensive with full CFD.\n\n**Approaches in Literature**\n- Deep Gaussian Process: R²=0.97 for combustion efficiency (An et al., 2024)\n- Physics-Informed Neural Networks: 5% accuracy on detonation speed (Chen et al., 2024)\n- Active learning: reduces required CFD evaluations by 60%\n\nThis article is a draft — pending run-004 literature review completion.`,
    related: ['Supersonic Combustion in Scramjets']
  },
];

// ── HELPER: Get papers for a run ────────────────────────────────────────────
export function getPapersForRun(runId: string): Paper[] {
  return mockPapers.filter(p => p.linkedRunIds.includes(runId));
}

export function getGapsForRun(runId: string): ResearchGap[] {
  return mockResearchGaps.filter(g => g.linkedRunId === runId);
}

export function getCFDForRun(runId: string): CFDResult[] {
  return mockCFDResults.filter(c => c.linkedRunId === runId);
}

export function getLogsForRun(runId: string): AgentLog[] {
  return mockAgentLogs.filter(l => l.runId === runId);
}

export function getReviewsForRun(runId: string): ReviewComment[] {
  return mockReviewComments.filter(r => r.linkedRunId === runId);
}

export function getWikiForRun(runId: string): WikiArticle[] {
  return mockWikiArticles.filter(w => w.linkedRunIds.includes(runId));
}
