import { useState } from 'react';
import Sidebar, { type View } from './components/Sidebar';
import Dashboard from './components/Dashboard';
import PipelineView from './components/PipelineView';
import LiteratureView from './components/LiteratureView';
import NoveltyView from './components/NoveltyView';
import CFDView from './components/CFDView';
import ManuscriptView from './components/ManuscriptView';
import ReviewView from './components/ReviewView';
import WikiView from './components/WikiView';
import SettingsView from './components/SettingsView';
import { mockPipelineRuns, mockReviewComments } from './data/mockData';

export default function App() {
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [selectedRunId, setSelectedRunId] = useState<string | undefined>(undefined);

  const pendingGates = mockPipelineRuns.filter(r => r.status === 'gate_pending').length;
  const reviewFlags  = mockReviewComments.filter(c => !c.resolved && c.severity === 'major').length;

  const handleNavigate = (view: View, runId?: string) => {
    setActiveView(view);
    if (runId) setSelectedRunId(runId);
  };

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':  return <Dashboard onNavigate={handleNavigate} />;
      case 'pipeline':   return <PipelineView selectedRunId={selectedRunId} />;
      case 'literature': return <LiteratureView />;
      case 'novelty':    return <NoveltyView />;
      case 'cfd':        return <CFDView />;
      case 'manuscript': return <ManuscriptView />;
      case 'review':     return <ReviewView />;
      case 'wiki':       return <WikiView />;
      case 'settings':   return <SettingsView />;
      default:           return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-200 font-sans">
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        pendingGates={pendingGates}
        reviewFlags={reviewFlags}
      />
      <main className="flex-1 overflow-y-auto">
        {renderView()}
      </main>
    </div>
  );
}
