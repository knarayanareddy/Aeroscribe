import { useState } from 'react';
import { CheckCircle2, Loader2, AlertTriangle, Clock, Plus, X, ChevronDown, ChevronUp } from 'lucide-react';
import {
  mockPipelineRuns, mockAgentLogs, journalProfiles,
  type PipelineRun, type StageStatus, type AgentLog
} from '../data/mockData';

interface PipelineViewProps {
  selectedRunId?: string;
}

const stageStatusStyle: Record<StageStatus, string> = {
  completed:    'bg-emerald-500 border-emerald-400 text-white',
  running:      'bg-blue-500 border-blue-400 text-white ring-2 ring-blue-300/30 ring-offset-1 ring-offset-slate-900',
  gate_pending: 'bg-orange-400 border-orange-300 text-white ring-2 ring-orange-300/30 ring-offset-1 ring-offset-slate-900',
  pending:      'bg-slate-800 border-slate-600 text-slate-400',
  failed:       'bg-red-500 border-red-400 text-white',
  skipped:      'bg-slate-700 border-slate-600 text-slate-500',
};

const stageLineStyle: Record<StageStatus, string> = {
  completed: 'bg-emerald-500', running: 'bg-blue-500', gate_pending: 'bg-orange-400',
  pending: 'bg-slate-700', failed: 'bg-red-500', skipped: 'bg-slate-700',
};

const levelColor: Record<AgentLog['level'], string> = {
  success: 'text-emerald-400', warn: 'text-orange-400', error: 'text-red-400', info: 'text-blue-400',
};
const levelDot: Record<AgentLog['level'], string> = {
  success: 'bg-emerald-400', warn: 'bg-orange-400', error: 'bg-red-400', info: 'bg-blue-400',
};

export default function PipelineView({ selectedRunId }: PipelineViewProps) {
  const [runs, setRuns] = useState<PipelineRun[]>(mockPipelineRuns);
  const [activeRunId, setActiveRunId] = useState(selectedRunId ?? runs[0]?.id);
  const activeRun = runs.find(r => r.id === activeRunId) ?? runs[0];
  const [expandedStage, setExpandedStage] = useState<number>(activeRun?.currentStage ?? 0);
  const [showNewRun, setShowNewRun] = useState(false);
  const [newTopic, setNewTopic] = useState('');
  const [newJournal, setNewJournal] = useState('Journal of Propulsion and Power');

  const approveGate = (stageId: number) => {
    setRuns(prev => prev.map(r => {
      if (r.id !== activeRun.id) return r;
      const newStages = r.stages.map(s => {
        if (s.id === stageId) return { ...s, gateApproved: true, status: 'completed' as const };
        if (s.id === stageId + 1) return { ...s, status: 'running' as const };
        return s;
      });
      const nextStage = stageId + 1;
      return { ...r, stages: newStages, currentStage: nextStage, status: nextStage < 8 ? 'running' : 'completed' as const };
    }));
  };

  const createRun = () => {
    if (!newTopic.trim()) return;
    const id = `run-${Date.now()}`;
    const newRun: PipelineRun = {
      id, topic: newTopic, journal: newJournal, status: 'running',
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      currentStage: 0, noveltyScore: 0, paperTitle: 'Pending — TopicIntelligenceAgent running…',
      stages: [
        { id: 0, name: 'Topic Intelligence',       shortName: 'Topic',    status: 'running',  agentsActive: ['TopicIntelligenceAgent'], metrics: {} },
        { id: 1, name: 'Literature Archaeology',   shortName: 'Lit',      status: 'pending',  agentsActive: [], metrics: {} },
        { id: 2, name: 'Novelty Detection',        shortName: 'Novelty',  status: 'pending',  agentsActive: [], metrics: {} },
        { id: 3, name: 'Contribution Framing',     shortName: 'Framing',  status: 'pending',  agentsActive: [], metrics: {} },
        { id: 4, name: 'Evidence Generation (CFD)',shortName: 'CFD',      status: 'pending',  agentsActive: [], metrics: {} },
        { id: 5, name: 'Paper Synthesis',          shortName: 'Writing',  status: 'pending',  agentsActive: [], metrics: {} },
        { id: 6, name: 'Peer Review Council',      shortName: 'Review',   status: 'pending',  agentsActive: [], metrics: {} },
        { id: 7, name: 'Revision & Compliance',    shortName: 'Revision', status: 'pending',  agentsActive: [], metrics: {} },
        { id: 8, name: 'AeroWiki & Submission',    shortName: 'Submit',   status: 'pending',  agentsActive: [], metrics: {} },
      ],
    };
    setRuns(prev => [newRun, ...prev]);
    setActiveRunId(id);
    setShowNewRun(false);
    setNewTopic('');
  };

  const runLogs = mockAgentLogs.filter(l => l.runId === activeRun?.id).sort((a, b) => b.timestamp.localeCompare(a.timestamp));

  if (!activeRun) return null;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Pipeline Manager</h1>
          <p className="text-slate-400 text-sm mt-0.5">Monitor autonomous research pipeline execution · 9 stages · 11 HITL gates</p>
        </div>
        <button
          onClick={() => setShowNewRun(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
        >
          <Plus size={15} /> New Run
        </button>
      </div>

      {/* New Run Form */}
      {showNewRun && (
        <div className="bg-slate-800/80 border border-blue-500/40 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Launch New Pipeline Run</h3>
            <button onClick={() => setShowNewRun(false)} className="text-slate-400 hover:text-white"><X size={16} /></button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-400 text-xs font-medium mb-1.5">Research Topic</label>
              <input
                value={newTopic}
                onChange={e => setNewTopic(e.target.value)}
                placeholder="e.g. Scramjet fuel injection at Mach 7 cruise conditions"
                className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-slate-400 text-xs font-medium mb-1.5">Target Journal</label>
              <select
                value={newJournal}
                onChange={e => setNewJournal(e.target.value)}
                className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {journalProfiles.map(j => <option key={j.id}>{j.name}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button
              onClick={createRun}
              disabled={!newTopic.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-sm font-medium px-5 py-2 rounded-lg transition-colors"
            >
              Launch Pipeline
            </button>
            <button onClick={() => setShowNewRun(false)} className="text-slate-400 text-sm hover:text-white px-4 py-2">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Run list */}
        <div className="lg:col-span-1 space-y-2">
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-2">Runs</p>
          {runs.map((r) => (
            <button
              key={r.id}
              onClick={() => { setActiveRunId(r.id); setExpandedStage(r.currentStage); }}
              className={`w-full text-left px-3 py-2.5 rounded-lg border transition-all text-sm ${
                r.id === activeRun.id
                  ? 'bg-blue-600/20 border-blue-500/50 text-white'
                  : 'bg-slate-800/40 border-slate-700/40 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium truncate text-[11px]">{r.id}</span>
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${
                  r.status === 'completed' ? 'bg-emerald-400' :
                  r.status === 'running'   ? 'bg-blue-400 animate-pulse' :
                  r.status === 'gate_pending' ? 'bg-orange-400' : 'bg-slate-500'
                }`} />
              </div>
              <p className="text-[10px] text-slate-500 truncate mt-0.5">{r.topic.slice(0, 45)}…</p>
            </button>
          ))}
        </div>

        {/* Pipeline stages */}
        <div className="lg:col-span-2 space-y-3">
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">Stage Progress — {activeRun.id}</p>
          {/* Stage timeline */}
          <div className="relative">
            {activeRun.stages.map((stage, idx) => {
              const isExpanded = expandedStage === stage.id;
              const isPendingGate = stage.status === 'gate_pending';
              return (
                <div key={stage.id} className="relative flex gap-3">
                  {/* Connector line */}
                  {idx < activeRun.stages.length - 1 && (
                    <div className={`absolute left-4 top-9 w-0.5 h-full -z-0 ${stageLineStyle[stage.status]}`} style={{ height: 'calc(100% - 36px)' }} />
                  )}

                  {/* Stage circle */}
                  <div className={`relative z-10 w-8 h-8 flex-shrink-0 rounded-full border-2 flex items-center justify-center text-[10px] font-bold transition-all ${stageStatusStyle[stage.status]}`}>
                    {stage.status === 'completed'    ? <CheckCircle2 size={13} /> :
                     stage.status === 'running'      ? <Loader2 size={13} className="animate-spin" /> :
                     stage.status === 'gate_pending' ? <AlertTriangle size={13} /> :
                     stage.status === 'failed'       ? <X size={13} /> :
                     <Clock size={11} />}
                  </div>

                  {/* Stage content */}
                  <div className={`flex-1 mb-2 bg-slate-800/40 border rounded-lg overflow-hidden transition-all ${
                    isPendingGate ? 'border-orange-500/40' : 'border-slate-700/40'
                  }`}>
                    <button
                      className="w-full flex items-center justify-between px-3 py-2.5 hover:bg-slate-800/60 transition-colors"
                      onClick={() => setExpandedStage(isExpanded ? -1 : stage.id)}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-slate-200 text-sm font-medium">{stage.name}</span>
                        {stage.gateId && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium ${
                            stage.gateApproved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-orange-500/20 text-orange-400'
                          }`}>{stage.gateId}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        {stage.duration && <span className="text-slate-500 text-[10px]">{stage.duration}min</span>}
                        {isExpanded ? <ChevronUp size={13} className="text-slate-500" /> : <ChevronDown size={13} className="text-slate-500" />}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="px-3 pb-3 border-t border-slate-700/40 pt-2.5 space-y-2">
                        {/* Agents */}
                        {stage.agentsActive.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {stage.agentsActive.map(a => (
                              <span key={a} className="text-[10px] bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded-full">{a}</span>
                            ))}
                          </div>
                        )}
                        {/* Metrics */}
                        {stage.metrics && Object.keys(stage.metrics).length > 0 && (
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                            {Object.entries(stage.metrics).map(([k, v]) => (
                              <div key={k}>
                                <span className="text-slate-500 text-[10px]">{k}: </span>
                                <span className="text-slate-300 text-[10px] font-medium">{String(v)}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {/* Gate approval */}
                        {isPendingGate && (
                          <div className="mt-2">
                            <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-2.5 mb-2">
                              <p className="text-orange-300 text-[11px] font-medium mb-0.5">🔒 {stage.gateId} — Human-in-the-Loop Gate</p>
                              <p className="text-orange-200/70 text-[10px]">Review the Novelty Certificate and approve to proceed to Stage {stage.id + 1}.</p>
                            </div>
                            <button
                              onClick={() => approveGate(stage.id)}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium px-4 py-1.5 rounded-lg transition-colors flex items-center gap-1.5"
                            >
                              <CheckCircle2 size={12} /> Approve {stage.gateId}
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Agent logs */}
        <div className="lg:col-span-1">
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-2">Agent Logs</p>
          <div className="bg-slate-900 border border-slate-700/60 rounded-xl p-3 space-y-3 max-h-[600px] overflow-y-auto">
            {runLogs.length === 0 ? (
              <p className="text-slate-500 text-xs text-center py-6">No logs for this run</p>
            ) : runLogs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 border-b border-slate-800 pb-2 last:border-0 last:pb-0">
                <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1 ${levelDot[log.level]}`} />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className={`text-[9px] font-mono font-bold ${levelColor[log.level]}`}>{log.event}</span>
                    {log.costUsd && <span className="text-[9px] text-slate-500">${log.costUsd.toFixed(3)}</span>}
                  </div>
                  <p className="text-[10px] text-slate-400 font-mono">{log.agentId}</p>
                  <p className="text-[11px] text-slate-300 leading-snug mt-0.5">{log.message}</p>
                  <p className="text-[9px] text-slate-600 mt-0.5">{new Date(log.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
