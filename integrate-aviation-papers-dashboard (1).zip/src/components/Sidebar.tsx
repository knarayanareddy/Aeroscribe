import {
  LayoutDashboard, GitBranch, BookOpen, Sparkles,
  Wind, FileText, Users, BookMarked, Settings, ChevronRight
} from 'lucide-react';

export type View =
  | 'dashboard' | 'pipeline' | 'literature' | 'novelty'
  | 'cfd' | 'manuscript' | 'review' | 'wiki' | 'settings';

interface SidebarProps {
  activeView: View;
  setActiveView: (v: View) => void;
  pendingGates: number;
  reviewFlags: number;
}

const navItems: { id: View; label: string; icon: React.ReactNode; badgeKey?: 'gates' | 'reviews' }[] = [
  { id: 'dashboard',  label: 'Dashboard',       icon: <LayoutDashboard size={17} /> },
  { id: 'pipeline',   label: 'Pipeline',         icon: <GitBranch size={17} />,      badgeKey: 'gates'   },
  { id: 'literature', label: 'Literature',       icon: <BookOpen size={17} /> },
  { id: 'novelty',    label: 'Novelty',          icon: <Sparkles size={17} /> },
  { id: 'cfd',        label: 'Evidence / CFD',   icon: <Wind size={17} /> },
  { id: 'manuscript', label: 'Manuscript',       icon: <FileText size={17} /> },
  { id: 'review',     label: 'Peer Review',      icon: <Users size={17} />,          badgeKey: 'reviews' },
  { id: 'wiki',       label: 'AeroWiki',         icon: <BookMarked size={17} /> },
  { id: 'settings',   label: 'Settings',         icon: <Settings size={17} /> },
];

export default function Sidebar({ activeView, setActiveView, pendingGates, reviewFlags }: SidebarProps) {
  const getBadge = (key?: 'gates' | 'reviews') => {
    if (key === 'gates') return pendingGates;
    if (key === 'reviews') return reviewFlags;
    return 0;
  };

  return (
    <aside className="w-56 flex-shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col h-screen sticky top-0">
      {/* Logo */}
      <div className="px-4 pt-5 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-7 h-7 rounded-md bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white text-xs font-bold shadow-lg">A</div>
          <span className="text-white font-bold text-sm tracking-tight">AeroScribe</span>
        </div>
        <p className="text-slate-500 text-[10px] leading-tight pl-9">Autonomous Research Engine v1.0</p>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const badge = getBadge(item.badgeKey);
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <span className={isActive ? 'text-white' : 'text-slate-500 group-hover:text-slate-300'}>
                {item.icon}
              </span>
              <span className="flex-1 text-left">{item.label}</span>
              {badge > 0 && (
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                  isActive ? 'bg-white/20 text-white' : 'bg-orange-500 text-white'
                }`}>
                  {badge}
                </span>
              )}
              {isActive && <ChevronRight size={12} className="text-white/60" />}
            </button>
          );
        })}
      </nav>

      {/* Principles Footer */}
      <div className="px-3 pb-3 pt-2 border-t border-slate-800">
        <div className="bg-slate-800/60 rounded-lg px-3 py-2 space-y-1">
          {[
            { dot: 'bg-emerald-400', text: 'Zero Hallucination' },
            { dot: 'bg-blue-400',    text: 'SHA256 Registry' },
            { dot: 'bg-purple-400',  text: 'Human-in-the-Loop' },
          ].map((p) => (
            <div key={p.text} className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 rounded-full ${p.dot}`} />
              <span className="text-[10px] text-slate-400">{p.text}</span>
            </div>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2 px-1">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-[9px] font-bold">KN</div>
          <div>
            <p className="text-slate-300 text-[11px] font-medium">K. Narayana Reddy</p>
            <p className="text-slate-500 text-[10px]">Researcher</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
