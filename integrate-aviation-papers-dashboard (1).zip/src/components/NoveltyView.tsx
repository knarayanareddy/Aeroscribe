import { useState } from 'react';
import { mockResearchGaps, mockPipelineRuns } from '../data/mockData';
import { AlertTriangle, TrendingUp, Shield, Zap } from 'lucide-react';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

const riskColor = { low: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30', medium: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30', high: 'text-red-400 bg-red-400/10 border-red-400/30' };
const riskDot   = { low: 'bg-emerald-400', medium: 'bg-yellow-400', high: 'bg-red-400' };

const noveltyRadar = [
  { axis: 'Phenomena Gap',    score: 9.2 },
  { axis: 'Method Gap',       score: 8.4 },
  { axis: 'Parameter Range',  score: 7.8 },
  { axis: 'Temporal Frontier',score: 8.0 },
  { axis: 'Contradiction Res',score: 7.5 },
  { axis: 'Preemption Safety',score: 8.7 },
];

export default function NoveltyView() {
  const [activeRunId, setActiveRunId] = useState('run-001');
  const run = mockPipelineRuns.find(r => r.id === activeRunId)!;
  const gaps = mockResearchGaps.filter(g => g.runId === activeRunId);

  const noveltyStage = run.stages.find(s => s.id === 2);
  const noveltyScore = run.noveltyScore;

  const barData = gaps.map(g => ({ name: g.phenomena.slice(0, 28) + '…', score: g.noveltyScore }));

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Novelty Detection</h1>
          <p className="text-slate-400 text-sm mt-0.5">Stage 2 · Gap Matrix · Temporal Frontier · Contradiction Detection · Novelty Certificate</p>
        </div>
        <select
          value={activeRunId}
          onChange={e => setActiveRunId(e.target.value)}
          className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {mockPipelineRuns.filter(r => r.noveltyScore > 0).map(r => (
            <option key={r.id} value={r.id}>{r.id} — {r.topic.slice(0, 40)}…</option>
          ))}
        </select>
      </div>

      {/* Novelty Certificate Banner */}
      <div className={`border rounded-xl p-5 ${
        noveltyStage?.status === 'gate_pending' ? 'bg-orange-500/10 border-orange-500/40' :
        noveltyStage?.status === 'completed' ? 'bg-emerald-500/10 border-emerald-500/40' : 'bg-slate-800/50 border-slate-700'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield size={16} className="text-cyan-400" />
              <span className="text-white font-bold text-sm">Novelty Certificate</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                noveltyStage?.status === 'gate_pending' ? 'bg-orange-500/20 text-orange-400' :
                noveltyStage?.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'
              }`}>
                {noveltyStage?.gateApproved ? 'GATE-2 Approved' : noveltyStage?.status === 'gate_pending' ? 'Awaiting GATE-2' : 'Pending'}
              </span>
            </div>
            <p className="text-slate-300 text-sm font-medium">"{run.paperTitle}"</p>
            <p className="text-slate-400 text-xs mt-1">
              Recommended framing: <span className="text-cyan-300 italic">
                "First CFD-validated study of RDE combustion stability at stratospheric pressure conditions."
              </span>
            </p>
          </div>
          <div className="text-center flex-shrink-0">
            <div className="relative w-20 h-20">
              <svg viewBox="0 0 80 80" className="w-20 h-20 -rotate-90">
                <circle cx="40" cy="40" r="34" fill="none" stroke="#1e293b" strokeWidth="8" />
                <circle cx="40" cy="40" r="34" fill="none" stroke={noveltyScore >= 8 ? '#10b981' : noveltyScore >= 6 ? '#f59e0b' : '#ef4444'} strokeWidth="8"
                  strokeDasharray={`${(noveltyScore / 10) * 213.6} 213.6`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-black text-white leading-none">{noveltyScore}</span>
                <span className="text-[10px] text-slate-400">/10</span>
              </div>
            </div>
            <p className="text-slate-400 text-[10px] mt-1">Novelty Score</p>
          </div>
        </div>
        {noveltyStage?.metrics && (
          <div className="grid grid-cols-4 gap-3 mt-4 pt-4 border-t border-white/10">
            {[
              { label: 'Gaps Found',       value: noveltyStage.metrics.gapsIdentified },
              { label: 'Contradictions',   value: noveltyStage.metrics.contradictionsFound },
              { label: 'Preemption Risk',  value: noveltyStage.metrics.preemptionRisk },
              { label: 'arXiv Overlap',    value: '0 papers' },
            ].map(m => (
              <div key={m.label}>
                <p className="text-slate-500 text-[10px]">{m.label}</p>
                <p className="text-white text-sm font-bold">{String(m.value)}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Radar chart */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4">Novelty Dimensions Radar</h3>
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={noveltyRadar}>
              <PolarGrid stroke="#334155" />
              <PolarAngleAxis dataKey="axis" tick={{ fill: '#94a3b8', fontSize: 10 }} />
              <Radar name="Score" dataKey="score" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Gap scores bar */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
          <h3 className="text-white font-semibold text-sm mb-4">Research Gap Novelty Scores</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={barData} layout="vertical" margin={{ left: 0, right: 20, top: 0, bottom: 0 }}>
              <XAxis type="number" domain={[0, 10]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
              <YAxis type="category" dataKey="name" width={120} tick={{ fill: '#94a3b8', fontSize: 9 }} />
              <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                {barData.map((entry, index) => (
                  <Cell key={index} fill={entry.score >= 9 ? '#10b981' : entry.score >= 8 ? '#3b82f6' : entry.score >= 7 ? '#f59e0b' : '#ef4444'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Gap cards */}
      <div>
        <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
          <Zap size={14} className="text-yellow-400" /> Identified Research Gaps
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {gaps.map((gap, idx) => (
            <div key={gap.id} className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4">
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">{idx + 1}</span>
                  <p className="text-slate-200 text-sm font-medium leading-snug">{gap.phenomena}</p>
                </div>
                <span className={`flex-shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${riskColor[gap.competitorRisk]}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${riskDot[gap.competitorRisk]}`} />
                  {gap.competitorRisk} risk
                </span>
              </div>

              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-500 text-[10px]">Novelty Score</span>
                  <span className="text-white text-xs font-bold">{gap.noveltyScore}/10</span>
                </div>
                <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${gap.noveltyScore >= 9 ? 'bg-emerald-500' : gap.noveltyScore >= 8 ? 'bg-blue-500' : gap.noveltyScore >= 7 ? 'bg-yellow-500' : 'bg-red-500'}`}
                    style={{ width: `${gap.noveltyScore * 10}%` }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="bg-slate-900/60 rounded-lg p-2.5">
                  <p className="text-slate-500 text-[10px] font-medium mb-0.5">MISSING METHODOLOGY</p>
                  <p className="text-slate-300 text-[11px]">{gap.missingMethodology}</p>
                </div>
                <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-2.5">
                  <p className="text-blue-400 text-[10px] font-medium mb-0.5 flex items-center gap-1"><TrendingUp size={9} /> RECOMMENDATION</p>
                  <p className="text-slate-300 text-[11px]">{gap.recommendation}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contradiction detection */}
      <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
        <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
          <AlertTriangle size={14} className="text-orange-400" /> Contradiction Detection
        </h3>
        <div className="space-y-2">
          {[
            { papers: ['Andrus et al. 2023 (J. Prop. Power)', 'Nakamura et al. 2023 (J. Prop. Power)'], claim1: 'Wave speed increases monotonically with ambient back-pressure in annular RDEs', claim2: 'Wave speed exhibits non-monotonic behavior above p_back/p_inlet = 0.3 in toroidal geometry', score: 0.82 },
            { papers: ['Smith & Chen 2024 (Combust. Flame)', 'Ng & Zhang 2022 (Prog. Aero. Sci.)'], claim1: 'GRI-Mech 3.0 accurately predicts detonation cell width at p < 5 atm', claim2: 'Detailed mechanism accuracy degrades by >30% at p < 1 atm for H₂-air systems', score: 0.61 },
          ].map((c, i) => (
            <div key={i} className="bg-orange-500/5 border border-orange-500/20 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-orange-400 text-[10px] font-bold">CONTRADICTION #{i + 1}</span>
                <span className="text-orange-300 text-[10px]">Contradiction score: {c.score}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <p className="text-slate-500 text-[10px] mb-0.5">{c.papers[0]}</p>
                  <p className="text-slate-300 italic">"{c.claim1}"</p>
                </div>
                <div>
                  <p className="text-slate-500 text-[10px] mb-0.5">{c.papers[1]}</p>
                  <p className="text-slate-300 italic">"{c.claim2}"</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
