import { AlertTriangle, CheckCircle2, Loader2, Clock, TrendingUp, FileText, BookOpen, Cpu } from 'lucide-react';
import {
  mockPipelineRuns, mockWikiArticles, mockCFDResults, mockAgentLogs,
  type PipelineRun, type PipelineStatus
} from '../data/mockData';
import type { View } from './Sidebar';

interface DashboardProps {
  onNavigate: (view: View, runId?: string) => void;
}

const statusConfig: Record<PipelineStatus, { label: string; color: string; icon: React.ReactNode }> = {
  gate_pending: { label: 'Gate Pending', color: 'text-orange-400 bg-orange-400/10 border-orange-400/30', icon: <AlertTriangle size={11} /> },
  running:      { label: 'Running',      color: 'text-blue-400 bg-blue-400/10 border-blue-400/30',     icon: <Loader2 size={11} className="animate-spin" /> },
  completed:    { label: 'Completed',    color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30', icon: <CheckCircle2 size={11} /> },
  failed:       { label: 'Failed',       color: 'text-red-400 bg-red-400/10 border-red-400/30',        icon: <AlertTriangle size={11} /> },
  idle:         { label: 'Idle',         color: 'text-slate-400 bg-slate-400/10 border-slate-400/30',  icon: <Clock size={11} /> },
};

const stageBarColor: Record<string, string> = {
  completed:    'bg-emerald-500',
  running:      'bg-blue-500 animate-pulse',
  gate_pending: 'bg-orange-400',
  failed:       'bg-red-500',
  pending:      'bg-slate-700',
};

function RunCard({ run, onNavigate }: { run: PipelineRun; onNavigate: (view: View, runId?: string) => void }) {
  const cfg = statusConfig[run.status];
  const completedStages = run.stages.filter(s => s.status === 'completed').length;
  const progress = Math.round((completedStages / run.stages.length) * 100);
  const pendingGate = run.stages.find(s => s.status === 'gate_pending');

  return (
    <div
      className={`bg-slate-800/50 border rounded-xl p-4 cursor-pointer hover:bg-slate-800 transition-all group ${
        run.status === 'gate_pending' ? 'border-orange-500/40' : 'border-slate-700/60 hover:border-slate-600'
      }`}
      onClick={() => onNavigate('pipeline', run.id)}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${cfg.color}`}>
              {cfg.icon}{cfg.label}
            </span>
            <span className="text-slate-500 text-[11px]">{run.journal}</span>
          </div>
          <p className="text-slate-200 text-sm font-semibold leading-snug line-clamp-1 group-hover:text-white">{run.topic}</p>
          <p className="text-slate-400 text-[11px] mt-0.5 line-clamp-1 italic">"{run.paperTitle}"</p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-white font-bold text-lg leading-none">{completedStages}/9</p>
          <p className="text-slate-500 text-[10px]">stages</p>
          {run.noveltyScore > 0 && (
            <p className="text-cyan-400 text-xs font-bold mt-1">{run.noveltyScore}<span className="text-slate-500 font-normal">/10</span></p>
          )}
        </div>
      </div>

      {/* Stage progress bar */}
      <div className="flex gap-0.5 mb-2">
        {run.stages.map((s) => (
          <div
            key={s.id}
            className={`flex-1 h-1.5 rounded-full transition-all ${stageBarColor[s.status]}`}
            title={s.name}
          />
        ))}
      </div>
      <div className="flex items-center justify-between">
        <span className="text-slate-500 text-[10px]">
          {run.stages[run.currentStage]?.name || 'Complete'}
        </span>
        <span className="text-slate-400 text-[10px] font-medium">{progress}%</span>
      </div>

      {pendingGate && (
        <div className="mt-2 flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 rounded-lg px-2.5 py-1.5">
          <AlertTriangle size={12} className="text-orange-400 flex-shrink-0" />
          <span className="text-orange-300 text-[11px]">
            <strong>{pendingGate.gateId}</strong> awaiting approval
          </span>
        </div>
      )}
    </div>
  );
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const totalRuns = mockPipelineRuns.length;
  const completedRuns = mockPipelineRuns.filter(r => r.status === 'completed').length;
  const activeRuns = mockPipelineRuns.filter(r => r.status === 'running').length;
  const gateRuns = mockPipelineRuns.filter(r => r.status === 'gate_pending').length;
  const totalCost = mockAgentLogs.reduce((acc, l) => acc + (l.costUsd ?? 0), 0);
  const totalPapers = mockPipelineRuns.reduce((acc, r) => {
    const harvested = r.stages[1]?.metrics?.papersHarvested;
    return acc + (typeof harvested === 'number' ? harvested : 0);
  }, 0);

  const recentLogs = [...mockAgentLogs].sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 5);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Research Dashboard</h1>
        <p className="text-slate-400 text-sm mt-0.5">World's first autonomous aerospace research laboratory</p>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { icon: <GitBranch size={16} className="text-blue-400" />, label: 'Active Runs',      value: activeRuns,      sub: `${totalRuns} total`,              color: 'text-blue-400',    onClick: () => onNavigate('pipeline') },
          { icon: <AlertTriangle size={16} className="text-orange-400" />, label: 'Gates Pending', value: gateRuns,    sub: 'Awaiting approval',               color: 'text-orange-400',  onClick: () => onNavigate('pipeline') },
          { icon: <BookOpen size={16} className="text-cyan-400" />,   label: 'Papers Indexed',  value: totalPapers,     sub: '100% DOI verified',               color: 'text-cyan-400',    onClick: () => onNavigate('literature') },
          { icon: <CheckCircle2 size={16} className="text-emerald-400" />, label: 'Completed',  value: completedRuns,   sub: `$${totalCost.toFixed(2)} total cost`, color: 'text-emerald-400', onClick: () => onNavigate('pipeline') },
        ].map((kpi) => (
          <button
            key={kpi.label}
            onClick={kpi.onClick}
            className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 text-left hover:bg-slate-800 hover:border-slate-600 transition-all"
          >
            <div className="flex items-center gap-2 mb-2">{kpi.icon}<span className="text-slate-400 text-xs">{kpi.label}</span></div>
            <p className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</p>
            <p className="text-slate-500 text-[10px] mt-0.5">{kpi.sub}</p>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pipeline runs */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-white font-semibold text-sm">Pipeline Runs</h2>
            <button onClick={() => onNavigate('pipeline')} className="text-blue-400 text-xs hover:text-blue-300">View all →</button>
          </div>
          {mockPipelineRuns.map((run) => (
            <RunCard key={run.id} run={run} onNavigate={onNavigate} />
          ))}
        </div>

        {/* Right column */}
        <div className="space-y-4">
          {/* Core Principles */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
              <span>🧬</span> Core Principles
            </h3>
            <div className="space-y-2">
              {[
                { icon: '🚫', label: 'Zero Hallucination',  desc: 'Every number traces to VerifiedRegistry.' },
                { icon: '🔐', label: 'SHA256 Registry',     desc: 'Checksums on all computational evidence.' },
                { icon: '🎯', label: 'Journal Calibration', desc: 'AIAA, Elsevier, Acta Astronautica formats.' },
                { icon: '👤', label: 'Human-in-the-Loop',   desc: '11 mandatory researcher decision gates.' },
              ].map((p) => (
                <div key={p.label} className="flex gap-2.5">
                  <span className="text-sm mt-0.5">{p.icon}</span>
                  <div>
                    <p className="text-slate-200 text-xs font-medium">{p.label}</p>
                    <p className="text-slate-500 text-[10px]">{p.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent CFD */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
              <Cpu size={13} className="text-blue-400" /> Latest CFD Results
            </h3>
            <div className="space-y-2">
              {mockCFDResults.slice(0, 4).map((r) => (
                <div key={r.id} className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-300 text-[11px] font-medium truncate">{r.name}</p>
                    <p className="text-slate-500 text-[10px] font-mono">{r.sha256.slice(0, 12)}…</p>
                  </div>
                  <div className="text-right">
                    <p className="text-cyan-400 text-xs font-bold">{r.value} <span className="text-slate-500 font-normal text-[10px]">{r.unit}</span></p>
                    <p className="text-slate-500 text-[10px]">±{r.uncertainty}</p>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => onNavigate('cfd')} className="mt-2 text-blue-400 text-[11px] hover:text-blue-300">View all results →</button>
          </div>

          {/* AeroWiki */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
              <FileText size={13} className="text-purple-400" /> AeroWiki
            </h3>
            <div className="space-y-2">
              {mockWikiArticles.slice(0, 5).map((a) => (
                <div key={a.id} className="flex items-center gap-2 cursor-pointer group" onClick={() => onNavigate('wiki')}>
                  <div className="w-1.5 h-1.5 rounded-full bg-purple-500 flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-300 text-[11px] font-medium group-hover:text-white truncate">{a.title}</p>
                    <p className="text-slate-500 text-[10px]">{a.category} · {a.papersLinked} papers</p>
                  </div>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-medium ${a.status === 'published' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-600/50 text-slate-400'}`}>
                    {a.status}
                  </span>
                </div>
              ))}
            </div>
            <button onClick={() => onNavigate('wiki')} className="mt-2 text-purple-400 text-[11px] hover:text-purple-300">Open AeroWiki →</button>
          </div>

          {/* Agent activity */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingUp size={13} className="text-green-400" /> Agent Activity
            </h3>
            <div className="space-y-2">
              {recentLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5 ${
                    log.level === 'success' ? 'bg-emerald-400' :
                    log.level === 'warn'    ? 'bg-orange-400' :
                    log.level === 'error'   ? 'bg-red-400'    : 'bg-blue-400'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-slate-400 text-[10px] font-mono">{log.agentId}</p>
                    <p className="text-slate-300 text-[11px] leading-snug line-clamp-2">{log.message}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
function GitBranch({ size, className }: { size: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>;
}
