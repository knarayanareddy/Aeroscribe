import { useState } from 'react';
import { CheckCircle2, AlertTriangle, MessageSquare, User, Shield } from 'lucide-react';
import { mockReviewComments, mockPipelineRuns, type ReviewComment } from '../data/mockData';

const severityStyle: Record<ReviewComment['severity'], string> = {
  major:      'bg-red-500/20 text-red-400 border-red-500/30',
  minor:      'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  suggestion: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

const reviewerColors: Record<string, string> = {
  ReviewerAAgent:    'bg-purple-600',
  ReviewerBAgent:    'bg-blue-600',
  ReviewerCAgent:    'bg-cyan-600',
  ReviewerDAgent:    'bg-teal-600',
  MetaReviewerAgent: 'bg-orange-600',
};

const reviewerInitials: Record<string, string> = {
  ReviewerAAgent:    'A',
  ReviewerBAgent:    'B',
  ReviewerCAgent:    'C',
  ReviewerDAgent:    'D',
  MetaReviewerAgent: 'M',
};

const reviewerDescriptions: Record<string, string> = {
  ReviewerAAgent:    'Methodology — CFD setup, uncertainty quantification, numerical methods',
  ReviewerBAgent:    'Literature — Prior work engagement, citation accuracy, DOI verification',
  ReviewerCAgent:    'Physics — Governing equations, physical consistency, visualization',
  ReviewerDAgent:    'Compliance — Journal format, word count, AIAA style, AI disclosure',
  MetaReviewerAgent: 'Meta-Review — Synthesizes all reviewer inputs, final recommendation',
};

export default function ReviewView() {
  const [activeRunId, setActiveRunId] = useState('run-001');
  const [filterSeverity, setFilterSeverity] = useState<'all' | ReviewComment['severity']>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'resolved'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [comments, setComments] = useState<ReviewComment[]>(mockReviewComments);

  const runComments = comments.filter(c => c.runId === activeRunId);
  const filtered = runComments.filter(c => {
    const matchSev = filterSeverity === 'all' || c.severity === filterSeverity;
    const matchStatus = filterStatus === 'all' || (filterStatus === 'open' ? !c.resolved : c.resolved);
    return matchSev && matchStatus;
  });

  const resolveComment = (id: string) => {
    setComments(prev => prev.map(c => c.id === id ? { ...c, resolved: true, response: c.response ?? 'Addressed per reviewer feedback.' } : c));
  };

  const stats = {
    major:     runComments.filter(c => c.severity === 'major').length,
    minor:     runComments.filter(c => c.severity === 'minor').length,
    suggestion: runComments.filter(c => c.severity === 'suggestion').length,
    resolved:  runComments.filter(c => c.resolved).length,
    total:     runComments.length,
  };

  const run = mockPipelineRuns.find(r => r.id === activeRunId)!;
  const reviewStage = run?.stages.find(s => s.id === 6);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Peer Review Council</h1>
          <p className="text-slate-400 text-sm mt-0.5">Stage 6 · 4 specialized AI reviewers + MetaReviewer · GATE-6 required for manuscript revision</p>
        </div>
        <select
          value={activeRunId}
          onChange={e => setActiveRunId(e.target.value)}
          className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {mockPipelineRuns.map(r => <option key={r.id} value={r.id}>{r.id} — {r.topic.slice(0, 40)}…</option>)}
        </select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-5 gap-2">
        {[
          { label: 'Major',     value: stats.major,      color: 'text-red-400',     bg: 'bg-red-500/10 border-red-500/20' },
          { label: 'Minor',     value: stats.minor,      color: 'text-yellow-400',  bg: 'bg-yellow-500/10 border-yellow-500/20' },
          { label: 'Suggestion',value: stats.suggestion, color: 'text-blue-400',    bg: 'bg-blue-500/10 border-blue-500/20' },
          { label: 'Resolved',  value: stats.resolved,   color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' },
          { label: 'Total',     value: stats.total,      color: 'text-white',       bg: 'bg-slate-700/40 border-slate-600/40' },
        ].map(s => (
          <div key={s.label} className={`border rounded-xl p-3 text-center ${s.bg}`}>
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-slate-500 text-[10px]">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Reviewer Council */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {Object.entries(reviewerDescriptions).map(([agentId, desc]) => {
          const agentComments = runComments.filter(c => c.reviewerId === agentId);
          const openCount = agentComments.filter(c => !c.resolved).length;
          return (
            <div key={agentId} className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-3">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-7 h-7 rounded-full ${reviewerColors[agentId]} flex items-center justify-center text-white text-[11px] font-bold`}>
                  {reviewerInitials[agentId]}
                </div>
                <div>
                  <p className="text-slate-200 text-[11px] font-semibold">{agentId.replace('Agent', '').replace('Meta', 'Meta-')}</p>
                  {openCount > 0 && <p className="text-orange-400 text-[9px]">{openCount} open</p>}
                </div>
              </div>
              <p className="text-slate-500 text-[10px] leading-snug">{desc.split('—')[0].trim()}</p>
            </div>
          );
        })}
      </div>

      {/* Stage info */}
      {reviewStage && (
        <div className={`border rounded-xl px-4 py-3 flex items-center gap-3 ${
          reviewStage.status === 'completed' ? 'bg-emerald-500/10 border-emerald-500/30' :
          reviewStage.status === 'running' ? 'bg-blue-500/10 border-blue-500/30' :
          'bg-slate-800/50 border-slate-700/60'
        }`}>
          <Shield size={16} className="text-blue-400 flex-shrink-0" />
          <div>
            <p className="text-white text-sm font-semibold">Stage 6: Peer Review Council — {reviewStage.status}</p>
            {reviewStage.metrics && Object.keys(reviewStage.metrics).length > 0 && (
              <div className="flex gap-4 mt-0.5">
                {Object.entries(reviewStage.metrics).map(([k, v]) => (
                  <span key={k} className="text-slate-400 text-[11px]">{k}: <strong className="text-white">{String(v)}</strong></span>
                ))}
              </div>
            )}
          </div>
          {reviewStage.gateId && !reviewStage.gateApproved && (
            <div className="ml-auto">
              <span className="bg-orange-500/20 text-orange-400 border border-orange-500/30 text-[10px] px-2 py-1 rounded-full">{reviewStage.gateId} Pending</span>
            </div>
          )}
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="flex gap-1">
          {(['all', 'major', 'minor', 'suggestion'] as const).map(s => (
            <button
              key={s}
              onClick={() => setFilterSeverity(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filterSeverity === s ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}
            >{s.charAt(0).toUpperCase() + s.slice(1)}</button>
          ))}
        </div>
        <div className="flex gap-1">
          {(['all', 'open', 'resolved'] as const).map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filterStatus === s ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}
            >{s.charAt(0).toUpperCase() + s.slice(1)}</button>
          ))}
        </div>
      </div>

      {/* Comments */}
      {filtered.length === 0 && (
        <div className="text-center py-10 text-slate-500">
          <MessageSquare size={28} className="mx-auto mb-2 opacity-30" />
          <p>No review comments match your filters.</p>
        </div>
      )}
      <div className="space-y-3">
        {filtered.map((comment) => (
          <div
            key={comment.id}
            className={`bg-slate-800/40 border rounded-xl overflow-hidden transition-all ${
              comment.resolved ? 'border-slate-700/40 opacity-70' : 'border-slate-700/60'
            }`}
          >
            <div
              className="px-4 py-3 cursor-pointer hover:bg-slate-800/60"
              onClick={() => setExpandedId(expandedId === comment.id ? null : comment.id)}
            >
              <div className="flex items-start gap-3">
                <div className={`w-7 h-7 rounded-full ${reviewerColors[comment.reviewerId]} flex items-center justify-center text-white text-[11px] font-bold flex-shrink-0 mt-0.5`}>
                  {reviewerInitials[comment.reviewerId]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-slate-300 text-xs font-semibold">{comment.reviewerName}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${severityStyle[comment.severity]}`}>{comment.severity}</span>
                    <span className="text-slate-500 text-[10px]">→ {comment.section}</span>
                    {comment.resolved && <span className="flex items-center gap-1 text-emerald-400 text-[10px]"><CheckCircle2 size={9} />Resolved</span>}
                  </div>
                  <p className="text-slate-300 text-sm line-clamp-2">{comment.comment}</p>
                </div>
                <div className="flex-shrink-0">
                  {comment.resolved
                    ? <CheckCircle2 size={16} className="text-emerald-400" />
                    : <AlertTriangle size={16} className="text-orange-400" />}
                </div>
              </div>
            </div>

            {expandedId === comment.id && (
              <div className="border-t border-slate-700/40 px-4 pb-4 pt-3 space-y-3">
                <div className="bg-slate-900/60 rounded-lg p-3">
                  <div className="flex items-center gap-1 mb-1">
                    <User size={11} className="text-slate-500" />
                    <span className="text-slate-500 text-[10px] font-medium">REVIEWER COMMENT</span>
                  </div>
                  <p className="text-slate-300 text-sm leading-relaxed">{comment.comment}</p>
                </div>
                {comment.response ? (
                  <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3">
                    <div className="flex items-center gap-1 mb-1">
                      <CheckCircle2 size={11} className="text-emerald-400" />
                      <span className="text-emerald-400 text-[10px] font-medium">AUTHOR RESPONSE</span>
                    </div>
                    <p className="text-slate-300 text-sm leading-relaxed">{comment.response}</p>
                  </div>
                ) : !comment.resolved && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => resolveComment(comment.id)}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium px-4 py-1.5 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <CheckCircle2 size={11} /> Mark Resolved
                    </button>
                    <span className="text-slate-500 text-[10px]">RevisionAgent will draft response-to-reviewers for GATE-7</span>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
