import { useState } from 'react';
import { CheckCircle2, AlertTriangle, Shield, Cpu, BookOpen, Zap } from 'lucide-react';
import { journalProfiles } from '../data/mockData';

export default function SettingsView() {
  const [model, setModel] = useState('claude-opus-4-5');
  const [semanticKey, setSemanticKey] = useState('••••••••••••••••••');
  const [maxContext, setMaxContext] = useState('stage1');
  const [hitlEnabled, setHitlEnabled] = useState(true);
  const [verifiedOnly, setVerifiedOnly] = useState(true);
  const [aiDisclosure, setAiDisclosure] = useState(true);
  const [activeJournals, setActiveJournals] = useState<string[]>(['jpp', 'aiaa', 'ast']);

  const toggleJournal = (id: string) => {
    setActiveJournals(prev => prev.includes(id) ? prev.filter(j => j !== id) : [...prev, id]);
  };

  const contextBudgets: Record<string, { mcps: number; tools: number; desc: string }> = {
    stage0: { mcps: 4,  tools: 20, desc: 'Topic Intelligence — minimal' },
    stage1: { mcps: 15, tools: 80, desc: 'Literature — max MCPs (RULE-024)' },
    stage4: { mcps: 8,  tools: 40, desc: 'Evidence — CFD tools only (RULE-024)' },
    stage5: { mcps: 6,  tools: 30, desc: 'Writing — LaTeX tools only (RULE-024)' },
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 text-sm mt-0.5">Pipeline configuration · Agent rules · Journal profiles · Integrity controls</p>
      </div>

      {/* Constitutional Rules summary */}
      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Shield size={16} className="text-blue-400" />
          <h3 className="text-white font-semibold text-sm">CLAUDE.md — Active Constitutional Rules</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {[
            { rule: 'RULE-001', desc: 'Never fabricate numerical results — VerifiedRegistry required', ok: true },
            { rule: 'RULE-002', desc: 'Never add unverified references — DOI resolution mandatory', ok: true },
            { rule: 'RULE-003', desc: 'Never bypass HITL gates — researcher approval required', ok: hitlEnabled },
            { rule: 'RULE-004', desc: 'AI systems never listed as paper authors — AI disclosure always included', ok: aiDisclosure },
            { rule: 'RULE-031', desc: 'All quantitative claims: VALUE ± UQ (CI%, METHOD)', ok: verifiedOnly },
            { rule: 'RULE-041', desc: 'CFD outputs SHA256-checksummed before manuscript use', ok: verifiedOnly },
            { rule: 'RULE-043', desc: 'VerifiedRegistry is append-only — no DELETE/UPDATE', ok: true },
          ].map(r => (
            <div key={r.rule} className="flex items-start gap-2">
              {r.ok
                ? <CheckCircle2 size={12} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                : <AlertTriangle size={12} className="text-orange-400 flex-shrink-0 mt-0.5" />}
              <div>
                <span className="text-blue-300 text-[10px] font-mono font-bold">{r.rule}</span>
                <p className="text-slate-400 text-[10px]">{r.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* AI Model */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 space-y-4">
          <h3 className="text-white font-semibold text-sm flex items-center gap-2"><Cpu size={14} className="text-blue-400" /> AI Model Configuration</h3>
          <div>
            <label className="block text-slate-400 text-xs font-medium mb-1.5">Primary Model (Orchestrators)</label>
            <select value={model} onChange={e => setModel(e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="claude-opus-4-5">claude-opus-4-5 (Recommended)</option>
              <option value="claude-sonnet-4-5">claude-sonnet-4-5 (Fast)</option>
            </select>
            <p className="text-slate-500 text-[10px] mt-1">Fast model: claude-haiku-3-5 (auto-selected for tool calls)</p>
          </div>
          <div>
            <label className="block text-slate-400 text-xs font-medium mb-1.5">Semantic Scholar API Key</label>
            <input value={semanticKey} onChange={e => setSemanticKey(e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <p className="text-slate-500 text-[10px] mt-1">Stored in .env — never in source code (RULE-040)</p>
          </div>
          <div>
            <label className="block text-slate-400 text-xs font-medium mb-1.5">Context Budget Profile (RULE-024)</label>
            <select value={maxContext} onChange={e => setMaxContext(e.target.value)}
              className="w-full bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              {Object.entries(contextBudgets).map(([k, v]) => (
                <option key={k} value={k}>{v.desc} — {v.mcps} MCPs, {v.tools} tools</option>
              ))}
            </select>
          </div>
        </div>

        {/* Integrity Controls */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 space-y-4">
          <h3 className="text-white font-semibold text-sm flex items-center gap-2"><Shield size={14} className="text-emerald-400" /> Integrity Controls</h3>
          {[
            { label: 'Human-in-the-Loop Gates (RULE-003)', desc: '11 mandatory gates — cannot auto-approve', value: hitlEnabled, onChange: setHitlEnabled, immutable: true },
            { label: 'VerifiedRegistry Required (RULE-041)', desc: 'Block manuscript use without SHA256 checksum', value: verifiedOnly, onChange: setVerifiedOnly, immutable: false },
            { label: 'AI Authorship Prohibition (RULE-004)', desc: 'AI systems never listed as paper authors', value: aiDisclosure, onChange: setAiDisclosure, immutable: true },
          ].map(ctrl => (
            <div key={ctrl.label} className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <p className="text-slate-200 text-xs font-medium">{ctrl.label}</p>
                <p className="text-slate-500 text-[10px]">{ctrl.desc}</p>
                {ctrl.immutable && <p className="text-orange-400 text-[9px] mt-0.5">Constitutional — cannot be disabled</p>}
              </div>
              <button
                onClick={() => !ctrl.immutable && ctrl.onChange(!ctrl.value)}
                className={`relative w-10 h-6 rounded-full transition-colors flex-shrink-0 ${ctrl.value ? 'bg-emerald-500' : 'bg-slate-600'} ${ctrl.immutable ? 'opacity-80 cursor-not-allowed' : 'cursor-pointer'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${ctrl.value ? 'left-5' : 'left-1'}`} />
              </button>
            </div>
          ))}

          <div className="pt-2 border-t border-slate-700/40">
            <p className="text-slate-400 text-xs font-medium mb-2">Exponential Backoff (RULE-042)</p>
            <div className="grid grid-cols-5 gap-1">
              {[0, 2, 4, 8, 16].map((s, i) => (
                <div key={i} className="text-center">
                  <div className={`h-6 rounded flex items-end justify-center text-[9px] font-bold text-slate-900 ${i === 0 ? 'bg-emerald-400' : i < 4 ? 'bg-yellow-400' : 'bg-red-400'}`} style={{ paddingBottom: 2 }}>
                    {i === 0 ? 'Now' : `${s}s`}
                  </div>
                  <p className="text-slate-600 text-[9px] mt-0.5">Attempt {i + 1}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Journal Profiles */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 md:col-span-2">
          <h3 className="text-white font-semibold text-sm flex items-center gap-2 mb-3"><BookOpen size={14} className="text-cyan-400" /> Active Journal Profiles</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {journalProfiles.map(j => (
              <div
                key={j.id}
                onClick={() => toggleJournal(j.id)}
                className={`cursor-pointer border rounded-xl p-3 transition-all ${activeJournals.includes(j.id) ? 'bg-blue-500/10 border-blue-500/40' : 'bg-slate-900/40 border-slate-700/40 opacity-50'}`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <p className="text-slate-200 text-[11px] font-semibold leading-snug">{j.name}</p>
                  {activeJournals.includes(j.id) && <CheckCircle2 size={13} className="text-blue-400 flex-shrink-0" />}
                </div>
                <div className="space-y-0.5 text-[10px]">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Publisher</span>
                    <span className="text-slate-300">{j.publisher}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Impact Factor</span>
                    <span className="text-cyan-400 font-bold">{j.impactFactor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Acceptance</span>
                    <span className="text-slate-300">{j.acceptanceRate}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Review Time</span>
                    <span className="text-slate-300">{j.reviewWeeks}wk</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-0.5">
                  {j.scopeKeywords.slice(0, 3).map(kw => (
                    <span key={kw} className="text-[9px] bg-slate-700/60 text-slate-400 px-1.5 py-0.5 rounded">{kw}</span>
                  ))}
                  {j.scopeKeywords.length > 3 && <span className="text-[9px] text-slate-500">+{j.scopeKeywords.length - 3}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Agent Registry */}
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 md:col-span-2">
          <h3 className="text-white font-semibold text-sm flex items-center gap-2 mb-3"><Zap size={14} className="text-yellow-400" /> Agent Registry (AGENTS.md)</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px]">
              <thead>
                <tr className="border-b border-slate-700/60">
                  {['Agent ID', 'Stage', 'Primary Tool', 'Max Runtime', 'Spawn Depth'].map(h => (
                    <th key={h} className="text-left text-slate-500 font-medium pb-2 pr-4">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/30">
                {[
                  { id: 'TopicIntelligenceAgent',   stage: '0',   tool: 'journal_profile_db',      runtime: '15 min', depth: '1' },
                  { id: 'LiteratureHarvestAgent',    stage: '1',   tool: 'semantic_scholar_api',     runtime: '4 hrs',  depth: '1' },
                  { id: 'CitationGraphAgent',        stage: '1',   tool: 'gitnexus_indexer',         runtime: '2 hrs',  depth: '1' },
                  { id: 'LiteratureRerankerAgent',   stage: '1',   tool: 'llm_reranker',             runtime: '1 hr',   depth: '1' },
                  { id: 'NoveltyDetectionAgent',     stage: '2',   tool: 'gap_matrix_builder',       runtime: '1 hr',   depth: '1' },
                  { id: 'ContributionFramingAgent',  stage: '3',   tool: 'contribution_generator',   runtime: '30 min', depth: '1' },
                  { id: 'CFDSolverAgent',            stage: '4',   tool: 'cfd_solver_runner',        runtime: '15 min/run', depth: '1' },
                  { id: 'SectionWriterAgent',        stage: '5',   tool: 'hierarchical_writer',      runtime: '2 hrs',  depth: '1' },
                  { id: 'MetaReviewerAgent',         stage: '6',   tool: 'meta_review_synthesizer',  runtime: '30 min', depth: '1' },
                  { id: 'RevisionAgent',             stage: '7',   tool: 'revision_writer',          runtime: '2 hrs',  depth: '1' },
                  { id: 'WikiCompilerAgent',         stage: '8',   tool: 'wiki_builder',             runtime: '1 hr',   depth: '1' },
                ].map(agent => (
                  <tr key={agent.id}>
                    <td className="py-1.5 pr-4 text-slate-300 font-mono">{agent.id}</td>
                    <td className="py-1.5 pr-4 text-slate-400">{agent.stage}</td>
                    <td className="py-1.5 pr-4 text-cyan-400 font-mono text-[10px]">{agent.tool}</td>
                    <td className="py-1.5 pr-4 text-slate-400">{agent.runtime}</td>
                    <td className="py-1.5 text-slate-500">{agent.depth}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-slate-600 text-[10px] mt-2 italic">max_spawn_depth: 3 enforced globally · No agent spawns sub-agents deeper than 3 levels (AGENTS.md)</p>
        </div>
      </div>
    </div>
  );
}
