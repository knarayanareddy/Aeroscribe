import { useState, useMemo } from 'react';
import { Search, ExternalLink, Filter, Star } from 'lucide-react';
import { mockPapers, mockPipelineRuns, type Paper } from '../data/mockData';

export default function LiteratureView() {
  const [search, setSearch] = useState('');
  const [minScore, setMinScore] = useState(0);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [activeRunId, setActiveRunId] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    mockPapers.forEach(p => p.tags.forEach(t => tags.add(t)));
    return Array.from(tags).sort();
  }, []);

  const filtered = useMemo(() => mockPapers.filter(p => {
    const matchRun = activeRunId === 'all' || p.runId === activeRunId;
    const matchSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.authors.toLowerCase().includes(search.toLowerCase());
    const matchScore = p.relevanceScore >= minScore;
    const matchTag = !activeTag || p.tags.includes(activeTag);
    return matchRun && matchSearch && matchScore && matchTag;
  }), [search, minScore, activeTag, activeRunId]);

  const stats = {
    total: filtered.length,
    avgRelevance: filtered.length ? (filtered.reduce((a, p) => a + p.relevanceScore, 0) / filtered.length).toFixed(1) : '—',
    avgCitations: filtered.length ? Math.round(filtered.reduce((a, p) => a + p.citationCount, 0) / filtered.length) : 0,
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Literature Archaeology</h1>
        <p className="text-slate-400 text-sm mt-0.5">Stage 1 output · DOI-verified via Crossref · Zero hallucinated references (RULE-002)</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Papers Shown',   value: stats.total,         icon: '📄', color: 'text-blue-400' },
          { label: 'DOI Verified',   value: '100%',              icon: '✅', color: 'text-emerald-400' },
          { label: 'Avg Relevance',  value: stats.avgRelevance,  icon: '⭐', color: 'text-yellow-400' },
          { label: 'Avg Citations',  value: stats.avgCitations,  icon: '🔗', color: 'text-cyan-400' },
        ].map(s => (
          <div key={s.label} className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-3 text-center">
            <p className="text-lg">{s.icon}</p>
            <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-slate-500 text-[10px]">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4 space-y-3">
        <div className="flex flex-wrap gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-48">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search title, authors…"
              className="w-full bg-slate-900 border border-slate-600 rounded-lg pl-8 pr-3 py-2 text-slate-200 text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          {/* Run filter */}
          <select
            value={activeRunId}
            onChange={e => setActiveRunId(e.target.value)}
            className="bg-slate-900 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Runs</option>
            {mockPipelineRuns.map(r => <option key={r.id} value={r.id}>{r.id} — {r.topic.slice(0, 30)}…</option>)}
          </select>
          {/* Min score */}
          <div className="flex items-center gap-2">
            <Filter size={13} className="text-slate-400" />
            <span className="text-slate-400 text-xs">Min score:</span>
            <select
              value={minScore}
              onChange={e => setMinScore(Number(e.target.value))}
              className="bg-slate-900 border border-slate-600 rounded-lg px-2 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {[0, 7, 7.5, 8, 8.5, 9].map(v => <option key={v} value={v}>{v}+</option>)}
            </select>
          </div>
        </div>
        {/* Tags */}
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveTag(null)}
            className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors ${!activeTag ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}
          >All</button>
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setActiveTag(activeTag === tag ? null : tag)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-colors ${activeTag === tag ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-400 hover:bg-slate-600'}`}
            >{tag}</button>
          ))}
        </div>
      </div>

      {/* Paper list */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <div className="text-center py-12 text-slate-500">No papers match your filters.</div>
        )}
        {filtered.map((paper: Paper) => (
          <div
            key={paper.id}
            className="bg-slate-800/40 border border-slate-700/60 rounded-xl overflow-hidden hover:border-slate-600 transition-all cursor-pointer"
            onClick={() => setExpandedId(expandedId === paper.id ? null : paper.id)}
          >
            <div className="px-4 py-3">
              <div className="flex items-start gap-3">
                {/* Score badge */}
                <div className="flex-shrink-0 flex flex-col items-center bg-slate-900 border border-slate-700 rounded-lg px-2 py-1.5 min-w-[44px]">
                  <Star size={10} className="text-yellow-400 mb-0.5" />
                  <span className="text-yellow-400 text-sm font-bold">{paper.relevanceScore.toFixed(1)}</span>
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-slate-100 text-sm font-semibold leading-snug">{paper.title}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-slate-400 text-[11px]">{paper.authors}</span>
                    <span className="text-slate-600 text-[11px]">·</span>
                    <span className="text-cyan-400 text-[11px] font-medium">{paper.journal}</span>
                    <span className="text-slate-600 text-[11px]">·</span>
                    <span className="text-slate-400 text-[11px]">{paper.year}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {paper.tags.map(t => (
                      <span key={t} className="text-[9px] bg-slate-700/60 text-slate-400 px-1.5 py-0.5 rounded">{t}</span>
                    ))}
                  </div>
                </div>

                <div className="flex-shrink-0 text-right space-y-0.5">
                  <p className="text-slate-400 text-[10px]">{paper.citationCount} citations</p>
                  <a
                    href={`https://doi.org/${paper.doi}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={e => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-blue-400 text-[10px] hover:text-blue-300"
                  >
                    DOI <ExternalLink size={9} />
                  </a>
                  <div className="flex items-center justify-end gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span className="text-[9px] text-slate-500">Verified</span>
                  </div>
                </div>
              </div>
            </div>

            {expandedId === paper.id && (
              <div className="px-4 pb-4 border-t border-slate-700/40 pt-3">
                <p className="text-slate-400 text-[12px] leading-relaxed">{paper.abstract}</p>
                <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-500">
                  <span className="font-mono bg-slate-900 px-2 py-0.5 rounded">DOI: {paper.doi}</span>
                  <span className="text-emerald-400">✓ Crossref verified</span>
                  <span>Run: {paper.runId}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
