import { useState } from 'react';
import { CheckCircle2, AlertCircle, FileText, Code2, ChevronRight } from 'lucide-react';
import { manuscriptSectionsRun002, mockPipelineRuns, type ManuscriptSection } from '../data/mockData';

const statusStyle: Record<ManuscriptSection['status'], string> = {
  complete:   'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  in_review:  'bg-blue-500/20 text-blue-400 border-blue-500/30',
  draft:      'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  pending:    'bg-slate-700/60 text-slate-500 border-slate-600/30',
};

const latexSnippet = `\\documentclass[conf]{new-aiaa}
\\usepackage{amsmath}
\\title{Variable Camber Wing via SMA Actuation: CFD Validation \\\\
and Transonic Drag Polar Analysis}
\\author{K. Narayana Reddy\\thanks{Researcher, AeroScribe.}}
\\affil{AeroScribe Autonomous Research Engine}

\\begin{document}
\\maketitle

\\begin{abstract}
Variable camber morphing wings driven by embedded shape memory alloy (SMA) 
actuators offer passive aerodynamic adaptation to off-design transonic 
conditions. This study presents a coupled FSI investigation of a NiTi 
SMA-actuated trailing-edge section at $M = 0.76$--$0.82$...
A drag reduction of $\\Delta C_D = -0.00312 \\pm 0.00018$ (95\\% CI, 
RANS $k$-$\\omega$ SST) is predicted at the cruise design point.
\\end{abstract}

\\section{Introduction}
Modern commercial transport aircraft operate across a wide range of lift 
coefficients during a typical mission profile~\\cite{Nguyen2022}...

\\section{Methodology}
\\subsection{Aerodynamic Solver}
All computations use DLR TAU with $k$-$\\omega$ SST turbulence closure.
Three structured grids are generated ($3.2$M, $12.4$M, $49.6$M cells)
with $y^+ < 1$ on the airfoil surface. Grid convergence is assessed by 
Richardson extrapolation, yielding $\\mathrm{GCI}_{23} = 1.2\\%$ on $C_D$.

\\begin{equation}
  \\frac{L}{D} = 18.4 \\pm 0.3 \\quad (95\\%\\;\\mathrm{CI},\\;
  \\text{Richardson extrapolation})
\\end{equation}

% VerifiedRegistry SHA256: a3f8c1d2e4b69f01...
% VerifiedRegistry SHA256: b7e2a9c0f3d12a88...

\\bibliography{aeroscribe-refs}
\\end{document}`;

const aiaaCompliance = [
  { label: 'Abstract ≤ 250 words',         ok: true,  detail: '248 words' },
  { label: 'Nomenclature section present',  ok: true,  detail: '' },
  { label: 'AIAA numeric citation style',   ok: true,  detail: '' },
  { label: 'Uncertainty on all values',     ok: false, detail: '0 values missing (fixed)' },
  { label: 'AI disclosure statement',       ok: true,  detail: 'Included per RULE-004' },
  { label: 'Figure captions complete',      ok: true,  detail: 'All 12 figures' },
  { label: 'SHA256 refs in LaTeX comments', ok: true,  detail: 'RULE-041 compliant' },
  { label: 'Abstract 4-sentence structure', ok: true,  detail: 'RULE-034 compliant' },
];

const abstractStructure = [
  { n: 'S1', label: 'Problem + Motivation', ok: true, text: 'Variable camber morphing wings offer passive aerodynamic adaptation…' },
  { n: 'S2', label: 'Approach / Method',    ok: true, text: 'Coupled FSI investigation of NiTi SMA trailing-edge…' },
  { n: 'S3', label: 'Key Quantitative Result', ok: true, text: 'ΔC_D = −0.00312 ± 0.00018 (95% CI) at cruise design point' },
  { n: 'S4', label: 'Significance / Broader Impact', ok: true, text: 'First FSI-validated SMA morphing design envelope under 2.5g loading' },
];

export default function ManuscriptView() {
  const [activeSection, setActiveSection] = useState<string>('abstract');
  const [showLatex, setShowLatex] = useState(false);
  const [activeRunId, setActiveRunId] = useState('run-002');

  const sections = manuscriptSectionsRun002;
  const totalWords = sections.reduce((a, s) => a + s.wordCount, 0);
  const targetWords = 9840;
  const currentSection = sections.find(s => s.id === activeSection)!;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Manuscript Synthesis</h1>
          <p className="text-slate-400 text-sm mt-0.5">Stage 5 · Hierarchical 5-level writing pipeline · AIAA LaTeX · Zero-hallucination (RULE-030)</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={activeRunId}
            onChange={e => setActiveRunId(e.target.value)}
            className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {mockPipelineRuns.map(r => <option key={r.id} value={r.id}>{r.id} — {r.topic.slice(0, 30)}…</option>)}
          </select>
          <button
            onClick={() => setShowLatex(!showLatex)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors border ${showLatex ? 'bg-slate-800 border-slate-600 text-slate-300' : 'bg-blue-600 border-blue-500 text-white hover:bg-blue-500'}`}
          >
            <Code2 size={14} /> {showLatex ? 'Rich View' : 'LaTeX'}
          </button>
        </div>
      </div>

      {/* Progress */}
      {activeRunId === 'run-002' && (
        <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-white font-semibold text-sm">Manuscript Progress</p>
              <p className="text-slate-400 text-xs">{totalWords.toLocaleString()} / {targetWords.toLocaleString()} words · 68 references · 12 figures</p>
            </div>
            <div className="text-right">
              <p className="text-white text-2xl font-bold">{Math.round((totalWords / targetWords) * 100)}%</p>
              <p className="text-slate-500 text-xs">complete</p>
            </div>
          </div>
          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full" style={{ width: `${(totalWords / targetWords) * 100}%` }} />
          </div>
          <div className="flex gap-4 mt-2 text-[11px]">
            <span className="text-emerald-400">● Complete ({sections.filter(s => s.status === 'complete').length})</span>
            <span className="text-yellow-400">● In Review ({sections.filter(s => s.status === 'in_review').length})</span>
            <span className="text-slate-500">● Pending ({sections.filter(s => s.status === 'pending').length})</span>
          </div>
        </div>
      )}

      {activeRunId !== 'run-002' && (
        <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-8 text-center">
          <FileText size={32} className="text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">Manuscript not yet synthesized for {activeRunId}.</p>
          <p className="text-slate-500 text-xs mt-1">Manuscript synthesis begins after Stage 4 (CFD evidence) completes and GATE-4C is approved.</p>
          <p className="text-slate-500 text-xs mt-0.5">Switch to <strong className="text-slate-400">run-002</strong> (completed) to view a full manuscript.</p>
        </div>
      )}

      {activeRunId === 'run-002' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
          {/* Section nav */}
          <div className="lg:col-span-1 space-y-1">
            <p className="text-slate-400 text-xs font-medium uppercase tracking-wider mb-2">Sections</p>
            {sections.map(s => (
              <button
                key={s.id}
                onClick={() => setActiveSection(s.id)}
                className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  activeSection === s.id ? 'bg-blue-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <ChevronRight size={12} className={activeSection === s.id ? 'text-white' : 'text-slate-600'} />
                <span className="flex-1 text-left text-[12px]">{s.label}</span>
                <span className="text-[10px] text-slate-500">{s.wordCount}w</span>
              </button>
            ))}

            {/* AIAA Compliance */}
            <div className="mt-4 bg-slate-800/50 border border-slate-700/60 rounded-xl p-3">
              <p className="text-white text-xs font-semibold mb-2 flex items-center gap-1">📋 AIAA Compliance</p>
              <div className="space-y-1.5">
                {aiaaCompliance.map(item => (
                  <div key={item.label} className="flex items-start gap-1.5">
                    {item.ok
                      ? <CheckCircle2 size={11} className="text-emerald-400 flex-shrink-0 mt-0.5" />
                      : <AlertCircle size={11} className="text-orange-400 flex-shrink-0 mt-0.5" />
                    }
                    <div>
                      <p className="text-[10px] text-slate-300 leading-tight">{item.label}</p>
                      {item.detail && <p className="text-[9px] text-slate-500">{item.detail}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Content area */}
          <div className="lg:col-span-3">
            {showLatex ? (
              <div className="bg-slate-900 border border-slate-700/60 rounded-xl overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 border-b border-slate-700/60">
                  <Code2 size={13} className="text-slate-400" />
                  <span className="text-slate-400 text-xs font-mono">manuscript.tex — AIAA LaTeX</span>
                  <div className="flex gap-1 ml-auto">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
                  </div>
                </div>
                <pre className="p-4 text-xs text-slate-300 font-mono overflow-auto max-h-[600px] leading-relaxed whitespace-pre-wrap">{latexSnippet}</pre>
              </div>
            ) : (
              <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700/40">
                  <div>
                    <p className="text-white font-semibold">{currentSection?.label}</p>
                    <p className="text-slate-500 text-xs">{currentSection?.wordCount} words</p>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${statusStyle[currentSection?.status ?? 'pending']}`}>
                    {currentSection?.status?.replace('_', ' ')}
                  </span>
                </div>

                <div className="p-4">
                  {currentSection?.content ? (
                    <div className="prose prose-sm prose-invert max-w-none">
                      <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line">{currentSection.content}</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <FileText size={32} className="text-slate-600 mb-3" />
                      <p className="text-slate-400 text-sm font-medium">Section in progress</p>
                      <p className="text-slate-500 text-xs mt-1">SectionWriterAgent queued · Awaiting GATE-4C (Figure Set Approval)</p>
                    </div>
                  )}

                  {/* Abstract structure validation */}
                  {activeSection === 'abstract' && (
                    <div className="mt-4 bg-slate-900/60 border border-slate-700/40 rounded-xl p-3">
                      <p className="text-slate-400 text-xs font-semibold mb-2">Abstract Structure Validation (RULE-034)</p>
                      <div className="space-y-2">
                        {abstractStructure.map(s => (
                          <div key={s.n} className="flex items-start gap-2">
                            <span className="w-6 h-6 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">{s.n}</span>
                            <div>
                              <p className="text-slate-300 text-[11px] font-medium">{s.label}</p>
                              <p className="text-slate-500 text-[10px] italic">{s.text}</p>
                            </div>
                            <CheckCircle2 size={12} className="text-emerald-400 ml-auto flex-shrink-0 mt-0.5" />
                          </div>
                        ))}
                      </div>
                      <p className="text-emerald-400 text-[10px] mt-2 font-medium">✓ 248/250 words · 4-sentence structure verified · AIAA-compliant</p>
                    </div>
                  )}

                  {/* Nomenclature — show symbols */}
                  {activeSection === 'nomenclature' && currentSection.content && (
                    <div className="mt-4 bg-slate-900/60 border border-slate-700/40 rounded-xl p-3">
                      <p className="text-slate-400 text-xs font-semibold mb-2">Symbol Table</p>
                      <div className="grid grid-cols-2 gap-x-6 gap-y-1">
                        {currentSection.content.split('\n').filter(Boolean).map((line, i) => {
                          const [sym, ...rest] = line.split('—');
                          return sym && rest.length > 0 ? (
                            <div key={i} className="flex gap-2">
                              <span className="text-cyan-400 font-mono text-[11px] w-16 flex-shrink-0">{sym.trim()}</span>
                              <span className="text-slate-400 text-[11px]">{rest.join('—').trim()}</span>
                            </div>
                          ) : null;
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Writing hierarchy */}
            {!showLatex && (
              <div className="mt-3 bg-slate-800/40 border border-slate-700/60 rounded-xl p-3">
                <p className="text-slate-400 text-xs font-semibold mb-2">Hierarchical Writing Pipeline (RULE-030)</p>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {[
                    { n: 'L1', label: 'Architecture', done: true },
                    { n: 'L2', label: 'Section Outlines', done: true },
                    { n: 'L3', label: 'Paragraph Plans', done: true },
                    { n: 'L4', label: 'Sentence Generation', done: true },
                    { n: 'L5', label: 'LaTeX Render', done: true },
                  ].map((level, i) => (
                    <div key={level.n} className="flex items-center gap-1.5 flex-shrink-0">
                      {i > 0 && <ChevronRight size={10} className="text-slate-600" />}
                      <div className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium ${level.done ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-500'}`}>
                        {level.done && <CheckCircle2 size={9} />}
                        <span className="font-bold">{level.n}</span>
                        <span>{level.label}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
