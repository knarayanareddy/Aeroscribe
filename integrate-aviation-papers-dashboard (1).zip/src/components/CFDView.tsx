import { useState } from 'react';
import { Shield, Cpu, CheckCircle2, Loader2, AlertTriangle } from 'lucide-react';
import { mockCFDResults, mockPipelineRuns, type CFDResult } from '../data/mockData';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from 'recharts';

const convergenceData = [
  { iter: 0,    res: 1e0   },
  { iter: 200,  res: 1e-1  },
  { iter: 400,  res: 3e-2  },
  { iter: 600,  res: 8e-3  },
  { iter: 800,  res: 4.2e-4 },
  { iter: 1000, res: 9e-5  },
  { iter: 1200, res: 2e-5  },
  { iter: 1400, res: 6e-6  },
  { iter: 1600, res: 1.8e-6 },
  { iter: 1800, res: 9e-7  },
];

const gciData = [
  { level: 'Level 1 (3.2M)', CL: 0.498, CD: 0.01041 },
  { level: 'Level 2 (12.4M)', CL: 0.500, CD: 0.01022 },
  { level: 'Level 3 (49.6M)', CL: 0.501, CD: 0.01010 },
  { level: 'Richardson Ext.', CL: 0.501, CD: 0.01004 },
];

export default function CFDView() {
  const [activeRunId, setActiveRunId] = useState('run-001');
  const results = mockCFDResults.filter(r => r.runId === activeRunId);
  const run = mockPipelineRuns.find(r => r.id === activeRunId)!;
  const cfdStage = run.stages.find(s => s.id === 4);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Evidence Generation — CFD</h1>
          <p className="text-slate-400 text-sm mt-0.5">Stage 4 · SHA256 VerifiedRegistry · Richardson extrapolation · Zero-hallucination results (RULE-041)</p>
        </div>
        <select
          value={activeRunId}
          onChange={e => setActiveRunId(e.target.value)}
          className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {mockPipelineRuns.map(r => <option key={r.id} value={r.id}>{r.id} — {r.topic.slice(0, 40)}…</option>)}
        </select>
      </div>

      {/* Stage status */}
      <div className={`border rounded-xl p-4 ${
        cfdStage?.status === 'running' ? 'bg-blue-500/10 border-blue-500/40' :
        cfdStage?.status === 'completed' ? 'bg-emerald-500/10 border-emerald-500/40' :
        'bg-slate-800/50 border-slate-700/60'
      }`}>
        <div className="flex items-center gap-3">
          {cfdStage?.status === 'running' ? <Loader2 size={16} className="text-blue-400 animate-spin" /> :
           cfdStage?.status === 'completed' ? <CheckCircle2 size={16} className="text-emerald-400" /> :
           <Cpu size={16} className="text-slate-400" />}
          <div>
            <p className="text-white font-semibold text-sm">
              CFD Stage: {cfdStage?.status ?? 'Pending'}
              {cfdStage?.gateId && <span className="ml-2 text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full">{cfdStage.gateId}</span>}
            </p>
            {cfdStage?.agentsActive.length ? (
              <div className="flex gap-1 mt-1">
                {cfdStage.agentsActive.map(a => (
                  <span key={a} className="text-[10px] bg-blue-500/10 text-blue-300 border border-blue-500/20 px-2 py-0.5 rounded-full">{a}</span>
                ))}
              </div>
            ) : null}
          </div>
          {cfdStage?.metrics && Object.keys(cfdStage.metrics).length > 0 && (
            <div className="ml-auto flex gap-4">
              {Object.entries(cfdStage.metrics).map(([k, v]) => (
                <div key={k} className="text-right">
                  <p className="text-slate-500 text-[10px]">{k}</p>
                  <p className="text-white text-xs font-bold">{String(v)}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* VerifiedRegistry Results */}
      <div>
        <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
          <Shield size={14} className="text-emerald-400" /> VerifiedRegistry — Computational Results
          <span className="text-[10px] text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 px-2 py-0.5 rounded-full">
            {results.length} records · SHA256 verified · Append-only (RULE-043)
          </span>
        </h3>
        {results.length === 0 ? (
          <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-8 text-center">
            <Cpu size={32} className="text-slate-600 mx-auto mb-2" />
            <p className="text-slate-400 text-sm">No CFD results registered for this run yet.</p>
            <p className="text-slate-500 text-xs mt-1">CFD results appear here after Stage 4 completes and CFDPostProcessor logs them to VerifiedRegistry.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {results.map((r: CFDResult) => (
              <div key={r.id} className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4">
                <div className="flex items-start justify-between mb-3">
                  <p className="text-slate-200 text-sm font-semibold leading-snug">{r.name}</p>
                  <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                    <CheckCircle2 size={11} className="text-emerald-400" />
                    <span className="text-emerald-400 text-[10px]">Verified</span>
                  </div>
                </div>

                {/* Value with uncertainty — RULE-031 format */}
                <div className="bg-slate-900 rounded-lg px-3 py-2 mb-3">
                  <p className="text-cyan-400 font-mono text-base font-bold">
                    {r.value.toLocaleString()} <span className="text-slate-500 font-normal text-xs">{r.unit}</span>
                  </p>
                  <p className="text-slate-500 text-[11px] font-mono mt-0.5">
                    ± {r.uncertainty} ({r.confidence}% CI, {r.method.split(',')[0]})
                  </p>
                  <p className="text-slate-600 text-[10px] italic mt-1">RULE-031 compliant</p>
                </div>

                <div className="space-y-1">
                  <div>
                    <p className="text-slate-500 text-[10px]">Method</p>
                    <p className="text-slate-300 text-[11px]">{r.method}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px]">SHA256 (truncated)</p>
                    <p className="text-emerald-400 font-mono text-[9px] break-all">{r.sha256}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px]">Logged</p>
                    <p className="text-slate-400 text-[10px]">{new Date(r.timestamp).toLocaleString()}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Convergence charts — only shown for runs with data */}
      {activeRunId === 'run-002' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Solver convergence */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-1">Solver Convergence History</h3>
            <p className="text-slate-500 text-[11px] mb-4">DLR TAU · k-ω SST · Level-2 mesh (12.4M cells)</p>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={convergenceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="iter" tick={{ fill: '#94a3b8', fontSize: 10 }} label={{ value: 'Iteration', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
                <YAxis scale="log" domain={['auto', 'auto']} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 11 }} formatter={(v) => [typeof v === 'number' ? v.toExponential(2) : v, 'Residual']} />
                <Line dataKey="res" stroke="#3b82f6" strokeWidth={2} dot={false} name="Density residual" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* GCI study */}
          <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
            <h3 className="text-white font-semibold text-sm mb-1">Grid Convergence Study (Richardson Extrapolation)</h3>
            <p className="text-slate-500 text-[11px] mb-4">GCI₂₃ = 1.2% on C_D · RULE-031 compliant</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={gciData} margin={{ bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="level" tick={{ fill: '#94a3b8', fontSize: 9 }} angle={-15} textAnchor="end" />
                <YAxis yAxisId="CD" orientation="left" tick={{ fill: '#94a3b8', fontSize: 10 }} domain={[0.0095, 0.0115]} label={{ value: 'C_D', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }} />
                <YAxis yAxisId="CL" orientation="right" tick={{ fill: '#94a3b8', fontSize: 10 }} domain={[0.495, 0.505]} label={{ value: 'C_L', angle: 90, position: 'insideRight', fill: '#64748b', fontSize: 10 }} />
                <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, fontSize: 11 }} />
                <Legend wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
                <Bar yAxisId="CD" dataKey="CD" fill="#3b82f6" name="C_D" radius={[3, 3, 0, 0]} />
                <Bar yAxisId="CL" dataKey="CL" fill="#10b981" name="C_L" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Integrity chain */}
      <div className="bg-slate-800/50 border border-slate-700/60 rounded-xl p-4">
        <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
          <AlertTriangle size={14} className="text-blue-400" /> Integrity Chain (RULE-041)
        </h3>
        <div className="flex items-center gap-2 flex-wrap">
          {[
            { step: 'Compute', desc: 'CFD solver runs',           color: 'bg-blue-500' },
            { step: '→ Checksum', desc: 'SHA256 hash generated', color: 'bg-cyan-500' },
            { step: '→ Registry', desc: 'Appended to VerifiedRegistry (append-only)', color: 'bg-purple-500' },
            { step: '→ Manuscript', desc: 'Value used in LaTeX with hash reference', color: 'bg-emerald-500' },
          ].map(s => (
            <div key={s.step} className="flex-1 min-w-32">
              <div className={`h-1 ${s.color} rounded mb-1.5`} />
              <p className="text-white text-xs font-bold">{s.step}</p>
              <p className="text-slate-400 text-[10px]">{s.desc}</p>
            </div>
          ))}
        </div>
        <p className="text-slate-500 text-[11px] mt-3 italic">Breaking this chain causes immediate PIPELINE HALT. No agent may use a CFD result without prior VerifiedRegistry registration.</p>
      </div>
    </div>
  );
}
