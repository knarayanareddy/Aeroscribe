// ─────────────────────────────────────────────────────────────────────────────
// AeroScribe — Mock Data Layer
// Spec: GLOBAL-ARCH-001, _global/data-model.md
// Implements all entity types consumed by every dashboard view.
// ─────────────────────────────────────────────────────────────────────────────

export type PipelineStatus = 'idle' | 'running' | 'gate_pending' | 'completed' | 'failed';
export type StageStatus = 'pending' | 'running' | 'gate_pending' | 'completed' | 'failed' | 'skipped';

export interface StageInfo {
  id: number;
  name: string;
  shortName: string;
  status: StageStatus;
  startedAt?: string;
  completedAt?: string;
  duration?: number;          // minutes
  agentsActive: string[];
  gateId?: string;
  gateApproved?: boolean;
  metrics?: Record<string, string | number>;
}

export interface PipelineRun {
  id: string;
  topic: string;
  journal: string;
  status: PipelineStatus;
  createdAt: string;
  updatedAt: string;
  currentStage: number;
  noveltyScore: number;
  paperTitle: string;
  stages: StageInfo[];
}

export interface Paper {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  doi: string;
  relevanceScore: number;
  citationCount: number;
  abstract: string;
  tags: string[];
  runId: string;
}

export interface ResearchGap {
  id: string;
  phenomena: string;
  missingMethodology: string;
  noveltyScore: number;
  recommendation: string;
  competitorRisk: 'low' | 'medium' | 'high';
  runId: string;
}

export interface CFDResult {
  id: string;
  name: string;
  value: number;
  unit: string;
  uncertainty: number;
  confidence: number;
  sha256: string;
  method: string;
  timestamp: string;
  runId: string;
}

export interface AgentLog {
  id: string;
  agentId: string;
  stageId: string;
  runId: string;
  event: string;
  message: string;
  durationMs?: number;
  costUsd?: number;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
}

export interface ReviewComment {
  id: string;
  reviewerId: string;
  reviewerName: string;
  section: string;
  severity: 'major' | 'minor' | 'suggestion';
  comment: string;
  resolved: boolean;
  response?: string;
  runId: string;
}

export interface WikiArticle {
  id: string;
  title: string;
  category: string;
  lastUpdated: string;
  papersLinked: number;
  status: 'published' | 'draft';
  summary: string;
  relatedRunIds: string[];
}

export interface JournalProfile {
  id: string;
  name: string;
  publisher: string;
  impactFactor: number;
  acceptanceRate: number;
  reviewWeeks: number;
  scopeKeywords: string[];
}

export interface ManuscriptSection {
  id: string;
  label: string;
  wordCount: number;
  status: 'complete' | 'in_review' | 'draft' | 'pending';
  content?: string;
  runId: string;
}

// ── PIPELINE RUNS ──────────────────────────────────────────────────────────────
export const mockPipelineRuns: PipelineRun[] = [
  {
    id: 'run-001',
    topic: 'Rotating Detonation Engine Combustion Stability at High-Altitude Conditions',
    journal: 'Journal of Propulsion and Power',
    status: 'gate_pending',
    createdAt: '2026-04-28T09:00:00Z',
    updatedAt: '2026-04-28T14:32:00Z',
    currentStage: 2,
    noveltyScore: 8.7,
    paperTitle: 'Detonation Cell Instability in RDEs Under Simulated Stratospheric Conditions: A CFD-Validated Investigation',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', startedAt: '2026-04-28T09:00:00Z', completedAt: '2026-04-28T09:14:00Z', duration: 14, agentsActive: ['TopicIntelligenceAgent'], gateId: 'GATE-0', gateApproved: true, metrics: { journalFitScore: '9.1/10', targetJournal: 'J. Propulsion & Power', paperType: 'Research Article' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', startedAt: '2026-04-28T09:15:00Z', completedAt: '2026-04-28T11:45:00Z', duration: 150, agentsActive: ['LiteratureHarvestAgent', 'CitationGraphAgent', 'LiteratureRerankerAgent'], gateId: 'GATE-1', gateApproved: true, metrics: { papersHarvested: 147, papersReranked: 112, citationDepth: 3, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'gate_pending', startedAt: '2026-04-28T11:46:00Z', completedAt: '2026-04-28T12:48:00Z', duration: 62, agentsActive: ['NoveltyDetectionAgent'], gateId: 'GATE-2', gateApproved: false, metrics: { noveltyScore: 8.7, gapsIdentified: 4, contradictionsFound: 2, preemptionRisk: 'Low' } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'pending', agentsActive: [], metrics: {} },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ],
  },
  {
    id: 'run-002',
    topic: 'Adaptive Wing Morphing for Transonic Drag Reduction using SMA Actuators',
    journal: 'AIAA Journal',
    status: 'completed',
    createdAt: '2026-04-20T08:00:00Z',
    updatedAt: '2026-04-26T16:00:00Z',
    currentStage: 8,
    noveltyScore: 7.9,
    paperTitle: 'Variable Camber Wing via SMA Actuation: CFD Validation and Transonic Drag Polar Analysis',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '8.4/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', agentsActive: [], gateApproved: true, metrics: { papersHarvested: 132, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'completed', agentsActive: [], gateApproved: true, metrics: { noveltyScore: 7.9, gapsIdentified: 3 } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'completed', agentsActive: [], gateApproved: true, metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'completed', agentsActive: [], gateApproved: true, metrics: { meshCells: '12.4M', solverIterations: 2400, convergenceResidual: '1e-6' } },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'completed', agentsActive: [], gateApproved: true, metrics: { wordCount: 9840, figureCount: 12, referenceCount: 68 } },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'completed', agentsActive: [], gateApproved: true, metrics: { majorComments: 3, minorComments: 8 } },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'completed', agentsActive: [], gateApproved: true, metrics: { complianceScore: '98%' } },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'completed', agentsActive: [], gateApproved: true, metrics: { submissionPackage: 'Ready', wikiArticles: 4 } },
    ],
  },
  {
    id: 'run-003',
    topic: 'Hypersonic Boundary Layer Transition on Blunt-Nosed Re-entry Vehicles',
    journal: 'Aerospace Science and Technology',
    status: 'running',
    createdAt: '2026-04-29T06:00:00Z',
    updatedAt: '2026-04-29T10:15:00Z',
    currentStage: 4,
    noveltyScore: 9.1,
    paperTitle: 'Mach 8 Boundary Layer Transition Onset: DNS Study with Wall-Temperature Sensitivity Analysis',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '9.4/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'completed', agentsActive: [], gateApproved: true, metrics: { papersHarvested: 189, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'completed', agentsActive: [], gateApproved: true, metrics: { noveltyScore: 9.1, gapsIdentified: 5 } },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'completed', agentsActive: [], gateApproved: true, metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'running', agentsActive: ['CFDSetupAgent', 'CFDSolverAgent'], gateId: 'GATE-4A', metrics: { currentRefinement: 'Level 2/4', solverRuntime: '3h 22m', residual: '4.2e-4' } },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ],
  },
  {
    id: 'run-004',
    topic: 'Machine Learning-Augmented Turbulence Closure for Low-Reynolds Number UAV Aerodynamics',
    journal: 'Aerospace Science and Technology',
    status: 'running',
    createdAt: '2026-04-30T07:30:00Z',
    updatedAt: '2026-04-30T11:45:00Z',
    currentStage: 1,
    noveltyScore: 8.3,
    paperTitle: 'Physics-Informed Neural Network Turbulence Model for Re < 200,000 Fixed-Wing UAV Airfoils',
    stages: [
      { id: 0, name: 'Topic Intelligence', shortName: 'Topic', status: 'completed', agentsActive: [], gateApproved: true, metrics: { journalFitScore: '8.8/10' } },
      { id: 1, name: 'Literature Archaeology', shortName: 'Literature', status: 'running', agentsActive: ['LiteratureHarvestAgent', 'CitationGraphAgent'], gateId: 'GATE-1', metrics: { papersHarvested: 73, citationDepth: 2, doiVerified: '100%' } },
      { id: 2, name: 'Novelty Detection', shortName: 'Novelty', status: 'pending', agentsActive: [], metrics: {} },
      { id: 3, name: 'Contribution Framing', shortName: 'Framing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 4, name: 'Evidence Generation (CFD)', shortName: 'CFD', status: 'pending', agentsActive: [], metrics: {} },
      { id: 5, name: 'Paper Synthesis', shortName: 'Writing', status: 'pending', agentsActive: [], metrics: {} },
      { id: 6, name: 'Peer Review Council', shortName: 'Review', status: 'pending', agentsActive: [], metrics: {} },
      { id: 7, name: 'Revision & Compliance', shortName: 'Revision', status: 'pending', agentsActive: [], metrics: {} },
      { id: 8, name: 'AeroWiki & Submission', shortName: 'Submit', status: 'pending', agentsActive: [], metrics: {} },
    ],
  },
];

// ── PAPERS (multi-run) ─────────────────────────────────────────────────────────
export const mockPapers: Paper[] = [
  // run-001: RDE
  { id: 'p001', runId: 'run-001', title: 'Detonation Cell Width in H₂-Air Mixtures at Elevated Pressures', authors: 'Smith, J.R. and Chen, W.', journal: 'Combustion and Flame', year: 2024, doi: '10.1016/j.combustflame.2024.01.012', relevanceScore: 9.4, citationCount: 23, abstract: 'This study investigates detonation cell width measurements in hydrogen-air mixtures over a pressure range of 1–20 atm using simultaneous schlieren photography and pressure diagnostics. Critical cell width data are reported for φ = 0.6–1.4 at 5 and 20 atm.', tags: ['detonation', 'hydrogen', 'cell width', 'high pressure'] },
  { id: 'p002', runId: 'run-001', title: 'Rotating Detonation Engine Performance at Altitude Relight Conditions', authors: 'Nakamura, T., Voitsekhovskii, B., and Park, S.', journal: 'J. Propulsion and Power', year: 2023, doi: '10.2514/1.B39012', relevanceScore: 9.1, citationCount: 41, abstract: 'Altitude relight behavior of a rotating detonation engine combustor was characterized experimentally at simulated altitudes of 5–15 km using a vacuum facility. Wave speed and combustion efficiency are reported as functions of ambient back-pressure.', tags: ['RDE', 'altitude', 'relight', 'combustor'] },
  { id: 'p003', runId: 'run-001', title: 'CFD Simulation of Multi-Wave RDE with Reactant Injection Variation', authors: 'Liu, Y., Braun, J., and Yungster, S.', journal: 'AIAA Journal', year: 2024, doi: '10.2514/1.J063441', relevanceScore: 8.8, citationCount: 18, abstract: 'A high-fidelity CFD model of a rotating detonation engine is presented, accounting for multi-wave propagation modes and injector geometry. GRI-Mech 3.0 kinetics with adaptive mesh refinement resolve the detonation front to sub-millimeter accuracy.', tags: ['CFD', 'RDE', 'injection', 'simulation'] },
  { id: 'p004', runId: 'run-001', title: 'Detonation Stability Analysis Using Linear Perturbation Theory', authors: 'Ng, H.D. and Zhang, F.', journal: 'Progress in Aerospace Sciences', year: 2022, doi: '10.1016/j.paerosci.2022.100887', relevanceScore: 8.5, citationCount: 62, abstract: 'Linear stability analysis of detonation waves is revisited using a refined activation energy model capable of predicting cellular structure onset. The instability parameter χ is extended to multi-species reactive mixtures.', tags: ['stability', 'linear perturbation', 'detonation', 'theory'] },
  { id: 'p005', runId: 'run-001', title: 'Stratospheric Combustion Limits for Aviation Fuels', authors: 'Williams, F.A. and Dryer, F.L.', journal: 'Fuel', year: 2023, doi: '10.1016/j.fuel.2023.127540', relevanceScore: 8.2, citationCount: 29, abstract: 'The flammability and ignition limits of Jet-A and SAF blends at stratospheric pressure and temperature conditions are studied experimentally and computationally. Extinction stretch rates are reported at 0.05–0.2 atm.', tags: ['stratospheric', 'aviation fuel', 'ignition', 'SAF'] },
  { id: 'p006', runId: 'run-001', title: 'Effect of Ambient Pressure on Rotating Detonation Wave Speed', authors: 'Andrus, I.Q., King, P.I., and Schauer, F.R.', journal: 'J. Propulsion and Power', year: 2023, doi: '10.2514/1.B38877', relevanceScore: 8.0, citationCount: 35, abstract: 'The influence of ambient back-pressure on the propagation velocity and wave count of rotating detonations is studied parametrically in an annular combustor. A correlation between wave speed deficit and pressure ratio is derived.', tags: ['RDE', 'pressure', 'wave speed', 'annular'] },
  { id: 'p007', runId: 'run-001', title: 'High-Altitude Ignition of Hydrogen in Scramjet Intakes', authors: 'Turner, J.C., Smart, M.K., and Capra, B.', journal: 'Aerospace Science and Technology', year: 2022, doi: '10.1016/j.ast.2022.107580', relevanceScore: 7.6, citationCount: 44, abstract: 'The ignition of hydrogen fuel in a Mach 8 scramjet intake at 35 km altitude is studied via numerical simulation and shock-tunnel experiments. Auto-ignition delay times at altitude-equivalent conditions are catalogued.', tags: ['scramjet', 'hydrogen', 'high altitude', 'ignition'] },
  { id: 'p008', runId: 'run-001', title: 'Thermodynamic Cycle Analysis of Pressure Gain Combustion Engines', authors: 'Kaemming, T.A. and Paxson, D.E.', journal: 'AIAA Journal', year: 2024, doi: '10.2514/1.J063810', relevanceScore: 7.3, citationCount: 12, abstract: 'A generalized thermodynamic framework for pressure-gain combustion engines is developed, encompassing PDEs, RDEs, and wave rotor combustors. Cycle efficiency advantages are quantified relative to Brayton baseline.', tags: ['thermodynamics', 'pressure gain', 'PDE', 'RDE', 'cycle analysis'] },

  // run-002: SMA morphing wing
  { id: 'p009', runId: 'run-002', title: 'Shape Memory Alloy Actuators for Morphing Wing Camber Control', authors: 'Barbarino, S., Saavedra Flores, E.I., and Ajaj, R.M.', journal: 'Smart Materials and Structures', year: 2023, doi: '10.1088/1361-665X/ac7d2c', relevanceScore: 9.3, citationCount: 57, abstract: 'NiTi SMA wires embedded in a composite trailing-edge structure enable 8° camber change with 240 ms actuation response. Structural testing at 2.5g load factor validates actuator authority.', tags: ['SMA', 'morphing', 'actuator', 'composite'] },
  { id: 'p010', runId: 'run-002', title: 'Transonic Aerodynamic Benefits of Variable Camber Wings', authors: 'Nguyen, N., Precup, N., and Urnes, J.', journal: 'AIAA Journal', year: 2022, doi: '10.2514/1.J061834', relevanceScore: 9.0, citationCount: 88, abstract: 'Wind tunnel and CFD studies on a variable camber airfoil demonstrate 3.1% drag reduction at Mach 0.78 cruise with 1.2° trailing-edge deflection. Drag polar shifts are characterized over a C_L range of 0.3–0.6.', tags: ['variable camber', 'transonic', 'drag reduction', 'CFD'] },
  { id: 'p011', runId: 'run-002', title: 'Transonic Buffet Onset Delay via Adaptive Trailing Edge', authors: 'Illi, S.A., Lutz, T., and Krämer, E.', journal: 'Aerospace Science and Technology', year: 2023, doi: '10.1016/j.ast.2023.108445', relevanceScore: 8.6, citationCount: 34, abstract: 'Adaptive trailing-edge deflection of ±3° delays transonic buffet onset by ΔCL = 0.04 on a supercritical airfoil at M = 0.76. URANS simulations show shock oscillation damping of 62% in amplitude.', tags: ['buffet', 'transonic', 'adaptive', 'trailing edge'] },
  { id: 'p012', runId: 'run-002', title: 'SMA Constitutive Models for Aerospace Actuator Design', authors: 'Lagoudas, D.C., Entchev, P.B., and Kumar, P.K.', journal: 'Mechanics of Materials', year: 2022, doi: '10.1016/j.mechmat.2022.104319', relevanceScore: 8.1, citationCount: 72, abstract: 'Unified SMA constitutive models accounting for thermomechanical coupling, phase transformation plasticity, and cyclic degradation are derived and validated against tension-compression experiments.', tags: ['SMA', 'constitutive', 'thermomechanical', 'phase transformation'] },

  // run-003: Hypersonic BL transition
  { id: 'p013', runId: 'run-003', title: 'Boundary Layer Transition on Blunt Cones at Mach 6–10', authors: 'Stetson, K.F. and Kimmel, R.L.', journal: 'AIAA Journal', year: 2022, doi: '10.2514/1.J061220', relevanceScore: 9.5, citationCount: 104, abstract: 'Natural boundary layer transition on 7° half-angle blunt cones is characterized at Mach 6, 8, and 10 using thin-film heat transfer gauges. Transition Reynolds number correlates with bluntness ratio Re_θ/Me.', tags: ['boundary layer', 'transition', 'hypersonic', 'blunt cone'] },
  { id: 'p014', runId: 'run-003', title: 'Wall Temperature Effect on Hypersonic Transition Location', authors: 'Malik, M.R. and Anderson, E.C.', journal: 'Physics of Fluids', year: 2023, doi: '10.1063/5.0134782', relevanceScore: 9.2, citationCount: 47, abstract: 'DNS and linear stability theory (LST) show that wall cooling (T_w/T_aw = 0.4) stabilizes second-mode instabilities by 35% while destabilizing first-mode disturbances at Mach 8.', tags: ['DNS', 'wall temperature', 'stability', 'second mode'] },
  { id: 'p015', runId: 'run-003', title: 'Second-Mode Instability Measurement via PCB Sensors on HIFiRE-1', authors: 'Kimmel, R.L., Adamczak, D., and DSTO Team', journal: 'J. Spacecraft and Rockets', year: 2023, doi: '10.2514/1.A35712', relevanceScore: 8.9, citationCount: 62, abstract: 'Flight data from HIFiRE-1 validate second-mode instability growth rates predicted by linear stability theory with a mean error of 12% over the frequency range 200–450 kHz.', tags: ['HIFiRE', 'second mode', 'flight data', 'PCB sensor'] },
  { id: 'p016', runId: 'run-003', title: 'Nose Bluntness Effects on Re-entry Vehicle Aerothermal Loads', authors: 'Wright, M.J., Loomis, M., and Papadopoulos, P.', journal: 'J. Thermophysics and Heat Transfer', year: 2022, doi: '10.2514/1.T6834', relevanceScore: 8.4, citationCount: 39, abstract: 'Parametric study of nose radius (R_N = 5–150 mm) on stagnation heating and transition location for a 70° sphere-cone re-entry geometry at Mach 8 demonstrates non-monotonic transition behavior for R_N > 50 mm.', tags: ['nose bluntness', 're-entry', 'aerothermal', 'heating'] },

  // run-004: ML turbulence / UAV
  { id: 'p017', runId: 'run-004', title: 'Physics-Informed Neural Networks for RANS Turbulence Closure', authors: 'Duraisamy, K., Iaccarino, G., and Xiao, H.', journal: 'Annual Review of Fluid Mechanics', year: 2023, doi: '10.1146/annurev-fluid-010518-040547', relevanceScore: 9.6, citationCount: 312, abstract: 'Machine learning augmentation of turbulence models is reviewed with emphasis on field inversion, genetic programming, and neural network approaches. Validation on benchmark flows including separated regions shows 25–40% accuracy improvement over standard k-ω SST.', tags: ['PINN', 'turbulence', 'machine learning', 'RANS'] },
  { id: 'p018', runId: 'run-004', title: 'Aerodynamics of Fixed-Wing UAVs at Low Reynolds Number', authors: 'Mueller, T.J. and DeLaurier, J.D.', journal: 'AIAA Journal', year: 2022, doi: '10.2514/1.J062103', relevanceScore: 9.1, citationCount: 145, abstract: 'Experimental force and moment data for NACA 0012, SD7037, and E387 airfoils at Re = 50,000–200,000 are tabulated. Laminar separation bubble formation and burst are characterized across incidence angles 0–18°.', tags: ['UAV', 'low Reynolds', 'airfoil', 'separation bubble'] },
  { id: 'p019', runId: 'run-004', title: 'Data-Driven Turbulence Modeling for Low-Reynolds Airfoils', authors: 'Singh, A.P., Medida, S., and Duraisamy, K.', journal: 'AIAA Journal', year: 2022, doi: '10.2514/1.J056671', relevanceScore: 8.8, citationCount: 93, abstract: 'A field-inversion + machine learning (FIML) approach corrects the k-ω SST baseline for low-Reynolds laminar-turbulent transition on SD7037. Corrected model predicts C_L within 4% of experiment across the range Re = 60,000–150,000.', tags: ['FIML', 'transition', 'k-omega', 'SD7037'] },
  { id: 'p020', runId: 'run-004', title: 'Laminar Separation Bubble Dynamics at Re < 100,000', authors: 'Horton, H.P. and Roberts, W.B.', journal: 'Experiments in Fluids', year: 2023, doi: '10.1007/s00348-023-03621-4', relevanceScore: 8.3, citationCount: 28, abstract: 'PIV measurements resolve the three-dimensional dynamics of a laminar separation bubble on an E387 airfoil at Re = 80,000. Bubble length, reattachment length, and unsteady shedding frequency are correlated with incidence angle.', tags: ['separation bubble', 'PIV', 'E387', 'low Reynolds'] },
];

// ── RESEARCH GAPS ───────────────────────────────────────────────────────────────
export const mockResearchGaps: ResearchGap[] = [
  { id: 'gap-001', runId: 'run-001', phenomena: 'RDE combustion stability at stratospheric pressure (<0.1 atm)', missingMethodology: 'High-fidelity reactive Euler CFD with detailed H₂-air kinetics at sub-100 mbar', noveltyScore: 9.2, recommendation: 'First application of 3D DNS-validated RDE model to sub-100 mbar ambient conditions', competitorRisk: 'low' },
  { id: 'gap-002', runId: 'run-001', phenomena: 'Detonation cell width at altitude-equivalent mixture fractions', missingMethodology: 'Combined experimental (shock tube) + numerical cell instability analysis', noveltyScore: 8.4, recommendation: 'Extend Ng & Zhang (2022) stability framework to low-pressure regimes', competitorRisk: 'medium' },
  { id: 'gap-003', runId: 'run-001', phenomena: 'Multi-wave mode transitions under throttling at altitude', missingMethodology: 'Unsteady RANS with dynamic injector boundary conditions', noveltyScore: 7.8, recommendation: 'Parametric CFD study correlating wave count with altitude-equivalent back-pressure', competitorRisk: 'medium' },
  { id: 'gap-004', runId: 'run-001', phenomena: 'Fuel-air mixing enhancement for cold, thin air at stratosphere', missingMethodology: 'LES with reduced-order turbulent mixing model', noveltyScore: 7.1, recommendation: 'Design space exploration for injector geometry at Mach 0.3 supply conditions', competitorRisk: 'high' },
  { id: 'gap-005', runId: 'run-002', phenomena: 'SMA actuation authority under transonic aerodynamic loading (>2g)', missingMethodology: 'Fluid-structure interaction (FSI) with thermomechanical SMA constitutive model', noveltyScore: 8.6, recommendation: 'Couple RANS aerodynamics with Lagoudas SMA model for full maneuver envelope', competitorRisk: 'low' },
  { id: 'gap-006', runId: 'run-002', phenomena: 'Drag polar sensitivity to camber schedule at M = 0.76–0.82', missingMethodology: 'Adjoint-based optimization for camber schedule vs. lift coefficient', noveltyScore: 7.7, recommendation: 'Adjoint-driven camber schedule optimization using DLR TAU solver', competitorRisk: 'medium' },
  { id: 'gap-007', runId: 'run-003', phenomena: 'Mach 8 boundary layer transition under nose bluntness + wall cooling coupling', missingMethodology: 'DNS with conjugate heat transfer boundary conditions', noveltyScore: 9.4, recommendation: 'First DNS study coupling wall-temperature and bluntness effects at Mach 8', competitorRisk: 'low' },
  { id: 'gap-008', runId: 'run-003', phenomena: 'Second-mode instability amplification in cooled-wall hypersonic BL', missingMethodology: 'PSE (Parabolized Stability Equations) with variable wall temperature', noveltyScore: 8.7, recommendation: 'PSE parametric sweep over T_w/T_aw = 0.3–1.0 at Mach 8', competitorRisk: 'medium' },
  { id: 'gap-009', runId: 'run-004', phenomena: 'RANS closure failure for laminar separation bubble on low-Re UAV airfoils', missingMethodology: 'Physics-informed ML correction trained on high-fidelity DNS data', noveltyScore: 8.9, recommendation: 'Train PINN on E387 DNS dataset to correct k-ω SST in the separation bubble region', competitorRisk: 'low' },
];

// ── CFD RESULTS ─────────────────────────────────────────────────────────────────
export const mockCFDResults: CFDResult[] = [
  // run-001
  { id: 'cfd-001', runId: 'run-001', name: 'Detonation Wave Speed', value: 1842.3, unit: 'm/s', uncertainty: 12.4, confidence: 95, sha256: 'a3f8c1d2e4b69f01c7883a50d234e1f0b6c2d8e4a1f9b305c7d2e8f1a0b4c6d9', method: 'Reactive Euler, GRI-Mech 3.0', timestamp: '2026-04-29T08:44:00Z' },
  { id: 'cfd-002', runId: 'run-001', name: 'Peak Pressure Ratio (p₂/p₁)', value: 18.6, unit: '—', uncertainty: 0.4, confidence: 95, sha256: 'b7e2a9c0f3d12a88e6b401f7c3d9a0e5f2b8c1d4e7a3f0b6c2d8e5f1a9b3c7d', method: 'Reactive Euler, GRI-Mech 3.0', timestamp: '2026-04-29T08:44:00Z' },
  { id: 'cfd-003', runId: 'run-001', name: 'Specific Impulse (Isp)', value: 4312, unit: 's', uncertainty: 38, confidence: 90, sha256: 'c1d4f8e0b2a75c33d8f2a0b6c4e1d7f3a9b0c5d2e8f4a1b7c3d6e0f2a8b5c1', method: 'Thermodynamic integration, GRI-Mech 3.0', timestamp: '2026-04-29T09:02:00Z' },
  { id: 'cfd-004', runId: 'run-001', name: 'Combustion Efficiency (η_c)', value: 0.9417, unit: '—', uncertainty: 0.0031, confidence: 95, sha256: 'd9a3b0e7c2f18b12e5d2a9c1f4b7e0d3a6c8f2b1e4d7a0c3f9b5e2d8a1c6f4', method: 'Species integration over exit plane', timestamp: '2026-04-29T09:02:00Z' },
  { id: 'cfd-005', runId: 'run-001', name: 'Cell Instability Parameter (χ)', value: 3.72, unit: '—', uncertainty: 0.18, confidence: 90, sha256: 'e5f2d1a8c9b04d77f3a0c6d2e8b1f4a7c3d9e0b5f1a2c8d4e7b0f3a6c1d9e2', method: 'Linear perturbation, Ng criterion', timestamp: '2026-04-29T09:15:00Z' },

  // run-002
  { id: 'cfd-006', runId: 'run-002', name: 'Drag Reduction at M=0.78 (ΔC_D)', value: -0.00312, unit: '—', uncertainty: 0.00018, confidence: 95, sha256: 'f6a3e0b8c2d71e49a5c1f8d4e0b3c7a2f9d5e1b8c4a0f2d7e3b6c9a1f4d8e0', method: 'RANS k-ω SST, Spalart–Allmaras validation', timestamp: '2026-04-25T14:30:00Z' },
  { id: 'cfd-007', runId: 'run-002', name: 'L/D at Optimal Camber Schedule', value: 18.4, unit: '—', uncertainty: 0.3, confidence: 95, sha256: 'g1b4d7f0a2e5c8b3d6f9a1e4c7b0d3f6a9c2e5b8d1f4a7c0e3b6f9d2a5c8e1', method: 'Richardson extrapolation on 3 grid levels', timestamp: '2026-04-25T15:12:00Z' },
  { id: 'cfd-008', runId: 'run-002', name: 'SMA Actuation Force at 2.5g Loading', value: 1240, unit: 'N', uncertainty: 45, confidence: 90, sha256: 'h2c5e8a1d4f7b0e3c6a9d2f5b8e1c4d7a0f3b6e9c2a5d8f1b4e7a0c3d6f9b2', method: 'FEA coupled with Lagoudas SMA constitutive model', timestamp: '2026-04-25T16:00:00Z' },

  // run-003
  { id: 'cfd-009', runId: 'run-003', name: 'Transition Re_θ at T_w/T_aw=0.5, Mach 8', value: 324000, unit: '—', uncertainty: 18000, confidence: 90, sha256: 'i3d6f9b2e5a8c1d4f7a0b3e6c9d2a5f8b1e4c7d0f3b6e9a2c5d8f1a4b7e0c3', method: 'DNS Navier-Stokes, 5th-order WENO', timestamp: '2026-04-29T10:00:00Z' },
  { id: 'cfd-010', runId: 'run-003', name: 'Peak Stagnation Heat Flux (q_s)', value: 4.82, unit: 'MW/m²', uncertainty: 0.14, confidence: 95, sha256: 'j4e7a0c3f6b9d2e5a8c1f4b7e0d3a6c9f2b5e8a1d4f7b0e3c6a9d2f5b8e1c4', method: 'DNS with conjugate heat transfer', timestamp: '2026-04-29T10:00:00Z' },
];

// ── AGENT LOGS ──────────────────────────────────────────────────────────────────
export const mockAgentLogs: AgentLog[] = [
  { id: 'log-001', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'STAGE_START', message: 'Beginning journal calibration for topic: Rotating Detonation Engine Combustion Stability at High-Altitude Conditions', timestamp: '2026-04-28T09:00:12Z', level: 'info' },
  { id: 'log-002', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'JOURNAL_MATCH', message: 'Journal of Propulsion and Power: scope fit score 9.1/10 (keywords matched: rotating detonation engines, combustion, turbomachinery). Acceptance rate: 22%. Typical review: 14 weeks.', timestamp: '2026-04-28T09:08:44Z', level: 'success', durationMs: 512000, costUsd: 0.021 },
  { id: 'log-003', agentId: 'TopicIntelligenceAgent', stageId: 'stage-0', runId: 'run-001', event: 'GATE_REQUEST', message: 'GATE-0 triggered. Researcher approval required to proceed to Stage 1 — Literature Archaeology.', timestamp: '2026-04-28T09:13:55Z', level: 'warn' },
  { id: 'log-004', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-001', event: 'HARVEST_START', message: 'Querying Semantic Scholar API for "rotating detonation engine altitude combustion stability". Exponential backoff retry active. Rate limit: 60 req/min.', timestamp: '2026-04-28T09:15:03Z', level: 'info' },
  { id: 'log-005', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-001', event: 'HARVEST_COMPLETE', message: 'Harvested 147 papers (depth-3 citation expansion). All DOIs resolved and metadata verified via Crossref. Zero hallucinated references (RULE-002 compliant).', timestamp: '2026-04-28T10:02:30Z', level: 'success', durationMs: 2840000, costUsd: 0.184 },
  { id: 'log-006', agentId: 'CitationGraphAgent', stageId: 'stage-1', runId: 'run-001', event: 'GRAPH_BUILD', message: 'Citation graph constructed: 147 nodes, 1,284 edges. Clustering (Louvain) identified 3 research sub-communities: RDE propulsion, detonation physics, stratospheric combustion.', timestamp: '2026-04-28T10:45:00Z', level: 'success', durationMs: 2580000, costUsd: 0.097 },
  { id: 'log-007', agentId: 'LiteratureRerankerAgent', stageId: 'stage-1', runId: 'run-001', event: 'RERANK_COMPLETE', message: 'Reranked 147 → 112 papers (relevance threshold: 7.0/10). Top paper: Nakamura et al. 2023 (score: 9.1). GATE-1 payload ready.', timestamp: '2026-04-28T11:44:20Z', level: 'success', durationMs: 3560000, costUsd: 0.142 },
  { id: 'log-008', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'GAP_MATRIX_BUILD', message: 'Gap matrix built: 12×8×6 sparse tensor (phenomena × methodologies × parameter_ranges). 4 candidate research gaps found. Primary gap: RDE stability at sub-100 mbar — zero papers in corpus.', timestamp: '2026-04-28T12:22:10Z', level: 'success', durationMs: 2160000, costUsd: 0.209 },
  { id: 'log-009', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'NOVELTY_CERTIFICATE', message: 'Novelty Certificate generated. Score: 8.7/10. Preemption risk: LOW (0 arXiv preprints in last 90 days). Recommended framing: "First CFD-validated study of RDE combustion stability at stratospheric pressure."', timestamp: '2026-04-28T12:47:55Z', level: 'success', durationMs: 1530000, costUsd: 0.118 },
  { id: 'log-010', agentId: 'NoveltyDetectionAgent', stageId: 'stage-2', runId: 'run-001', event: 'GATE_REQUEST', message: 'GATE-2 triggered. Novelty Certificate ready for researcher review. Awaiting POST /api/v1/pipeline/run-001/gate/GATE-2/approve', timestamp: '2026-04-28T12:48:02Z', level: 'warn' },
  { id: 'log-011', agentId: 'CFDSolverAgent', stageId: 'stage-4', runId: 'run-003', event: 'SOLVER_START', message: 'SU2 solver launched: Level-2 mesh (4.8M cells, hexahedral-dominant). Target residual: 1e-6. CFL ramping: 1 → 50 over 500 iterations.', timestamp: '2026-04-29T06:52:00Z', level: 'info' },
  { id: 'log-012', agentId: 'CFDSolverAgent', stageId: 'stage-4', runId: 'run-003', event: 'SOLVER_UPDATE', message: 'Iteration 800/2400: Residual = 4.2e-4. Continuity converging. CL = 0.412 (Δ from prev: 0.003). Wall time: 3h 22m / est. 8h remaining.', timestamp: '2026-04-29T10:15:00Z', level: 'info', durationMs: 12120000 },
  { id: 'log-013', agentId: 'LiteratureHarvestAgent', stageId: 'stage-1', runId: 'run-004', event: 'HARVEST_START', message: 'Querying Semantic Scholar + arXiv APIs for "physics-informed turbulence model low Reynolds number UAV". 73 papers retrieved at current depth-2 pass. Expanding to depth-3.', timestamp: '2026-04-30T08:20:00Z', level: 'info', durationMs: 480000, costUsd: 0.062 },
  { id: 'log-014', agentId: 'CitationGraphAgent', stageId: 'stage-1', runId: 'run-004', event: 'GRAPH_BUILD', message: 'Partial graph (depth-2): 73 nodes, 612 edges. Sub-communities: PINN/ML turbulence (28 papers), low-Re aerodynamics (31 papers), UAV design (14 papers).', timestamp: '2026-04-30T09:44:00Z', level: 'info', durationMs: 1440000, costUsd: 0.043 },
];

// ── REVIEW COMMENTS ─────────────────────────────────────────────────────────────
export const mockReviewComments: ReviewComment[] = [
  { id: 'rc-001', runId: 'run-001', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3 — CFD Setup', severity: 'major', comment: 'The grid convergence study (Richardson extrapolation) must be presented before any quantitative results are cited. Table 2 is referenced on p.8 but the GCI study appears only in the Appendix. Per RULE-031, restructure to present convergence evidence first, then derived quantities with UQ.', resolved: false },
  { id: 'rc-002', runId: 'run-001', reviewerId: 'ReviewerBAgent', reviewerName: 'Literature Reviewer', section: 'Section 2 — Literature Review', severity: 'major', comment: 'Ng & Zhang (2022) is the canonical reference for the χ-stability framework. The authors must explicitly state where their approach extends their formulation to the low-pressure regime. Currently cited without engagement.', resolved: false },
  { id: 'rc-003', runId: 'run-001', reviewerId: 'ReviewerCAgent', reviewerName: 'Physics Reviewer', section: 'Section 4 — Results', severity: 'minor', comment: 'Figure 6 shows the detonation wave at t=0.2ms but the scale bar is absent. All visualization images must include a length scale. Recommend switching from jet to RdBu diverging colormap for pressure field clarity.', resolved: true, response: 'Scale bar added to Figure 6. Colormap changed to RdBu (diverging) for all pressure field visualizations. SHA256 of revised figure logged to VerifiedRegistry.' },
  { id: 'rc-004', runId: 'run-001', reviewerId: 'ReviewerDAgent', reviewerName: 'Compliance Reviewer', section: 'Abstract', severity: 'minor', comment: 'Abstract at 274 words exceeds the AIAA J. Propulsion and Power 250-word limit. Condense Sentences 2–3. Key quantitative result (Isp = 4312 ± 38 s) must be preserved.', resolved: true, response: 'Abstract condensed to 248 words. Isp result retained with full uncertainty notation per RULE-031.' },
  { id: 'rc-005', runId: 'run-001', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3.2 — Kinetic Mechanism', severity: 'suggestion', comment: 'Consider a sensitivity analysis comparing GRI-Mech 3.0 vs. San Diego mechanism. At sub-100 mbar, third-body efficiencies diverge significantly between the two mechanisms and could affect the χ calculation by ±0.3.', resolved: false },
  { id: 'rc-006', runId: 'run-001', reviewerId: 'MetaReviewerAgent', reviewerName: 'Meta-Reviewer', section: 'Overall — Quantitative Claims', severity: 'major', comment: 'The paper\'s central claim requires uncertainty quantification on ALL reported numerical values. Per RULE-031, every quantitative claim must follow: "[VALUE] ± [UNCERTAINTY] ([CONFIDENCE]%, [METHOD])". Currently 7 values in Section 4 lack uncertainty bounds. Pipeline HALT until resolved.', resolved: false },
  { id: 'rc-007', runId: 'run-002', reviewerId: 'ReviewerAAgent', reviewerName: 'Methodology Reviewer', section: 'Section 3 — FSI Methodology', severity: 'major', comment: 'The one-way FSI coupling assumption (aerodynamic loads applied statically to SMA structure without dynamic feedback) must be justified. At M=0.78 with 2.5g loading, aeroelastic coupling timescales may approach SMA actuation speed. Provide timescale separation argument or switch to two-way coupling.', resolved: true, response: 'Timescale separation analysis added as Section 3.4. SMA actuation period (240 ms) vs. aerodynamic response time (8 ms) gives separation ratio of 30×, justifying one-way coupling. Reference to Lagoudas et al. 2022 added.' },
  { id: 'rc-008', runId: 'run-002', reviewerId: 'ReviewerBAgent', reviewerName: 'Literature Reviewer', section: 'Section 2', severity: 'minor', comment: 'Nguyen et al. (2022) AIAA Journal study on variable camber is the closest prior work to the current paper. The delta contribution must be clearly articulated: this paper extends to SMA actuation under aerodynamic loading, which Nguyen did not address.', resolved: true, response: 'Section 2.3 expanded with explicit positioning statement vs. Nguyen et al. (2022). Contribution delta now stated in final paragraph of Introduction.' },
  { id: 'rc-009', runId: 'run-003', reviewerId: 'ReviewerCAgent', reviewerName: 'Physics Reviewer', section: 'Section 4 — Stability Results', severity: 'major', comment: 'The second-mode frequency predicted by PSE (380 kHz) differs from the DNS by 18%. This exceeds the acceptable 12% threshold established by HIFiRE-1 flight data validation (Kimmel et al. 2023). Provide explanation or rerun PSE with correct mean flow profile.', resolved: false },
  { id: 'rc-010', runId: 'run-003', reviewerId: 'ReviewerDAgent', reviewerName: 'Compliance Reviewer', section: 'Nomenclature', severity: 'minor', comment: 'Re_θ appears in Section 3 without definition in the Nomenclature table. AST requires all symbols defined at first use AND in the Nomenclature section. Add Re_θ (momentum-thickness Reynolds number) with SI unit [—].', resolved: false },
];

// ── JOURNAL PROFILES ────────────────────────────────────────────────────────────
export const journalProfiles: JournalProfile[] = [
  { id: 'jpp', name: 'Journal of Propulsion and Power', publisher: 'AIAA', impactFactor: 2.3, acceptanceRate: 22, reviewWeeks: 14, scopeKeywords: ['airbreathing propulsion', 'combustion', 'turbomachinery', 'rotating detonation engines', 'scramjet', 'liquid rockets', 'solid rockets', 'electric propulsion'] },
  { id: 'aiaa', name: 'AIAA Journal', publisher: 'AIAA', impactFactor: 2.7, acceptanceRate: 20, reviewWeeks: 12, scopeKeywords: ['aerodynamics', 'aeroelasticity', 'flight mechanics', 'structures', 'propulsion', 'computational methods', 'experimental methods'] },
  { id: 'ast', name: 'Aerospace Science and Technology', publisher: 'Elsevier', impactFactor: 5.6, acceptanceRate: 28, reviewWeeks: 10, scopeKeywords: ['aeronautics', 'astronautics', 'propulsion', 'structures', 'flight mechanics', 'avionics', 'aircraft design', 'spacecraft design'] },
  { id: 'acta', name: 'Acta Astronautica', publisher: 'Elsevier / IAF', impactFactor: 3.5, acceptanceRate: 30, reviewWeeks: 11, scopeKeywords: ['space science', 'spacecraft systems', 'launch vehicles', 'human spaceflight', 'space propulsion', 'orbital mechanics', 'satellite technology'] },
  { id: 'pia', name: 'Progress in Aerospace Sciences', publisher: 'Elsevier', impactFactor: 8.3, acceptanceRate: 15, reviewWeeks: 20, scopeKeywords: ['comprehensive review', 'survey', 'state of the art', 'aerospace technology overview'] },
  { id: 'joa', name: 'Journal of Aircraft', publisher: 'AIAA', impactFactor: 1.8, acceptanceRate: 20, reviewWeeks: 12, scopeKeywords: ['aircraft systems', 'MDO', 'structural design', 'flight testing', 'applied CFD', 'UAV', 'VTOL', 'aeroelasticity'] },
];

// ── AEROWIKI ARTICLES ───────────────────────────────────────────────────────────
export const mockWikiArticles: WikiArticle[] = [
  { id: 'wiki-001', title: 'Rotating Detonation Engine (RDE)', category: 'Propulsion', lastUpdated: '2026-04-28', papersLinked: 23, status: 'published', relatedRunIds: ['run-001'], summary: 'RDEs exploit detonation-mode combustion to produce pressure gain across the combustor. Wave propagation speed, annular geometry, and injector design are principal design variables. Altitude combustion stability remains an open research area.' },
  { id: 'wiki-002', title: 'Detonation Cell Width — Measurement & Prediction', category: 'Combustion', lastUpdated: '2026-04-27', papersLinked: 8, status: 'published', relatedRunIds: ['run-001'], summary: 'Cell width (λ) quantifies detonation sensitivity. Measured via sooted foil technique or simultaneous schlieren + pressure diagnostics. Ng instability parameter χ = E_a × (Re_N)^(-1) correlates cell width to mixture thermochemistry.' },
  { id: 'wiki-003', title: 'Pressure-Gain Combustion Cycles', category: 'Thermodynamics', lastUpdated: '2026-04-26', papersLinked: 12, status: 'published', relatedRunIds: ['run-001'], summary: 'Pressure-gain combustion (PGC) cycles achieve thermodynamic efficiency exceeding the Brayton cycle. RDE, PDE, and wave-rotor combustors are primary implementations. Isp gains of 5–15% predicted by Kaemming & Paxson (2024) framework.' },
  { id: 'wiki-004', title: 'Stratospheric Combustion Limits', category: 'Combustion', lastUpdated: '2026-04-28', papersLinked: 5, status: 'draft', relatedRunIds: ['run-001'], summary: 'At stratospheric altitudes (20–50 km), ambient pressure drops to 0.005–0.055 atm. Flammability limits narrow, ignition delay increases non-linearly, and flame stability requires active control. Critical for high-altitude propulsion design.' },
  { id: 'wiki-005', title: 'SMA-Actuated Morphing Wings', category: 'Structures', lastUpdated: '2026-04-24', papersLinked: 15, status: 'published', relatedRunIds: ['run-002'], summary: 'Shape Memory Alloy (NiTi) actuators recover 4–8% strain on thermal cycling above austenite finish temperature (A_f). Embedded in composite trailing-edge structures, they enable camber changes of 5–12° with actuation response times of 200–500 ms.' },
  { id: 'wiki-006', title: 'Transonic Drag Polar Analysis', category: 'Aerodynamics', lastUpdated: '2026-04-23', papersLinked: 19, status: 'published', relatedRunIds: ['run-002'], summary: 'Drag polar characterizes C_D vs. C_L performance across the flight envelope. At transonic Mach (0.76–0.84), wave drag onset causes characteristic drag rise. Variable camber shifts the drag polar, enabling off-design drag reduction.' },
  { id: 'wiki-007', title: 'Hypersonic Boundary Layer Transition', category: 'Aerodynamics', lastUpdated: '2026-04-29', papersLinked: 16, status: 'published', relatedRunIds: ['run-003'], summary: 'Transition from laminar to turbulent boundary layer in hypersonic flow is dominated by second-mode (Mack mode) instabilities above Mach 4. Wall temperature strongly modulates second-mode growth rates. Blunt-nose vehicles experience transition delay due to entropy-layer swallowing.' },
  { id: 'wiki-008', title: 'PINN Turbulence Closure for Low-Re Flows', category: 'Computational Methods', lastUpdated: '2026-04-30', papersLinked: 9, status: 'draft', relatedRunIds: ['run-004'], summary: 'Physics-Informed Neural Networks trained on DNS datasets correct systematic errors in RANS eddy-viscosity models within laminar separation bubbles. Field Inversion + Machine Learning (FIML) framework allows uncertainty-aware corrections without retraining the full model.' },
];

// ── MANUSCRIPT SECTIONS (run-002 — completed) ────────────────────────────────────
export const manuscriptSectionsRun002: ManuscriptSection[] = [
  { id: 'abstract', runId: 'run-002', label: 'Abstract', wordCount: 248, status: 'complete', content: `Variable camber morphing wings driven by embedded shape memory alloy (SMA) actuators offer passive aerodynamic adaptation to off-design transonic conditions. This study presents a coupled fluid–structure interaction (FSI) investigation of a NiTi SMA-actuated trailing-edge section on a supercritical airfoil at Mach 0.76–0.82, with lift coefficients spanning C_L = 0.3–0.65. RANS simulations (k-ω SST, Richardson-extrapolated on three grid levels) coupled to the Lagoudas SMA constitutive model predict a drag reduction of ΔC_D = −0.00312 ± 0.00018 (95% CI, RANS k-ω SST) at the cruise design point, corresponding to a 3.1% drag improvement. The results establish the first FSI-validated design envelope for SMA morphing wings under sustained transonic aerodynamic loading exceeding 2.5g, demonstrating a viable structural authority margin of 1,240 ± 45 N at maximum actuation temperature.` },
  { id: 'nomenclature', runId: 'run-002', label: 'Nomenclature', wordCount: 112, status: 'complete', content: `C_D — Drag coefficient [—]\nC_L — Lift coefficient [—]\nM — Mach number [—]\nT_f — SMA phase transformation finish temperature [K]\nA_f — Austenite finish temperature [K]\nε_SMA — SMA transformation strain [—]\nσ — Cauchy stress [Pa]\nΔC_D — Change in drag coefficient [—]\ng — Load factor (gravitational acceleration units) [—]\nRe — Reynolds number [—]\nq∞ — Dynamic pressure [Pa]\nL/D — Lift-to-drag ratio [—]` },
  { id: 'introduction', runId: 'run-002', label: 'Introduction', wordCount: 1240, status: 'complete', content: `Modern commercial transport aircraft operate across a wide range of lift coefficients during a typical mission profile, from high-C_L takeoff and landing configurations to low-C_L cruise conditions at transonic Mach numbers. Fixed airfoil geometry, while optimized for the cruise design point, incurs drag penalties at off-design conditions that accumulate over the mission. Variable-camber morphing offers a pathway to recover this penalty by continuously adapting wing shape to the instantaneous aerodynamic demand.\n\nShape Memory Alloy (SMA) actuators have emerged as a structurally compact, low-part-count alternative to conventional servo-actuation for morphing applications. NiTi SMA wires embedded in composite laminates can deliver 4–8% recovery strain on the austenite-phase transformation cycle (A_f ≈ 343 K), enabling trailing-edge camber changes of 5–12° with sub-second actuation response (Barbarino et al., 2023). The absence of hinges and gearboxes makes SMA systems attractive for fatigue-critical applications, though the thermomechanical coupling between actuation and structural load response under transonic aerodynamic loading has not been rigorously quantified in the open literature.\n\nNguyen et al. (2022) characterized the aerodynamic benefit of variable camber in a wind-tunnel and RANS study but used conventional servo-flap actuation and did not address structural authority under sustained loading. Lagoudas et al. (2022) provide the definitive SMA constitutive framework but without coupled aerodynamic loading. The present work bridges this gap by integrating a three-level Richardson-extrapolated RANS solver with the Lagoudas SMA model to deliver the first FSI-validated design envelope for SMA morphing wings at transonic conditions.` },
  { id: 'methodology', runId: 'run-002', label: 'Methodology', wordCount: 2480, status: 'complete', content: `**3.1 Aerodynamic Solver**\n\nAll aerodynamic computations use the DLR TAU code with a k-ω SST turbulence closure. Three structured grids are generated (Level 1: 3.2M cells, Level 2: 12.4M cells, Level 3: 49.6M cells) with y+ < 1 on the airfoil surface. Grid convergence is assessed by Richardson extrapolation, yielding a grid convergence index (GCI) of 1.2% on C_D between Level 2 and Level 3.\n\n**3.2 SMA Constitutive Model**\n\nThe Lagoudas (2022) unified thermomechanical SMA model is implemented as a user material (UMAT) subroutine in Abaqus/Standard 2024. The model accounts for phase transformation plasticity, thermomechanical coupling, and cyclic degradation over 1,000 actuation cycles.\n\n**3.3 FSI Coupling Strategy**\n\nOne-way FSI coupling is employed: aerodynamic surface pressures from the TAU solver are applied as boundary conditions on the Abaqus structural model at each load step. The coupling assumption is justified by a timescale separation analysis (Section 3.4): SMA actuation period ~240 ms vs. aerodynamic response time ~8 ms (separation ratio 30×).\n\n**3.4 Timescale Separation Analysis**\n\nThe aerodynamic response timescale is estimated as τ_aero = c/V∞ = 0.25 m / (260 m/s) ≈ 0.96 ms. The SMA thermal actuation timescale is governed by Joule heating: τ_SMA ≈ m·c_p/P = 240 ms at 40 W heating power. The ratio τ_SMA/τ_aero ≈ 250, confirming that structural motions are quasi-static relative to aerodynamic response.` },
  { id: 'results', runId: 'run-002', label: 'Results & Discussion', wordCount: 2890, status: 'complete', content: `**4.1 Grid Convergence Study**\n\nRichardson extrapolation on three mesh levels (Level 1–3) yields GCI_23 = 1.2% for C_D and GCI_23 = 0.8% for C_L at the cruise design point (M = 0.78, C_L = 0.50). All subsequent results use the Level-2 mesh (12.4M cells) as the production grid, providing a balance between accuracy and computational cost.\n\n**4.2 Variable Camber Aerodynamic Performance**\n\nAt the cruise design point (M = 0.78, C_L = 0.50), the optimal camber schedule (δ_te = +1.8°) reduces C_D from 0.01022 to 0.00710, a reduction of ΔC_D = −0.00312 ± 0.00018 (95% CI, k-ω SST, Richardson extrapolation). This corresponds to a 3.1% drag improvement and a lift-to-drag ratio of L/D = 18.4 ± 0.3 (95% CI), compared to L/D = 17.2 for the fixed geometry baseline.\n\n**4.3 SMA Structural Authority**\n\nAt 2.5g aerodynamic loading (q∞ = 14.2 kPa), the Lagoudas-model FSI analysis predicts a net SMA actuation force of F_SMA = 1,240 ± 45 N (90% CI, Abaqus FEA). The structural authority margin (ratio of SMA force to aerodynamic hinge moment) is 1.38 ± 0.08, confirming adequate actuator authority across the full loading envelope.` },
  { id: 'conclusions', runId: 'run-002', label: 'Conclusions', wordCount: 420, status: 'complete', content: `This study has presented the first FSI-validated design envelope for SMA-actuated morphing wings under sustained transonic aerodynamic loading. The principal findings are:\n\n1. At the cruise design point (M = 0.78, C_L = 0.50), variable camber actuation achieves a drag reduction of ΔC_D = −0.00312 ± 0.00018 (95% CI), corresponding to L/D = 18.4 ± 0.3 vs. the fixed-geometry baseline of 17.2 — a 7% improvement in cruise efficiency.\n\n2. SMA actuation force of F_SMA = 1,240 ± 45 N (90% CI) at 2.5g loading provides a structural authority margin of 1.38 ± 0.08, confirming feasibility across the intended maneuver envelope.\n\n3. Timescale separation analysis (τ_SMA/τ_aero ≈ 250) validates the one-way FSI coupling assumption, enabling computationally tractable parametric design studies.\n\nFuture work should address two-way FSI coupling for highly flexible wings (EI < 1 MN·m²), fatigue characterization of the SMA constitutive response over > 10,000 cycles, and experimental validation at transonic wind-tunnel conditions.` },
  { id: 'references', runId: 'run-002', label: 'References', wordCount: 680, status: 'complete', content: `[1] Barbarino, S., Saavedra Flores, E.I., and Ajaj, R.M., "Shape Memory Alloy Actuators for Morphing Wing Camber Control," Smart Materials and Structures, Vol. 32, No. 4, 2023, pp. 044001. doi:10.1088/1361-665X/ac7d2c\n\n[2] Nguyen, N., Precup, N., and Urnes, J., "Transonic Aerodynamic Benefits of Variable Camber Wings," AIAA Journal, Vol. 60, No. 8, 2022, pp. 4701–4718. doi:10.2514/1.J061834\n\n[3] Lagoudas, D.C., Entchev, P.B., and Kumar, P.K., "SMA Constitutive Models for Aerospace Actuator Design," Mechanics of Materials, Vol. 168, 2022, pp. 104319. doi:10.1016/j.mechmat.2022.104319\n\n[4] Illi, S.A., Lutz, T., and Krämer, E., "Transonic Buffet Onset Delay via Adaptive Trailing Edge," Aerospace Science and Technology, Vol. 134, 2023, pp. 108445. doi:10.1016/j.ast.2023.108445\n\n[5] Kaemming, T.A. and Paxson, D.E., "Thermodynamic Cycle Analysis of Pressure Gain Combustion Engines," AIAA Journal, Vol. 62, No. 1, 2024, pp. 102–119. doi:10.2514/1.J063810` },
];
